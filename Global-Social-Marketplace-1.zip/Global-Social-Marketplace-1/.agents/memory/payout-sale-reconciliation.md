---
name: Payout sale reconciliation
description: The evidence threshold and ownership rule for attributing marketplace sales to connected-account payouts.
---

Attribute a sale to a payout only when the payment provider lists its persisted destination transfer among that payout's balance transactions. Do not infer payout membership from dates, totals, or transfer status.

**Why:** Payout timing can include adjustments, reserves, refunds, and unrelated balance activity. Heuristic matching can show a seller an incorrect financial breakdown.

**How to apply:** Fully page provider payout and balance-transaction results, then require the transfer owner and linked order seller to match the authenticated user before returning sale details.