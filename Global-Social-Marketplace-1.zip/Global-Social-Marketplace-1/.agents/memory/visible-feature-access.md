---
name: Visible feature access
description: Product rule for presenting implemented and planned VibeLoom capabilities.
---

Major product areas should always have a clear user-facing navigation path. If backend support is not implemented, keep the destination visible but disable unsupported actions and label them as coming soon.

**Why:** Users must understand the platform's scope without confusing a route or placeholder with working upload, payment, streaming, or account-management behavior.

**How to apply:** When adding or revising a major VibeLoom capability, add a direct entry from the primary shell, Home, Search, or Profile as appropriate, and never show an enabled control unless its flow works.