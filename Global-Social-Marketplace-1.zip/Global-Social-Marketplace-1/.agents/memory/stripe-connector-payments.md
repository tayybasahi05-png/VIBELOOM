---
name: Stripe connector payments
description: Durable constraints for payment API access and verified webhook crediting through Replit's Stripe connector.
---

Use Replit's Stripe connector proxy for products, prices, and Checkout Sessions. Treat the webhook signing secret as a separate secret and never replace signed webhook verification with trust in browser redirects.

Seller-created marketplace listings and inventory are application-owned records. Stripe products and prices are provider mirrors created from the persisted listing at checkout; never resolve seller ownership or payout destination from browser input or Stripe metadata alone.

**Why:** The connected Stripe account can be healthy through the connector while legacy direct-credential environment variables remain unavailable to the application workflow. Browser redirects and client-supplied seller identifiers are user-controlled and are not authoritative proof of payment or ownership.

**How to apply:** Create Stripe resources through the connector SDK. Resolve the listing, seller, inventory, and connected account from PostgreSQL before checkout. Credit balances only after either a verified signed Stripe webhook or a server-side retrieval that confirms the paid session and authenticated owner; keep database credit operations idempotent and transactional.