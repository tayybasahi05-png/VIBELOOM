import { createInsertSchema } from "drizzle-zod";
import { integer, pgTable, serial, text, timestamp, uniqueIndex } from "drizzle-orm/pg-core";
import { giftCatalogTable } from "./gift-catalog";
import { liveRoomsTable } from "./live-rooms";
import { usersTable } from "./users";
import { z } from "zod/v4";

export const giftTransfersTable = pgTable(
  "gift_transfers",
  {
    id: serial("id").primaryKey(),
    roomId: text("room_id").notNull().references(() => liveRoomsTable.id, { onDelete: "restrict" }),
    giftId: text("gift_id").notNull().references(() => giftCatalogTable.id, { onDelete: "restrict" }),
    senderUserId: text("sender_user_id").notNull().references(() => usersTable.id, { onDelete: "restrict" }),
    receiverUserId: text("receiver_user_id").notNull().references(() => usersTable.id, { onDelete: "restrict" }),
    quantity: integer("quantity").notNull().default(1),
    totalCoins: integer("total_coins").notNull(),
    idempotencyKey: text("idempotency_key").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    senderKeyIndex: uniqueIndex("gift_transfers_sender_idempotency_idx").on(table.senderUserId, table.idempotencyKey),
  }),
);

export const insertGiftTransferSchema = createInsertSchema(giftTransfersTable).omit({
  id: true,
  createdAt: true,
});
export type InsertGiftTransfer = z.infer<typeof insertGiftTransferSchema>;
export type GiftTransfer = typeof giftTransfersTable.$inferSelect;