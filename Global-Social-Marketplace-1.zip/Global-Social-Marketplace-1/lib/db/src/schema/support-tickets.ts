import { createInsertSchema } from "drizzle-zod";
import { index, integer, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";
import { z } from "zod/v4";
import { usersTable } from "./users";
import { appAiConversationsTable } from "./app-ai-conversations";

export const supportTicketsTable = pgTable(
  "support_tickets",
  {
    id: serial("id").primaryKey(),
    userId: text("user_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "cascade" }),
    conversationId: integer("conversation_id")
      .references(() => appAiConversationsTable.id, { onDelete: "set null" }),
    subject: text("subject").notNull(),
    details: text("details").notNull(),
    status: text("status").notNull().default("open"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("support_tickets_user_idx").on(table.userId)],
);

export const insertSupportTicketSchema = createInsertSchema(supportTicketsTable).omit({
  id: true,
  status: true,
  createdAt: true,
});
export type InsertSupportTicket = z.infer<typeof insertSupportTicketSchema>;
