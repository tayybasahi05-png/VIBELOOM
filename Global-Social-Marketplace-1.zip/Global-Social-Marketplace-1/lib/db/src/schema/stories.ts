import { createInsertSchema } from "drizzle-zod";
import {
  index,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";
import { usersTable } from "./users";
import { z } from "zod/v4";

export const storiesTable = pgTable(
  "stories",
  {
    id: serial("id").primaryKey(),
    authorUserId: text("author_user_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "cascade" }),
    type: text("type").notNull(),
    text: text("text"),
    objectPath: text("object_path"),
    contentType: text("content_type"),
    sizeBytes: integer("size_bytes"),
    durationSeconds: integer("duration_seconds"),
    width: integer("width"),
    height: integer("height"),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    deletedAt: timestamp("deleted_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => ({
    activeStoriesIndex: index("stories_active_idx").on(
      table.deletedAt,
      table.expiresAt,
      table.createdAt,
    ),
    authorStoriesIndex: index("stories_author_created_idx").on(
      table.authorUserId,
      table.createdAt,
    ),
  }),
);

export const storyViewsTable = pgTable(
  "story_views",
  {
    id: serial("id").primaryKey(),
    storyId: integer("story_id")
      .notNull()
      .references(() => storiesTable.id, { onDelete: "cascade" }),
    viewerUserId: text("viewer_user_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "cascade" }),
    viewedAt: timestamp("viewed_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => ({
    storyViewerUnique: uniqueIndex("story_views_story_viewer_uidx").on(
      table.storyId,
      table.viewerUserId,
    ),
    viewerIndex: index("story_views_viewer_idx").on(table.viewerUserId),
  }),
);

export const insertStorySchema = createInsertSchema(storiesTable).omit({
  id: true,
  createdAt: true,
});
export const insertStoryViewSchema = createInsertSchema(storyViewsTable).omit({
  id: true,
  viewedAt: true,
});
export type InsertStory = z.infer<typeof insertStorySchema>;
export type Story = typeof storiesTable.$inferSelect;
export type StoryView = typeof storyViewsTable.$inferSelect;