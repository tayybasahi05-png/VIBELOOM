import { createInsertSchema } from "drizzle-zod";
import {
  boolean,
  index,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";
import { z } from "zod/v4";
import { usersTable } from "./users";

export const marketListingsTable = pgTable(
  "market_listings",
  {
    id: text("id").primaryKey(),
    sellerUserId: text("seller_user_id").notNull().references(() => usersTable.id, { onDelete: "restrict" }),
    name: text("name").notNull(),
    description: text("description").notNull(),
    category: text("category").notNull(),
    condition: text("condition").notNull().default("New"),
    imageUrl: text("image_url").notNull(),
    location: text("location").notNull().default(""),
    amountMinor: integer("amount_minor").notNull(),
    currency: text("currency").notNull().default("usd"),
    status: text("status").notNull().default("published"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    sellerCreatedIdx: index("market_listings_seller_created_idx").on(table.sellerUserId, table.createdAt),
  }),
);

export const paymentOrdersTable = pgTable(
  "payment_orders",
  {
    id: serial("id").primaryKey(),
    buyerUserId: text("buyer_user_id").notNull().references(() => usersTable.id, { onDelete: "restrict" }),
    sellerUserId: text("seller_user_id").references(() => usersTable.id, { onDelete: "restrict" }),
    provider: text("provider").notNull().default("stripe"),
    kind: text("kind").notNull(),
    referenceId: text("reference_id").notNull(),
    description: text("description").notNull(),
    amountMinor: integer("amount_minor").notNull(),
    subtotalMinor: integer("subtotal_minor"),
    taxMinor: integer("tax_minor"),
    taxRateBps: integer("tax_rate_bps"),
    taxRegion: text("tax_region"),
    currency: text("currency").notNull(),
    idempotencyKey: text("idempotency_key").notNull(),
    status: text("status").notNull().default("created"),
    providerCheckoutSessionId: text("provider_checkout_session_id"),
    providerPaymentIntentId: text("provider_payment_intent_id"),
    providerChargeId: text("provider_charge_id"),
    receiptUrl: text("receipt_url"),
    refundedAmountMinor: integer("refunded_amount_minor").notNull().default(0),
    metadata: jsonb("metadata").$type<Record<string, string>>().notNull().default({}),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    checkoutSessionIdx: uniqueIndex("payment_orders_checkout_session_idx").on(table.providerCheckoutSessionId),
    buyerIdempotencyIdx: uniqueIndex("payment_orders_buyer_idempotency_idx").on(table.buyerUserId, table.idempotencyKey),
    buyerCreatedIdx: index("payment_orders_buyer_created_idx").on(table.buyerUserId, table.createdAt),
  }),
);

export const paymentRefundsTable = pgTable(
  "payment_refunds",
  {
    id: serial("id").primaryKey(),
    orderId: integer("order_id").notNull().references(() => paymentOrdersTable.id, { onDelete: "restrict" }),
    requestedByUserId: text("requested_by_user_id").notNull().references(() => usersTable.id, { onDelete: "restrict" }),
    providerRefundId: text("provider_refund_id"),
    amountMinor: integer("amount_minor").notNull(),
    currency: text("currency").notNull(),
    reason: text("reason").notNull(),
    status: text("status").notNull().default("pending"),
    idempotencyKey: text("idempotency_key").notNull(),
    reviewedByUserId: text("reviewed_by_user_id").references(() => usersTable.id, { onDelete: "restrict" }),
    reviewedAt: timestamp("reviewed_at", { withTimezone: true }),
    denialReason: text("denial_reason"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    idempotencyIdx: uniqueIndex("payment_refunds_idempotency_idx").on(table.requestedByUserId, table.idempotencyKey),
    providerRefundIdx: uniqueIndex("payment_refunds_provider_idx").on(table.providerRefundId),
  }),
);

export const paymentDisputesTable = pgTable(
  "payment_disputes",
  {
    id: serial("id").primaryKey(),
    orderId: integer("order_id").references(() => paymentOrdersTable.id, { onDelete: "set null" }),
    providerDisputeId: text("provider_dispute_id").notNull(),
    amountMinor: integer("amount_minor").notNull(),
    currency: text("currency").notNull(),
    status: text("status").notNull(),
    reason: text("reason"),
    responseDueAt: timestamp("response_due_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    providerDisputeIdx: uniqueIndex("payment_disputes_provider_idx").on(table.providerDisputeId),
  }),
);

export const connectedPaymentAccountsTable = pgTable("connected_payment_accounts", {
  userId: text("user_id").primaryKey().references(() => usersTable.id, { onDelete: "cascade" }),
  provider: text("provider").notNull().default("stripe"),
  providerAccountId: text("provider_account_id").notNull().unique(),
  country: text("country"),
  defaultCurrency: text("default_currency"),
  detailsSubmitted: boolean("details_submitted").notNull().default(false),
  chargesEnabled: boolean("charges_enabled").notNull().default(false),
  payoutsEnabled: boolean("payouts_enabled").notNull().default(false),
  status: text("status").notNull().default("restricted"),
  requirements: jsonb("requirements").$type<string[]>().notNull().default([]),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const paymentPayoutsTable = pgTable(
  "payment_payouts",
  {
    id: serial("id").primaryKey(),
    userId: text("user_id").notNull().references(() => usersTable.id, { onDelete: "restrict" }),
    providerPayoutId: text("provider_payout_id").notNull(),
    amountMinor: integer("amount_minor").notNull(),
    currency: text("currency").notNull(),
    status: text("status").notNull(),
    arrivalAt: timestamp("arrival_at", { withTimezone: true }),
    failureCode: text("failure_code"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    providerPayoutIdx: uniqueIndex("payment_payouts_provider_idx").on(table.providerPayoutId),
  }),
);

export const paymentAttemptsTable = pgTable(
  "payment_attempts",
  {
    id: serial("id").primaryKey(),
    orderId: integer("order_id").notNull().references(() => paymentOrdersTable.id, { onDelete: "cascade" }),
    provider: text("provider").notNull().default("stripe"),
    providerPaymentIntentId: text("provider_payment_intent_id"),
    providerCheckoutSessionId: text("provider_checkout_session_id"),
    amountMinor: integer("amount_minor").notNull(),
    currency: text("currency").notNull(),
    status: text("status").notNull().default("created"),
    errorCode: text("error_code"),
    errorMessage: text("error_message"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({ orderIdx: index("payment_attempts_order_idx").on(table.orderId) }),
);

export const paymentTransfersTable = pgTable(
  "payment_transfers",
  {
    id: serial("id").primaryKey(),
    orderId: integer("order_id").references(() => paymentOrdersTable.id, { onDelete: "set null" }),
    userId: text("user_id").notNull().references(() => usersTable.id, { onDelete: "restrict" }),
    providerTransferId: text("provider_transfer_id").notNull(),
    amountMinor: integer("amount_minor").notNull(),
    currency: text("currency").notNull(),
    status: text("status").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({ providerIdx: uniqueIndex("payment_transfers_provider_idx").on(table.providerTransferId) }),
);

export const paymentIdempotencyKeysTable = pgTable(
  "payment_idempotency_keys",
  {
    id: serial("id").primaryKey(),
    userId: text("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
    operation: text("operation").notNull(),
    key: text("key").notNull(),
    requestHash: text("request_hash").notNull(),
    responseStatus: integer("response_status"),
    responseBody: jsonb("response_body"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    expiresAt: timestamp("expires_at", { withTimezone: true }),
  },
  (table) => ({ keyIdx: uniqueIndex("payment_idempotency_key_idx").on(table.userId, table.operation, table.key) }),
);

export const marketPaymentInventoryTable = pgTable("market_payment_inventory", {
  productId: text("product_id").primaryKey().references(() => marketListingsTable.id, { onDelete: "cascade" }),
  availableQuantity: integer("available_quantity").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const paymentReservationsTable = pgTable("payment_reservations", {
  orderId: integer("order_id").primaryKey().references(() => paymentOrdersTable.id, { onDelete: "cascade" }),
  productId: text("product_id").notNull(),
  quantity: integer("quantity").notNull().default(1),
  status: text("status").notNull().default("reserved"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertPaymentOrderSchema = createInsertSchema(paymentOrdersTable).omit({ id: true, createdAt: true, updatedAt: true });
export const insertPaymentRefundSchema = createInsertSchema(paymentRefundsTable).omit({ id: true, createdAt: true, updatedAt: true });
export const insertPaymentAttemptSchema = createInsertSchema(paymentAttemptsTable).omit({ id: true, createdAt: true, updatedAt: true });
export const insertMarketListingSchema = createInsertSchema(marketListingsTable).omit({ createdAt: true, updatedAt: true });
export type PaymentOrder = typeof paymentOrdersTable.$inferSelect;
export type PaymentRefund = typeof paymentRefundsTable.$inferSelect;
export type PaymentDispute = typeof paymentDisputesTable.$inferSelect;
export type ConnectedPaymentAccount = typeof connectedPaymentAccountsTable.$inferSelect;
export type PaymentPayout = typeof paymentPayoutsTable.$inferSelect;
export type PaymentAttempt = typeof paymentAttemptsTable.$inferSelect;
export type PaymentTransfer = typeof paymentTransfersTable.$inferSelect;
export type MarketListing = typeof marketListingsTable.$inferSelect;