import { createInsertSchema } from "drizzle-zod";
import { pgTable, text, timestamp, uniqueIndex } from "drizzle-orm/pg-core";
import { randomUUID } from "node:crypto";
import { z } from "zod/v4";

export const inboxConversationsTable = pgTable(
  "inbox_conversations",
  {
    id: text("id").primaryKey().$defaultFn(() => randomUUID()),
    directKey: text("direct_key"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("inbox_conversations_direct_key_unique").on(table.directKey)],
);

export const insertInboxConversationSchema = createInsertSchema(inboxConversationsTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertInboxConversation = z.infer<typeof insertInboxConversationSchema>;
export type InboxConversation = typeof inboxConversationsTable.$inferSelect;