import { createInsertSchema } from "drizzle-zod";
import { boolean, integer, pgTable, text, timestamp } from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const giftCatalogTable = pgTable("gift_catalog", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  coinCost: integer("coin_cost").notNull(),
  iconUrl: text("icon_url"),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertGiftCatalogSchema = createInsertSchema(giftCatalogTable).omit({
  createdAt: true,
});
export type InsertGiftCatalog = z.infer<typeof insertGiftCatalogSchema>;
export type GiftCatalog = typeof giftCatalogTable.$inferSelect;