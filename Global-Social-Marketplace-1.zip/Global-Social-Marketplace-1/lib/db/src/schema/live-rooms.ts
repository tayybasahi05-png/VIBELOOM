import { createInsertSchema } from "drizzle-zod";
import { boolean, integer, pgTable, text, timestamp } from "drizzle-orm/pg-core";
import { usersTable } from "./users";
import { z } from "zod/v4";

export const liveRoomsTable = pgTable("live_rooms", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  category: text("category").notNull(),
  hostUserId: text("host_user_id").notNull().references(() => usersTable.id, { onDelete: "restrict" }),
  coverUrl: text("cover_url").notNull(),
  viewers: integer("viewers").notNull().default(0),
  isLive: boolean("is_live").notNull().default(true),
  tags: text("tags").array().notNull().default([]),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertLiveRoomSchema = createInsertSchema(liveRoomsTable).omit({
  createdAt: true,
  updatedAt: true,
});
export type InsertLiveRoom = z.infer<typeof insertLiveRoomSchema>;
export type LiveRoom = typeof liveRoomsTable.$inferSelect;