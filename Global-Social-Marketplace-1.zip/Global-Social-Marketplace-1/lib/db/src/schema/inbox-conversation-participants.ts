import { createInsertSchema } from "drizzle-zod";
import { index, pgTable, primaryKey, text, timestamp } from "drizzle-orm/pg-core";
import { z } from "zod/v4";
import { inboxConversationsTable } from "./inbox-conversations";
import { usersTable } from "./users";

export const inboxConversationParticipantsTable = pgTable(
  "inbox_conversation_participants",
  {
    conversationId: text("conversation_id")
      .notNull()
      .references(() => inboxConversationsTable.id, { onDelete: "cascade" }),
    userId: text("user_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "cascade" }),
    joinedAt: timestamp("joined_at", { withTimezone: true }).notNull().defaultNow(),
    lastReadAt: timestamp("last_read_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    primaryKey({ columns: [table.conversationId, table.userId] }),
    index("inbox_participants_user_idx").on(table.userId),
  ],
);

export const insertInboxConversationParticipantSchema = createInsertSchema(
  inboxConversationParticipantsTable,
).omit({ joinedAt: true, lastReadAt: true });
export type InsertInboxConversationParticipant = z.infer<
  typeof insertInboxConversationParticipantSchema
>;