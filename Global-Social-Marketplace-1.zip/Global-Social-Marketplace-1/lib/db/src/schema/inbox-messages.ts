import { createInsertSchema } from "drizzle-zod";
import { index, pgTable, text, timestamp } from "drizzle-orm/pg-core";
import { randomUUID } from "node:crypto";
import { z } from "zod/v4";
import { inboxConversationsTable } from "./inbox-conversations";
import { usersTable } from "./users";

export const inboxMessagesTable = pgTable(
  "inbox_messages",
  {
    id: text("id").primaryKey().$defaultFn(() => randomUUID()),
    conversationId: text("conversation_id")
      .notNull()
      .references(() => inboxConversationsTable.id, { onDelete: "cascade" }),
    senderId: text("sender_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "restrict" }),
    body: text("body").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    index("inbox_messages_conversation_created_idx").on(
      table.conversationId,
      table.createdAt,
    ),
  ],
);

export const insertInboxMessageSchema = createInsertSchema(inboxMessagesTable).omit({
  id: true,
  createdAt: true,
});
export type InsertInboxMessage = z.infer<typeof insertInboxMessageSchema>;
export type InboxMessage = typeof inboxMessagesTable.$inferSelect;