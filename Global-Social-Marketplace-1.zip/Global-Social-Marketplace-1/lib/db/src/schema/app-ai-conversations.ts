import { createInsertSchema } from "drizzle-zod";
import { index, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";
import { z } from "zod/v4";
import { usersTable } from "./users";

export const appAiConversationsTable = pgTable(
  "app_ai_conversations",
  {
    id: serial("id").primaryKey(),
    userId: text("user_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "cascade" }),
    title: text("title").notNull().default("APP AI"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("app_ai_conversations_user_idx").on(table.userId)],
);

export const insertAppAiConversationSchema = createInsertSchema(appAiConversationsTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertAppAiConversation = z.infer<typeof insertAppAiConversationSchema>;
