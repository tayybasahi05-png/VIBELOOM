import { createInsertSchema } from "drizzle-zod";
import { boolean, index, integer, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";
import { z } from "zod/v4";
import { appAiConversationsTable } from "./app-ai-conversations";

export const appAiMessagesTable = pgTable(
  "app_ai_messages",
  {
    id: serial("id").primaryKey(),
    conversationId: integer("conversation_id")
      .notNull()
      .references(() => appAiConversationsTable.id, { onDelete: "cascade" }),
    role: text("role").notNull(),
    content: text("content").notNull(),
    helpful: boolean("helpful"),
    reportReason: text("report_reason"),
    reportedAt: timestamp("reported_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("app_ai_messages_conversation_idx").on(table.conversationId)],
);

export const insertAppAiMessageSchema = createInsertSchema(appAiMessagesTable).omit({
  id: true,
  helpful: true,
  reportReason: true,
  reportedAt: true,
  createdAt: true,
});
export type InsertAppAiMessage = z.infer<typeof insertAppAiMessageSchema>;
