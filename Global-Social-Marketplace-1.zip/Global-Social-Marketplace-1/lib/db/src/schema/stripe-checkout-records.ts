import { createInsertSchema } from "drizzle-zod";
import { integer, pgTable, serial, text, timestamp, uniqueIndex } from "drizzle-orm/pg-core";
import { usersTable } from "./users";
import { z } from "zod/v4";

export const stripeCheckoutRecordsTable = pgTable(
  "stripe_checkout_records",
  {
    id: serial("id").primaryKey(),
    userId: text("user_id").notNull().references(() => usersTable.id, { onDelete: "restrict" }),
    checkoutSessionId: text("checkout_session_id").notNull(),
    packId: text("pack_id").notNull(),
    coinAmount: integer("coin_amount").notNull(),
    amountMinor: integer("amount_minor"),
    currency: text("currency").notNull().default("usd"),
    status: text("status").notNull().default("pending"),
    paymentIntentId: text("payment_intent_id"),
    paidAt: timestamp("paid_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    checkoutSessionIndex: uniqueIndex("stripe_checkout_session_idx").on(table.checkoutSessionId),
  }),
);

export const insertStripeCheckoutRecordSchema = createInsertSchema(stripeCheckoutRecordsTable).omit({
  id: true,
  createdAt: true,
});
export type InsertStripeCheckoutRecord = z.infer<typeof insertStripeCheckoutRecordSchema>;
export type StripeCheckoutRecord = typeof stripeCheckoutRecordsTable.$inferSelect;