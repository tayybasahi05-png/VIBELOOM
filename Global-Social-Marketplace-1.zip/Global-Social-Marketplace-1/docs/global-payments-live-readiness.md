# Global payments live-readiness

## Current charge model

Stripe-hosted Checkout is the only collection surface. The server resolves a
product from its own catalog and sends Stripe integer minor units and lowercase
ISO currency values; clients cannot choose a price, seller, or currency.
Marketplace charges use destination charges only after the seller's Express
Connect account reports both `charges_enabled` and `payouts_enabled`. Until
then the product is explicitly unavailable for payment. Platform-only test
checkout is opt-in and must never be enabled for live mode.

The application stores order, attempt, refund, dispute, transfer, payout,
recipient capability, and idempotency records in PostgreSQL. It stores Stripe
identifiers and status, never API keys, bank details, card data, or other
sensitive credentials.

## Capability and geography gates

Connect availability, supported countries, business type, verification
requirements, settlement currencies, and card-present/payment-method support
are Stripe account and platform settings, not assumptions in the UI. A seller
must complete onboarding and remain enabled before receiving a destination
charge. Product currency is currently USD (`usd`); adding currencies requires
an explicit catalog, tax, settlement, and refund review.

## Refunds and disputes

Customer refund requests are ownership-checked, amount-bounded, idempotent,
and stored as pending for authorized support review; submitting a request does
not move money. A later operator workflow must create the Stripe refund, and
Stripe events remain authoritative for its final status. Dispute events make an order disputed and must be reviewed
by an operator; evidence deadlines and responsibility differ by country and
charge model.

## Test/live separation

Use the Replit Stripe connector proxy and separate test/live connections.
Never copy IDs or webhook secrets between environments. Live checkout requires
the production Stripe connection, approved live configuration, configured
Connect platform, and an operator-approved rollout; a successful browser
redirect is never payment proof.

## Webhooks and operations

Register the raw signed webhook endpoint before JSON parsing. Verify the
signature, atomically claim event IDs, and process retries for checkout
success/async success/failure/expiry, PaymentIntent status, refunds, disputes,
account updates, transfers, and payouts. Monitor failed claims, reconciliation
drift, duplicate/idempotency conflicts, and delayed payouts. Reconcile pending
orders from provider state rather than accepting client assertions.

## Legal, tax, and operator checklist

- Complete Stripe KYC/KYB, Connect platform, beneficial-owner, and restricted
  business reviews for every supported country.
- Obtain legal advice on marketplace terms, seller-of-record/merchant-of-
  record structure, consumer cancellation and refund rights, sanctions, AML,
  privacy, and chargeback allocation.
- Configure tax registration, VAT/GST/sales-tax collection, invoices, seller
  reporting, withholding, and payout reconciliation before live money movement.
- Publish buyer and seller terms, privacy/cookie notices, refund policy,
  support escalation, dispute evidence process, and contact details.
- Set webhook alerts, rotate signing secrets through Replit Secrets, test
  replay/retry behavior, document incident response, and restrict production
  dashboard access.

This code slice is not a claim that live payments are ready: Stripe Dashboard,
legal, tax, Connect, webhook, and operator setup remain required.