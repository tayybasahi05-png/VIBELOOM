import { useEffect, useRef } from "react";
import { ClerkProvider, SignIn, SignUp, Show, useClerk } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { shadcn } from '@clerk/themes';
import { Switch, Route, useLocation, Router as WouterRouter, Redirect, Link } from 'wouter';
import { QueryClient, QueryClientProvider, useQueryClient } from "@tanstack/react-query";
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';

// Pages
import { Landing } from './pages/landing';
import { Home } from './pages/home';
import { Market } from './pages/market';
import { ProductDetail } from './pages/product-detail';
import { Inbox } from './pages/inbox';
import { AppAiAssistant } from './pages/app-ai-assistant';
import { ConversationDetail } from './pages/conversation';
import { Search } from './pages/search';
import { Live } from './pages/live';
import { RoomDetail } from './pages/room-detail';
import { Opportunities } from './pages/opportunities';
import { Wallet } from './pages/wallet';
import { Payments } from './pages/payments';
import { Notifications } from './pages/notifications';
import { Profile } from './pages/profile';
import { MemberProfile } from './pages/member-profile';
import { Blogs } from './pages/blogs';
import { Communities } from './pages/communities';
import { Media } from './pages/media';
import { Advertising } from './pages/advertising';
import { Layout } from './components/layout';

const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);

const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;
const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

function stripBase(path: string): string {
  return basePath && path.startsWith(basePath)
    ? path.slice(basePath.length) || "/"
    : path;
}

if (!clerkPubKey) {
  throw new Error('Missing VITE_CLERK_PUBLISHABLE_KEY in .env file');
}

const clerkAppearance = {
  theme: shadcn,
  cssLayerName: "clerk",
  options: {
    logoPlacement: "inside" as const,
    logoLinkUrl: basePath || "/",
    logoImageUrl: `${window.location.origin}${basePath}/vibeloom-logo.jpeg`,
  },
  variables: {
    colorPrimary: "hsl(95 24% 34%)",
    colorForeground: "hsl(95 15% 15%)",
    colorMutedForeground: "hsl(95 10% 40%)",
    colorDanger: "hsl(0 70% 45%)",
    colorBackground: "hsl(45 40% 98%)",
    colorInput: "hsl(45 15% 86%)",
    colorInputForeground: "hsl(95 15% 15%)",
    colorNeutral: "hsl(45 15% 86%)",
    fontFamily: "'Plus Jakarta Sans', sans-serif",
    borderRadius: "0.75rem",
  },
  elements: {
    rootBox: "w-full flex justify-center",
    cardBox: "bg-card rounded-3xl w-[440px] max-w-full overflow-hidden border border-border shadow-lg",
    card: "!shadow-none !border-0 !bg-transparent !rounded-none",
    footer: "!shadow-none !border-0 !bg-transparent !rounded-none",
    headerTitle: "text-foreground font-serif text-3xl font-bold",
    headerSubtitle: "text-muted-foreground text-base",
    socialButtonsBlockButtonText: "text-foreground font-semibold",
    formFieldLabel: "text-foreground font-bold",
    footerActionLink: "text-primary hover:text-primary/80 font-bold",
    footerActionText: "text-muted-foreground",
    dividerText: "text-muted-foreground font-semibold",
    identityPreviewEditButton: "text-primary",
    formFieldSuccessText: "text-primary",
    alertText: "text-destructive",
    logoBox: "mx-auto mb-4 flex h-24 w-24 items-center justify-center overflow-hidden rounded-3xl border border-border shadow-md",
    logoImage: "h-full w-full object-cover",
    socialButtonsBlockButton: "border-2 border-border bg-card hover:bg-secondary transition-all rounded-xl py-4",
    formButtonPrimary: "bg-primary text-primary-foreground hover:bg-primary/90 transition-all rounded-xl py-4 font-bold text-lg",
    formFieldInput: "bg-background border-2 border-border text-foreground focus:ring-primary focus:border-primary rounded-xl py-3",
    footerAction: "bg-background pb-6",
    dividerLine: "bg-border h-0.5",
    alert: "bg-destructive/10 border border-destructive/20 text-destructive rounded-xl",
    otpCodeFieldInput: "border-2 border-border text-foreground focus:ring-primary rounded-xl",
    formFieldRow: "mb-5",
    main: "w-full px-6 pt-6",
  },
};

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: false,
      refetchOnWindowFocus: false,
    },
  },
});

function HomeRedirect() {
  return (
    <>
      <Show when="signed-in">
        <Redirect to="/home" />
      </Show>
      <Show when="signed-out">
        <Landing />
      </Show>
    </>
  );
}

function SignInPage() {
  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-background noise-bg px-4 py-12">
      <SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} />
    </div>
  );
}

function SignUpPage() {
  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-background noise-bg px-4 py-12">
      <SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} />
    </div>
  );
}

function ProtectedRoute({ component: Component, ...rest }: any) {
  return (
    <Route {...rest}>
      {() => (
        <>
          <Show when="signed-in">
            <Layout>
              <Component />
            </Layout>
          </Show>
          <Show when="signed-out">
            <Redirect to="/" />
          </Show>
        </>
      )}
    </Route>
  );
}

function ClerkQueryClientCacheInvalidator() {
  const { addListener } = useClerk();
  const queryClient = useQueryClient();
  const previousUserId = useRef<string | null | undefined>(undefined);

  useEffect(() => {
    return addListener(({ user }) => {
      const userId = user?.id ?? null;
      if (previousUserId.current !== undefined && previousUserId.current !== userId) {
        queryClient.clear();
      }
      previousUserId.current = userId;
    });
  }, [addListener, queryClient]);

  return null;
}

function ClerkProviderWithRoutes() {
  const [, setLocation] = useLocation();

  return (
    <ClerkProvider
      publishableKey={clerkPubKey}
      proxyUrl={clerkProxyUrl}
      appearance={clerkAppearance}
      signInUrl={`${basePath}/sign-in`}
      signUpUrl={`${basePath}/sign-up`}
      localization={{
        signIn: {
          start: {
            title: "Welcome to VibeLoom",
            subtitle: "Sign in to connect and discover",
          },
        },
        signUp: {
          start: {
            title: "Join VibeLoom",
            subtitle: "Create your account today",
          },
        },
      }}
      routerPush={(to) => setLocation(stripBase(to))}
      routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
    >
      <QueryClientProvider client={queryClient}>
        <ClerkQueryClientCacheInvalidator />
        <Toaster />
        <Switch>
          <Route path="/" component={HomeRedirect} />
          <Route path="/sign-in/*?" component={SignInPage} />
          <Route path="/sign-up/*?" component={SignUpPage} />
          
          <ProtectedRoute path="/home" component={Home} />
          <ProtectedRoute path="/market" component={Market} />
          <ProtectedRoute path="/market/:productId" component={ProductDetail} />
          <ProtectedRoute path="/inbox" component={Inbox} />
          <ProtectedRoute path="/inbox/app-ai" component={AppAiAssistant} />
          <ProtectedRoute path="/inbox/:conversationId" component={ConversationDetail} />
          <Route path="/discover"><Redirect to="/search" /></Route>
          <ProtectedRoute path="/search" component={Search} />
          <ProtectedRoute path="/live" component={Live} />
          <ProtectedRoute path="/live/:roomId" component={RoomDetail} />
          <ProtectedRoute path="/opportunities" component={Opportunities} />
          <ProtectedRoute path="/wallet" component={Wallet} />
          <ProtectedRoute path="/payments" component={Payments} />
          <ProtectedRoute path="/notifications" component={Notifications} />
          <ProtectedRoute path="/profile" component={Profile} />
          <ProtectedRoute path="/profile/:userId" component={MemberProfile} />
          <ProtectedRoute path="/blogs" component={Blogs} />
          <ProtectedRoute path="/communities" component={Communities} />
          <Route path="/gifts"><Redirect to="/live" /></Route>
          <ProtectedRoute path="/media" component={Media} />
          <ProtectedRoute path="/advertising" component={Advertising} />
          
          <Route>
            <div className="flex h-[100dvh] flex-col items-center justify-center bg-background noise-bg">
              <h1 className="text-4xl font-serif text-primary mb-2">Not Found</h1>
              <Link href="/" className="text-muted-foreground hover:text-foreground">Return home</Link>
            </div>
          </Route>
        </Switch>
      </QueryClientProvider>
    </ClerkProvider>
  );
}

export default function App() {
  return (
    <ErrorBoundary resetKey={window.location.pathname}>
      <WouterRouter base={basePath}>
        <ClerkProviderWithRoutes />
      </WouterRouter>
    </ErrorBoundary>
  );
}
