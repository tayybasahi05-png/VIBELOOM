import { Megaphone, BarChart3, Target, ArrowRight } from "lucide-react";

export function Advertising() {
  return (
    <div className="w-full space-y-8">
      <div className="relative overflow-hidden bg-primary text-primary-foreground rounded-3xl p-8 md:p-12">
        <div className="relative z-10 max-w-lg space-y-4">
          <h1 className="text-3xl md:text-5xl font-serif font-bold">VibeLoom Ads</h1>
          <p className="text-primary-foreground/80 text-lg">
            Reach exactly who you want, when they are most engaged. Grow your audience or business with native placements.
          </p>
          <button className="mt-4 px-6 py-3 bg-background text-foreground font-bold rounded-xl flex items-center gap-2 cursor-not-allowed opacity-90" disabled>
            Launch Campaign (Coming Soon)
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
        <div className="absolute right-0 bottom-0 opacity-10 translate-x-1/4 translate-y-1/4">
          <Megaphone className="w-96 h-96" />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-card border border-border p-8 rounded-3xl">
          <div className="w-12 h-12 bg-secondary rounded-xl flex items-center justify-center mb-6">
            <Target className="w-6 h-6 text-foreground" />
          </div>
          <h3 className="text-xl font-bold mb-2">Smart Targeting</h3>
          <p className="text-muted-foreground">
            Our self-serve ad platform is currently in beta. We are working on providing deep analytics and precise demographic targeting for your marketplace listings and content.
          </p>
        </div>
        
        <div className="bg-card border border-border p-8 rounded-3xl">
          <div className="w-12 h-12 bg-secondary rounded-xl flex items-center justify-center mb-6">
            <BarChart3 className="w-6 h-6 text-foreground" />
          </div>
          <h3 className="text-xl font-bold mb-2">Detailed Analytics</h3>
          <p className="text-muted-foreground">
            Track impressions, clicks, and conversions in real-time. The reporting dashboard will be available once the Ads API goes live.
          </p>
        </div>
      </div>
    </div>
  );
}
