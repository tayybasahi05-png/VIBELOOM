import { useListLiveRooms } from "@workspace/api-client-react";
import { Radio, Users, Play } from "lucide-react";

import { Link } from "wouter";

export function Live() {
  const { data: rooms, isLoading } = useListLiveRooms();

  return (
    <div className="w-full pb-10">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-4xl font-serif text-foreground font-bold flex items-center gap-3">
            <Radio className="w-8 h-8 text-destructive animate-pulse" />
            Live Now
          </h1>
          <p className="text-muted-foreground mt-2">Join conversations happening right now.</p>
        </div>
        <button disabled className="hidden sm:flex items-center gap-2 bg-secondary text-muted-foreground px-5 py-3 rounded-xl font-bold shadow-md cursor-not-allowed">
          <Play className="w-5 h-5 fill-current" />
          Start Room (Coming Soon)
        </button>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 animate-pulse">
          {[1,2,3,4].map(i => (
            <div key={i} className="bg-card h-48 rounded-3xl border border-border" />
          ))}
        </div>
      ) : rooms?.length === 0 ? (
        <div className="text-center py-20 bg-card rounded-3xl border border-border">
          <Radio className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-xl font-bold text-foreground">No active rooms</h3>
          <p className="text-muted-foreground mt-2">Be the first to start a conversation today.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
          {rooms?.map(room => (
            <Link key={room.id} href={`/live/${room.id}`} className="group relative bg-card border border-border rounded-3xl overflow-hidden hover-elevate cursor-pointer block">
              {/* Cover */}
              <div className="h-32 bg-secondary relative overflow-hidden">
                <img src={room.coverUrl} alt={room.title} className="w-full h-full object-cover opacity-80 group-hover:scale-105 transition-transform duration-700" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                
                <div className="absolute top-3 left-3 bg-destructive text-destructive-foreground px-2.5 py-1 rounded-full text-xs font-bold flex items-center gap-1.5 shadow-sm">
                  <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                  LIVE
                </div>
                
                <div className="absolute top-3 right-3 bg-black/50 backdrop-blur-md text-white px-2.5 py-1 rounded-full text-xs font-bold flex items-center gap-1.5">
                  <Users className="w-3.5 h-3.5" />
                  {room.viewers}
                </div>
              </div>

              {/* Info */}
              <div className="p-5 relative">
                {/* Host avatar floating up */}
                <div className="absolute -top-6 left-5 border-4 border-card rounded-full overflow-hidden w-12 h-12 bg-secondary shadow-sm">
                  <img src={room.host.avatarUrl} alt={room.host.name} className="w-full h-full object-cover" />
                </div>
                
                <div className="mt-4">
                  <h3 className="text-xl font-bold text-foreground mb-1 leading-tight group-hover:text-primary transition-colors">{room.title}</h3>
                  <p className="text-sm text-muted-foreground font-medium">Hosted by {room.host.name}</p>
                </div>

                {room.tags && room.tags.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-4">
                    {room.tags.map(tag => (
                      <span key={tag} className="bg-secondary text-secondary-foreground px-2.5 py-1 rounded-lg text-xs font-bold">
                        #{tag}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </Link>
          ))}
        </div>
      )}
      
      {/* Mobile fab */}
      <button disabled title="Start Room (Coming Soon)" className="sm:hidden fixed bottom-24 right-4 bg-secondary text-muted-foreground w-14 h-14 rounded-full flex items-center justify-center shadow-xl z-10 cursor-not-allowed">
        <Play className="w-6 h-6 fill-current" />
      </button>
    </div>
  );
}