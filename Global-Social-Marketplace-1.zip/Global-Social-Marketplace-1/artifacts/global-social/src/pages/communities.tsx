import { Users, Plus, Globe } from "lucide-react";

export function Communities() {
  return (
    <div className="w-full space-y-8">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-serif text-foreground font-bold">Communities</h1>
          <p className="text-muted-foreground mt-1">Find your tribe on VibeLoom.</p>
        </div>
        <button className="px-5 py-2.5 bg-primary text-primary-foreground font-bold rounded-xl flex items-center gap-2 cursor-not-allowed opacity-80" disabled>
          <Plus className="w-5 h-5" />
          Create Community
        </button>
      </div>

      <div className="bg-card rounded-3xl border border-border p-12 text-center">
        <div className="w-20 h-20 bg-secondary rounded-full flex items-center justify-center mx-auto mb-6">
          <Globe className="w-10 h-10 text-muted-foreground" />
        </div>
        <h2 className="text-2xl font-bold font-serif mb-3">Community Hub Coming Soon</h2>
        <p className="text-muted-foreground max-w-md mx-auto mb-6">
          We are currently preparing the infrastructure for Groups and Communities. Soon, you'll be able to create private spaces, host discussions, and manage community memberships.
        </p>
        <div className="inline-flex items-center gap-2 text-sm font-medium px-4 py-2 bg-secondary rounded-lg text-muted-foreground">
          <span className="w-2 h-2 rounded-full bg-accent animate-pulse" />
          Under Construction
        </div>
      </div>
    </div>
  );
}
