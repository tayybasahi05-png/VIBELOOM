import {
  getListConversationsQueryKey,
  useCreateConversation,
  useGetMember,
  useGetSession,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { AlertCircle, ArrowLeft, Calendar, CheckCircle2, Loader2, MapPin, MessageCircle } from "lucide-react";
import { useState } from "react";
import { Link, useLocation, useParams } from "wouter";

export function MemberProfile() {
  const { userId } = useParams<{ userId: string }>();
  const { data: member, isLoading, isError, refetch, isFetching } = useGetMember(userId!);
  const { data: session } = useGetSession();
  const createConversation = useCreateConversation();
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();
  const [messageError, setMessageError] = useState<string | null>(null);

  const handleMessage = () => {
    if (!member) return;
    setMessageError(null);
    createConversation.mutate(
      { data: { participantId: member.id } },
      {
        onSuccess: (conversation) => {
          queryClient.setQueryData(
            getListConversationsQueryKey(),
            (current: typeof conversation[] | undefined) => {
              const others = (current ?? []).filter((item) => item.id !== conversation.id);
              return [conversation, ...others];
            },
          );
          setLocation(`/inbox/${conversation.id}`);
        },
        onError: () => setMessageError("Unable to open a conversation with this member."),
      },
    );
  };

  if (isLoading) {
    return <div className="h-80 animate-pulse rounded-3xl border border-border bg-card" />;
  }

  if (isError || !member) {
    return (
      <div className="flex min-h-80 flex-col items-center justify-center rounded-3xl border border-destructive/20 bg-card p-8 text-center">
        <AlertCircle className="mb-3 h-9 w-9 text-destructive" />
        <h1 className="font-serif text-2xl font-bold">Member not found</h1>
        <p className="mt-2 text-sm text-muted-foreground">This profile may no longer be available.</p>
        <button
          type="button"
          onClick={() => refetch()}
          disabled={isFetching}
          className="mt-5 inline-flex min-h-11 items-center gap-2 rounded-xl bg-primary px-5 font-bold text-primary-foreground disabled:opacity-60"
        >
          {isFetching && <Loader2 className="h-4 w-4 animate-spin" />}
          Retry
        </button>
      </div>
    );
  }

  const isOwnProfile = session?.user.id === member.id;

  return (
    <div className="w-full space-y-6">
      <Link href="/search" className="inline-flex items-center gap-2 text-muted-foreground transition-colors hover:text-foreground">
        <ArrowLeft className="h-5 w-5" />
        Back
      </Link>

      <div className="overflow-hidden rounded-3xl border border-border bg-card">
        <div className="relative h-36 bg-secondary/60">
          <div className="absolute -bottom-14 left-6">
            {member.avatarUrl ? (
              <img
                src={member.avatarUrl}
                alt={member.name}
                className="h-28 w-28 rounded-full border-4 border-card bg-secondary object-cover"
              />
            ) : (
              <span className="flex h-28 w-28 items-center justify-center rounded-full border-4 border-card bg-secondary text-4xl font-bold">
                {member.name.charAt(0).toUpperCase()}
              </span>
            )}
          </div>
        </div>

        <div className="px-6 pb-7 pt-16">
          <div className="flex flex-col gap-5 sm:flex-row sm:items-start sm:justify-between">
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-serif text-3xl font-bold">{member.name}</h1>
                {member.verified && <CheckCircle2 className="h-5 w-5 text-primary" />}
              </div>
              <p className="mt-1 text-muted-foreground">{member.handle}</p>
              <div className="mt-4 flex flex-wrap gap-4 text-sm text-muted-foreground">
                {member.location && (
                  <span className="flex items-center gap-1.5">
                    <MapPin className="h-4 w-4" />
                    {member.location}
                  </span>
                )}
                <span className="flex items-center gap-1.5">
                  <Calendar className="h-4 w-4" />
                  Member profile
                </span>
              </div>
            </div>

            {session && !isOwnProfile && (
              <button
                type="button"
                onClick={handleMessage}
                disabled={createConversation.isPending}
                className="inline-flex min-h-12 items-center justify-center gap-2 rounded-2xl bg-primary px-6 font-bold text-primary-foreground shadow-sm disabled:opacity-60"
              >
                {createConversation.isPending ? (
                  <Loader2 className="h-5 w-5 animate-spin" />
                ) : (
                  <MessageCircle className="h-5 w-5" />
                )}
                Message
              </button>
            )}
          </div>
          {messageError && <p className="mt-4 text-sm font-medium text-destructive">{messageError}</p>}
        </div>
      </div>

      <section className="rounded-3xl border border-border bg-card p-6">
        <h2 className="font-serif text-xl font-bold">About</h2>
        <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
          This member has not added a bio yet.
        </p>
        <span className="mt-5 inline-flex rounded-full bg-secondary px-3 py-1 text-xs font-semibold capitalize text-muted-foreground">
          {member.role}
        </span>
      </section>
    </div>
  );
}