import { FileText, PenTool, Sparkles } from "lucide-react";

export function Blogs() {
  return (
    <div className="w-full space-y-8">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-serif text-foreground font-bold">VibeLoom Blogs</h1>
          <p className="text-muted-foreground mt-1">Read, write, and explore long-form content.</p>
        </div>
        <button className="px-5 py-2.5 bg-secondary text-foreground font-bold rounded-xl flex items-center gap-2 cursor-not-allowed opacity-80" disabled>
          <PenTool className="w-4 h-4" />
          Write (Coming Soon)
        </button>
      </div>

      <div className="bg-primary/5 rounded-3xl border border-primary/10 p-8 text-center space-y-4">
        <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
          <Sparkles className="w-8 h-8 text-primary" />
        </div>
        <h2 className="text-2xl font-serif font-bold text-primary">Blogging is on the way</h2>
        <p className="max-w-xl mx-auto text-muted-foreground">
          We're building a beautiful editor for you to share your stories, guides, and thoughts with the VibeLoom community. The blogging API is currently under development.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 opacity-50 pointer-events-none grayscale-[0.5]">
        {[1, 2, 3, 4].map(i => (
          <div key={i} className="bg-card rounded-2xl border border-border p-5 flex flex-col gap-3">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-secondary" />
              <div className="flex-1">
                <div className="h-3 w-24 bg-secondary rounded" />
                <div className="h-2 w-16 bg-secondary mt-1 rounded" />
              </div>
            </div>
            <div className="h-6 w-3/4 bg-secondary rounded mt-2" />
            <div className="space-y-2 mt-2">
              <div className="h-3 w-full bg-secondary rounded" />
              <div className="h-3 w-5/6 bg-secondary rounded" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
