import { Link } from "wouter";
import { useGetWallet } from "@workspace/api-client-react";
import { Coins, Activity, CreditCard, ShieldCheck } from "lucide-react";

export function Wallet() {
  const { data: wallet, isLoading } = useGetWallet();

  if (isLoading) {
    return (
      <div className="animate-pulse space-y-6">
        <div className="h-48 bg-card rounded-3xl border border-border" />
        <div className="grid grid-cols-2 gap-4">
          <div className="h-32 bg-card rounded-3xl border border-border" />
          <div className="h-32 bg-card rounded-3xl border border-border" />
        </div>
      </div>
    );
  }

  return (
    <div className="w-full pb-10 space-y-6">
      <h1 className="text-3xl font-serif text-foreground font-bold mb-8">Wallet</h1>

      {/* Main Balance Card */}
      <div className="bg-primary text-primary-foreground rounded-3xl p-8 relative overflow-hidden shadow-lg border border-primary-border/20">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/3 pointer-events-none" />
        
        <div className="relative z-10 flex flex-col h-full justify-between gap-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 bg-white/10 px-3 py-1.5 rounded-full text-sm font-medium">
              <Coins className="w-4 h-4 text-accent" />
              Global Coins
            </div>
            <Activity className="w-6 h-6 opacity-50" />
          </div>
          
          <div>
            <p className="text-primary-foreground/70 font-medium mb-1">Available Balance</p>
            <div className="flex items-baseline gap-2">
              <span className="text-5xl md:text-6xl font-serif font-bold tracking-tight">
                {wallet?.coinBalance.toLocaleString()}
              </span>
               <span className="text-xl font-bold opacity-70">Coins</span>
            </div>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Link href="/payments" className="flex items-center gap-4 p-5 bg-card border border-border rounded-2xl hover:bg-secondary transition-colors hover-elevate group">
          <div className="w-12 h-12 bg-secondary text-foreground rounded-full flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform">
            <CreditCard className="w-6 h-6 text-primary" />
          </div>
          <div className="text-left">
            <span className="block font-bold text-foreground text-lg mb-0.5">Payment Center</span>
            <span className="block text-sm text-muted-foreground">Manage orders, payouts, and settings</span>
          </div>
        </Link>
        <button disabled className="flex items-center gap-4 p-5 bg-card border border-border rounded-2xl opacity-50 cursor-not-allowed group">
          <div className="w-12 h-12 bg-secondary text-foreground rounded-full flex items-center justify-center shrink-0">
            <Coins className="w-6 h-6" />
          </div>
          <div className="text-left">
            <span className="block font-bold text-foreground text-lg mb-0.5">Buy Coins</span>
            <span className="block text-sm text-muted-foreground">Coming soon</span>
          </div>
        </button>
      </div>

      <div className="bg-card border border-border p-5 rounded-2xl flex items-start gap-4">
        <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center shrink-0">
          <ShieldCheck className="w-5 h-5 text-primary" />
        </div>
        <div>
          <p className="font-bold text-foreground">Provider-confirmed payouts</p>
          <p className="text-sm text-muted-foreground mt-1">
            Recipient status, payout amounts, and arrival dates appear in the Payment Center only after the payment provider confirms them.
          </p>
        </div>
      </div>
    </div>
  );
}