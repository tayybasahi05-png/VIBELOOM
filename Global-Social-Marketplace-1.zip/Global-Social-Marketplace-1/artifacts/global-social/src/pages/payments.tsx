import { useEffect, useRef, useState } from "react";
import { 
  useGetPaymentConfig, 
  useGetConnectedPaymentAccount, 
  useCreateConnectedPaymentAccount, 
  useCreateConnectedAccountOnboardingLink,
  useListPaymentOrders,
  useListPaymentPayouts,
  useListPaymentRefunds,
  useListSupportPaymentRefunds,
  useDecidePaymentRefund,
  useRequestPaymentRefund,
  useConfirmPaymentOrder,
  useCreateProduct,
  useListSellerProducts,
  useUpdateProduct,
  getListProductsQueryKey,
  getListSellerProductsQueryKey,
  getGetConnectedPaymentAccountQueryKey,
  getListPaymentOrdersQueryKey,
  getListPaymentRefundsQueryKey,
  getListSupportPaymentRefundsQueryKey
} from "@workspace/api-client-react";
import { 
  ShieldCheck, ShieldAlert, CheckCircle2, AlertCircle, ExternalLink, 
  ArrowRight, Clock, RefreshCcw, Receipt, ArrowUpRight, ArrowDownLeft,
  ChevronRight, Loader2, Info, Package, Pencil, Save, X
} from "lucide-react";
import { format } from "date-fns";
import { useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";

function StatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    succeeded: "bg-primary/10 text-primary border-primary/20",
    paid: "bg-primary/10 text-primary border-primary/20",
    pending: "bg-accent/10 text-accent border-accent/20",
    in_transit: "bg-accent/10 text-accent border-accent/20",
    failed: "bg-destructive/10 text-destructive border-destructive/20",
    denied: "bg-destructive/10 text-destructive border-destructive/20",
    approved: "bg-accent/10 text-accent border-accent/20",
    completed: "bg-primary/10 text-primary border-primary/20",
    refunded: "bg-muted text-muted-foreground border-border",
    canceled: "bg-muted text-muted-foreground border-border",
  };

  const style = styles[status] || "bg-secondary text-foreground border-border";
  
  return (
    <span className={`px-2.5 py-1 text-xs font-bold rounded-md border ${style} uppercase tracking-wider`}>
      {status.replace('_', ' ')}
    </span>
  );
}

function formatMinorAmount(amountMinor: number, currency: string) {
  const zeroDecimal = new Set(["BIF", "CLP", "DJF", "GNF", "JPY", "KMF", "KRW", "MGA", "PYG", "RWF", "UGX", "VND", "VUV", "XAF", "XOF", "XPF"]);
  const code = currency.toUpperCase();
  const amount = amountMinor / (zeroDecimal.has(code) ? 1 : 100);
  try {
    return new Intl.NumberFormat(undefined, { style: "currency", currency: code }).format(amount);
  } catch {
    return `${amount.toLocaleString()} ${code}`;
  }
}

export function Payments() {
  const { data: config, isLoading: isConfigLoading } = useGetPaymentConfig();
  const { data: account, isLoading: isAccountLoading } = useGetConnectedPaymentAccount();
  const { data: ordersData, isLoading: isOrdersLoading } = useListPaymentOrders({ limit: 10 });
  const { data: payoutsData, isLoading: isPayoutsLoading } = useListPaymentPayouts();
  const { data: refundsData } = useListPaymentRefunds({
    query: { queryKey: getListPaymentRefundsQueryKey(), refetchInterval: 15_000 },
  });
  const { data: supportRefunds, isLoading: isSupportRefundsLoading } = useListSupportPaymentRefunds({
    query: { queryKey: getListSupportPaymentRefundsQueryKey(), retry: false, refetchInterval: 15_000 },
  });
  const { data: sellerProducts, isLoading: isSellerProductsLoading } = useListSellerProducts({
    query: { queryKey: getListSellerProductsQueryKey(), refetchOnMount: "always" },
  });
  
  const initialTab = new URLSearchParams(window.location.search).get("tab");
  const [activeTab, setActiveTab] = useState<'overview' | 'orders' | 'payouts' | 'refunds'>(
    initialTab === "orders" || initialTab === "payouts" || initialTab === "refunds" ? initialTab : "overview",
  );
  const [countryCode, setCountryCode] = useState("");
  const [onboardingError, setOnboardingError] = useState("");
  
  const createAccount = useCreateConnectedPaymentAccount();
  const createLink = useCreateConnectedAccountOnboardingLink();
  const requestRefund = useRequestPaymentRefund();
  const decideRefund = useDecidePaymentRefund();
  const confirmOrder = useConfirmPaymentOrder();
  const createProduct = useCreateProduct();
  const updateProduct = useUpdateProduct();
  const queryClient = useQueryClient();
  const confirmedReturn = useRef(false);
  const [listing, setListing] = useState({
    name: "",
    price: "",
    imageUrl: "",
    category: "",
    description: "",
    quantity: "1",
  });
  const [editingListing, setEditingListing] = useState<null | {
    id: string;
    name: string;
    price: string;
    imageUrl: string;
    category: string;
    description: string;
    condition: string;
    quantity: string;
    expectedQuantity: number;
    status: "published" | "unpublished";
  }>(null);
  const [listingUpdateError, setListingUpdateError] = useState("");

  useEffect(() => {
    if (confirmedReturn.current) return;
    const orderId = Number(new URLSearchParams(window.location.search).get("order_id"));
    if (!Number.isInteger(orderId) || orderId < 1) return;
    confirmedReturn.current = true;
    confirmOrder.mutate(
      { orderId },
      { onSuccess: () => queryClient.invalidateQueries({ queryKey: getListPaymentOrdersQueryKey() }) },
    );
  }, [confirmOrder, queryClient]);

  const handleCreateAccount = () => {
    if (!countryCode || countryCode.length !== 2) {
      setOnboardingError("Please enter a valid 2-letter country code (e.g., US, UK, CA)");
      return;
    }
    setOnboardingError("");
    createAccount.mutate(
      { data: { country: countryCode.toUpperCase() } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetConnectedPaymentAccountQueryKey() });
        },
        onError: () => {
          setOnboardingError("Failed to create seller account. Please try again.");
        }
      }
    );
  };

  const handleResumeOnboarding = () => {
    createLink.mutate(undefined, {
      onSuccess: (res) => {
        window.location.href = res.url;
      }
    });
  };

  const handleRefund = (orderId: number, amountMinor: number) => {
    if (confirm("Are you sure you want to request a refund for this order?")) {
      requestRefund.mutate(
        { orderId, data: { amountMinor, reason: "requested_by_customer", idempotencyKey: crypto.randomUUID() } },
        {
          onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: getListPaymentOrdersQueryKey() });
            queryClient.invalidateQueries({ queryKey: getListPaymentRefundsQueryKey() });
          }
        }
      );
    }
  };

  const handleRefundDecision = (refundId: number, decision: "approve" | "deny") => {
    const reason = decision === "deny"
      ? window.prompt("Why is this refund being denied? This is recorded for support audit history.")
      : undefined;
    if (decision === "deny" && !reason?.trim()) return;
    decideRefund.mutate(
      { refundId, data: { decision, ...(reason ? { reason: reason.trim() } : {}) } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListSupportPaymentRefundsQueryKey() });
          queryClient.invalidateQueries({ queryKey: getListPaymentRefundsQueryKey() });
        },
      },
    );
  };

  const handleCreateListing = () => {
    const price = Number(listing.price);
    const quantity = Number(listing.quantity);
    if (!listing.name.trim() || !Number.isFinite(price) || price <= 0 || !Number.isInteger(quantity) || quantity < 1 || !listing.imageUrl.trim() || !listing.category.trim() || !listing.description.trim()) return;
    createProduct.mutate(
      {
        productId: `product-${crypto.randomUUID()}`,
        data: {
          name: listing.name.trim(),
          price,
          currency: "USD",
          imageUrl: listing.imageUrl.trim(),
          category: listing.category.trim(),
          description: listing.description.trim(),
          condition: "New",
          quantity,
        },
      },
      {
        onSuccess: () => {
          setListing({ name: "", price: "", imageUrl: "", category: "", description: "", quantity: "1" });
          queryClient.invalidateQueries({ queryKey: getListProductsQueryKey({}) });
          queryClient.invalidateQueries({ queryKey: getListSellerProductsQueryKey() });
        },
      },
    );
  };

  const startEditingListing = (product: NonNullable<typeof sellerProducts>[number]) => {
    setEditingListing({
      id: product.id,
      name: product.name,
      price: String(product.price),
      imageUrl: product.imageUrl,
      category: product.category,
      description: product.description ?? "",
      condition: product.condition ?? "New",
      quantity: String(product.quantity),
      expectedQuantity: product.quantity,
      status: product.status,
    });
  };

  const saveListing = () => {
    if (!editingListing) return;
    const price = Number(editingListing.price);
    const quantity = Number(editingListing.quantity);
    if (
      !editingListing.name.trim() ||
      !Number.isFinite(price) ||
      price <= 0 ||
      !Number.isInteger(quantity) ||
      quantity < 0 ||
      !editingListing.imageUrl.trim() ||
      !editingListing.category.trim() ||
      !editingListing.description.trim()
    ) return;
    setListingUpdateError("");
    updateProduct.mutate(
      {
        productId: editingListing.id,
        data: {
          name: editingListing.name.trim(),
          price,
          imageUrl: editingListing.imageUrl.trim(),
          category: editingListing.category.trim(),
          description: editingListing.description.trim(),
          condition: editingListing.condition.trim() || "New",
          quantity,
          expectedQuantity: editingListing.expectedQuantity,
          status: editingListing.status,
        },
      },
      {
        onSuccess: () => {
          setEditingListing(null);
          queryClient.invalidateQueries({ queryKey: getListSellerProductsQueryKey() });
          queryClient.invalidateQueries({ queryKey: getListProductsQueryKey({}) });
        },
        onError: () => {
          setListingUpdateError("Could not save this listing because its stock changed or the seller account needs attention. Reload the listing and try again.");
          queryClient.invalidateQueries({ queryKey: getListSellerProductsQueryKey() });
        },
      },
    );
  };

  const toggleListingStatus = (product: NonNullable<typeof sellerProducts>[number]) => {
    setListingUpdateError("");
    updateProduct.mutate(
      {
        productId: product.id,
        data: {
          status: product.status === "published" ? "unpublished" : "published",
        },
      },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListSellerProductsQueryKey() });
          queryClient.invalidateQueries({ queryKey: getListProductsQueryKey({}) });
        },
        onError: () => {
          setListingUpdateError(
            product.status === "published"
              ? "Could not unpublish this listing. Reload it and try again."
              : "Could not republish this listing. Reload it, make sure your seller account is active, and try again.",
          );
          queryClient.invalidateQueries({ queryKey: getListSellerProductsQueryKey() });
        },
      },
    );
  };

  if (isConfigLoading) {
    return (
      <div className="w-full pb-20 space-y-6 animate-pulse">
        <div className="h-10 w-48 bg-card rounded-xl border border-border" />
        <div className="h-64 bg-card rounded-3xl border border-border" />
      </div>
    );
  }

  return (
    <div className="w-full pb-20 space-y-8">
      <div>
        <h1 className="text-3xl font-serif text-foreground font-bold mb-2">Payment Center</h1>
        <p className="text-muted-foreground">Manage your transactions securely and efficiently.</p>
      </div>

      {/* Trust Banner */}
      <div className="bg-card border border-border rounded-2xl p-5 flex flex-col sm:flex-row items-start sm:items-center gap-4 shadow-sm">
        <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
          <ShieldCheck className="w-6 h-6 text-primary" />
        </div>
        <div className="flex-1">
          <h3 className="font-bold text-foreground text-lg">Secure Payments</h3>
          <p className="text-sm text-muted-foreground">
            {config?.message || "Payments are securely processed. We do not store your sensitive card details."}
          </p>
        </div>
        <div className="bg-secondary px-3 py-1.5 rounded-lg flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
          <span className="text-xs font-bold text-foreground uppercase tracking-wider">
            {!config?.hostedPaymentCollection ? "Payments Disabled" : config.livePaymentsEnabled ? "Live Mode" : "Test Mode"}
          </span>
        </div>
      </div>

      {/* Navigation */}
      <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-none">
        <button 
          onClick={() => setActiveTab('overview')}
          className={`px-5 py-2.5 rounded-xl font-bold transition-all whitespace-nowrap ${
            activeTab === 'overview' ? "bg-foreground text-background" : "bg-card text-foreground hover:bg-secondary border border-border"
          }`}
        >
          Account Overview
        </button>
        <button 
          onClick={() => setActiveTab('orders')}
          className={`px-5 py-2.5 rounded-xl font-bold transition-all whitespace-nowrap ${
            activeTab === 'orders' ? "bg-foreground text-background" : "bg-card text-foreground hover:bg-secondary border border-border"
          }`}
        >
          Order History
        </button>
        <button 
          onClick={() => setActiveTab('payouts')}
          className={`px-5 py-2.5 rounded-xl font-bold transition-all whitespace-nowrap ${
            activeTab === 'payouts' ? "bg-foreground text-background" : "bg-card text-foreground hover:bg-secondary border border-border"
          }`}
        >
          Payouts
        </button>
        {supportRefunds !== undefined && (
          <button
            onClick={() => setActiveTab('refunds')}
            className={`px-5 py-2.5 rounded-xl font-bold transition-all whitespace-nowrap ${
              activeTab === 'refunds' ? "bg-foreground text-background" : "bg-card text-foreground hover:bg-secondary border border-border"
            }`}
          >
            Refund review {supportRefunds.filter((refund) => refund.status === "pending").length > 0 ? `(${supportRefunds.filter((refund) => refund.status === "pending").length})` : ""}
          </button>
        )}
      </div>

      {/* Tab Content */}
      <div className="space-y-6">
        {activeTab === 'overview' && (
          <div className="space-y-6">
            <h2 className="text-2xl font-serif font-bold text-foreground">Seller Account</h2>
            
            {isAccountLoading ? (
              <div className="h-48 bg-card rounded-3xl border border-border animate-pulse" />
            ) : account?.exists ? (
              <div className="bg-card border border-border rounded-3xl p-6 md:p-8 shadow-sm relative overflow-hidden">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
                  <div className="space-y-2">
                    <div className="flex items-center gap-3">
                      <h3 className="text-xl font-bold text-foreground">Connected Account</h3>
                      {account.status === 'enabled' ? (
                        <span className="flex items-center gap-1.5 px-2.5 py-1 bg-primary/10 text-primary border border-primary/20 rounded-md text-xs font-bold uppercase tracking-wider">
                          <CheckCircle2 className="w-3.5 h-3.5" /> Active
                        </span>
                      ) : (
                        <span className="flex items-center gap-1.5 px-2.5 py-1 bg-accent/10 text-accent border border-accent/20 rounded-md text-xs font-bold uppercase tracking-wider">
                          <AlertCircle className="w-3.5 h-3.5" /> Action Required
                        </span>
                      )}
                    </div>
                    <p className="text-muted-foreground text-sm max-w-md">
                      Your account is registered in {account.country}. 
                      {account.payoutsEnabled 
                        ? " You are ready to receive payouts." 
                        : " You need to provide more details to enable payouts."}
                    </p>
                  </div>
                  
                  {account.status !== 'enabled' && (
                    <button 
                      onClick={handleResumeOnboarding}
                      disabled={createLink.isPending}
                      className="px-6 py-3 bg-primary text-primary-foreground font-bold rounded-xl hover-elevate shadow-md transition-all flex items-center justify-center gap-2"
                    >
                      {createLink.isPending ? <Loader2 className="w-5 h-5 animate-spin" /> : "Complete Setup"}
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  )}
                </div>

                {account.requirements.length > 0 && (
                  <div className="mt-6 p-4 bg-accent/5 border border-accent/10 rounded-2xl relative z-10">
                    <h4 className="text-sm font-bold text-accent mb-2 flex items-center gap-2">
                      <Info className="w-4 h-4" /> Outstanding Requirements
                    </h4>
                    <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground ml-6">
                      {account.requirements.map((req, i) => (
                        <li key={i} className="text-foreground">{req.replace(/_/g, ' ')}</li>
                      ))}
                    </ul>
                  </div>
                )}
                
                {/* Decorative background element */}
                <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/3 pointer-events-none" />
              </div>
            ) : (
              <div className="bg-card border border-border rounded-3xl p-6 md:p-8 shadow-sm">
                <div className="max-w-xl">
                  <h3 className="text-xl font-bold text-foreground mb-3">Become a Seller</h3>
                  <p className="text-muted-foreground mb-6">
                    Set up your connected account to start receiving payments and payouts. We partner with {config?.provider} for secure transactions.
                  </p>
                  
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-bold text-foreground mb-2">
                        Country Code
                      </label>
                      <input 
                        type="text" 
                        placeholder="e.g. US, UK, CA" 
                        maxLength={2}
                        value={countryCode}
                        onChange={(e) => setCountryCode(e.target.value)}
                        className="w-full max-w-[200px] px-4 py-3 bg-background border border-border rounded-xl text-foreground font-medium focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent uppercase"
                      />
                      <p className="text-xs text-muted-foreground mt-2">Enter your 2-letter ISO country code.</p>
                    </div>

                    {onboardingError && (
                      <p className="text-sm text-destructive font-medium">{onboardingError}</p>
                    )}

                    <button 
                      onClick={handleCreateAccount}
                      disabled={createAccount.isPending || !countryCode || !config?.recipientOnboarding}
                      className="px-6 py-3 bg-foreground text-background font-bold rounded-xl hover:bg-foreground/90 transition-all disabled:opacity-50 disabled:pointer-events-none flex items-center gap-2"
                    >
                      {createAccount.isPending ? <Loader2 className="w-5 h-5 animate-spin" /> : config?.recipientOnboarding ? "Start Setup" : "Setup unavailable"}
                    </button>
                  </div>
                </div>
              </div>
            )}

            {account?.status === "enabled" && (
              <div className="bg-card border border-border rounded-3xl p-6 md:p-8 shadow-sm">
                <h3 className="text-xl font-bold text-foreground mb-2">Publish a payable listing</h3>
                <p className="text-sm text-muted-foreground mb-5">
                  This listing will be tied to your verified recipient account. Buyers can check out only while your payment capabilities remain enabled.
                </p>
                <div className="grid sm:grid-cols-2 gap-3">
                  <input aria-label="Product name" placeholder="Product name" value={listing.name} onChange={(event) => setListing({ ...listing, name: event.target.value })} className="px-4 py-3 bg-background border border-border rounded-xl" />
                  <input aria-label="Price in USD" type="number" min="0.01" step="0.01" placeholder="Price in USD" value={listing.price} onChange={(event) => setListing({ ...listing, price: event.target.value })} className="px-4 py-3 bg-background border border-border rounded-xl" />
                  <input aria-label="Image URL" type="url" placeholder="Image URL" value={listing.imageUrl} onChange={(event) => setListing({ ...listing, imageUrl: event.target.value })} className="px-4 py-3 bg-background border border-border rounded-xl sm:col-span-2" />
                  <input aria-label="Category" placeholder="Category" value={listing.category} onChange={(event) => setListing({ ...listing, category: event.target.value })} className="px-4 py-3 bg-background border border-border rounded-xl" />
                  <input aria-label="Inventory quantity" type="number" min="1" step="1" placeholder="Inventory quantity" value={listing.quantity} onChange={(event) => setListing({ ...listing, quantity: event.target.value })} className="px-4 py-3 bg-background border border-border rounded-xl" />
                  <input aria-label="Description" placeholder="Description" value={listing.description} onChange={(event) => setListing({ ...listing, description: event.target.value })} className="px-4 py-3 bg-background border border-border rounded-xl" />
                </div>
                <button onClick={handleCreateListing} disabled={createProduct.isPending} className="mt-4 px-6 py-3 bg-primary text-primary-foreground font-bold rounded-xl disabled:opacity-50">
                  {createProduct.isPending ? "Publishing..." : "Publish listing"}
                </button>
              </div>
            )}

            {account?.exists && (
              <div className="bg-card border border-border rounded-3xl p-6 md:p-8 shadow-sm">
                <div className="mb-5">
                  <h3 className="text-xl font-bold text-foreground">Your listings</h3>
                  <p className="text-sm text-muted-foreground mt-1">Update listing details and stock, or temporarily remove an item from the marketplace.</p>
                </div>
                {listingUpdateError && <p className="mb-4 text-sm font-medium text-destructive">{listingUpdateError}</p>}
                {isSellerProductsLoading ? (
                  <div className="space-y-3">
                    {[1, 2].map((item) => <div key={item} className="h-28 rounded-2xl bg-secondary animate-pulse" />)}
                  </div>
                ) : !sellerProducts?.length ? (
                  <div className="py-10 text-center border border-dashed border-border rounded-2xl">
                    <Package className="w-9 h-9 text-muted-foreground mx-auto mb-3" />
                    <p className="font-bold text-foreground">No listings yet</p>
                    <p className="text-sm text-muted-foreground">Published items will appear here.</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {sellerProducts.map((product) => {
                      const isEditing = editingListing?.id === product.id;
                      return (
                        <div key={product.id} className="border border-border rounded-2xl p-4">
                          {isEditing && editingListing ? (
                            <div className="space-y-3">
                              <div className="grid sm:grid-cols-2 gap-3">
                                <input aria-label="Edit product name" value={editingListing.name} onChange={(event) => setEditingListing({ ...editingListing, name: event.target.value })} className="px-4 py-3 bg-background border border-border rounded-xl" />
                                <input aria-label="Edit price in USD" type="number" min="0.01" step="0.01" value={editingListing.price} onChange={(event) => setEditingListing({ ...editingListing, price: event.target.value })} className="px-4 py-3 bg-background border border-border rounded-xl" />
                                <input aria-label="Edit image URL" type="url" value={editingListing.imageUrl} onChange={(event) => setEditingListing({ ...editingListing, imageUrl: event.target.value })} className="px-4 py-3 bg-background border border-border rounded-xl sm:col-span-2" />
                                <input aria-label="Edit category" value={editingListing.category} onChange={(event) => setEditingListing({ ...editingListing, category: event.target.value })} className="px-4 py-3 bg-background border border-border rounded-xl" />
                                <input aria-label="Edit inventory quantity" type="number" min="0" max="100000" step="1" value={editingListing.quantity} onChange={(event) => setEditingListing({ ...editingListing, quantity: event.target.value })} className="px-4 py-3 bg-background border border-border rounded-xl" />
                                <input aria-label="Edit description" value={editingListing.description} onChange={(event) => setEditingListing({ ...editingListing, description: event.target.value })} className="px-4 py-3 bg-background border border-border rounded-xl sm:col-span-2" />
                              </div>
                              <div className="flex flex-wrap gap-2">
                                <button onClick={saveListing} disabled={updateProduct.isPending} className="px-4 py-2.5 bg-primary text-primary-foreground font-bold rounded-xl disabled:opacity-50 flex items-center gap-2">
                                  {updateProduct.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />} Save changes
                                </button>
                                <button onClick={() => setEditingListing(null)} className="px-4 py-2.5 border border-border font-bold rounded-xl flex items-center gap-2">
                                  <X className="w-4 h-4" /> Cancel
                                </button>
                              </div>
                            </div>
                          ) : (
                            <div className="flex flex-col sm:flex-row gap-4 sm:items-center">
                              <img src={product.imageUrl} alt="" className="w-20 h-20 rounded-xl object-cover bg-secondary shrink-0" />
                              <div className="min-w-0 flex-1">
                                <div className="flex flex-wrap items-center gap-2">
                                  <h4 className="font-bold text-foreground truncate">{product.name}</h4>
                                  <StatusBadge status={product.status} />
                                </div>
                                <p className="text-sm text-muted-foreground mt-1">
                                  {new Intl.NumberFormat(undefined, { style: "currency", currency: product.currency }).format(product.price)} · {product.quantity} available
                                </p>
                                <p className="text-sm text-muted-foreground truncate mt-1">{product.description}</p>
                              </div>
                              <div className="flex sm:flex-col gap-2 shrink-0">
                                <button onClick={() => startEditingListing(product)} disabled={updateProduct.isPending} className="px-3 py-2 border border-border font-bold rounded-xl flex items-center justify-center gap-2">
                                  <Pencil className="w-4 h-4" /> Edit
                                </button>
                                <button onClick={() => toggleListingStatus(product)} disabled={updateProduct.isPending} className="px-3 py-2 border border-border font-bold rounded-xl disabled:opacity-50">
                                  {product.status === "published" ? "Unpublish" : "Republish"}
                                </button>
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {activeTab === 'orders' && (
          <div className="space-y-6">
            <h2 className="text-2xl font-serif font-bold text-foreground">Order History</h2>
            {refundsData && refundsData.length > 0 && (
              <div className="bg-card border border-border rounded-2xl p-5">
                <h3 className="font-bold text-foreground mb-3">Refund requests</h3>
                <div className="space-y-3">
                  {refundsData.map((refund) => (
                    <div key={refund.id} className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-t border-border first:border-t-0 pt-3 first:pt-0">
                      <div>
                        <p className="text-sm font-bold text-foreground">
                          Order #{refund.orderId} · {formatMinorAmount(refund.amountMinor, refund.currency)}
                        </p>
                        <p className="text-xs text-muted-foreground">Requested {format(new Date(refund.createdAt), "MMM d, yyyy")}</p>
                        {refund.denialReason && <p className="text-sm text-destructive mt-1">Reason: {refund.denialReason}</p>}
                      </div>
                      <StatusBadge status={refund.status} />
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            {isOrdersLoading ? (
              <div className="space-y-4">
                {[1,2,3].map(i => <div key={i} className="h-24 bg-card rounded-2xl border border-border animate-pulse" />)}
              </div>
            ) : !ordersData?.items || ordersData.items.length === 0 ? (
              <div className="text-center py-16 bg-card border border-border rounded-3xl">
                <Receipt className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
                <h3 className="text-lg font-bold text-foreground mb-2">No orders yet</h3>
                <p className="text-muted-foreground max-w-sm mx-auto">When you make purchases on the marketplace, they will appear here.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {ordersData.items.map((order) => (
                  <div key={order.id} className="bg-card border border-border rounded-2xl p-5 hover:border-border/80 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center shrink-0 mt-1">
                        <ArrowUpRight className="w-5 h-5 text-foreground" />
                      </div>
                      <div>
                        <p className="font-bold text-foreground">{order.description}</p>
                        <div className="flex flex-wrap items-center gap-2 mt-1 text-sm text-muted-foreground">
                          <span>{format(new Date(order.createdAt), "MMM d, yyyy")}</span>
                          <span>•</span>
                          <span className="font-mono text-xs bg-secondary px-1.5 py-0.5 rounded">{order.referenceId}</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center sm:flex-col sm:items-end justify-between sm:justify-center gap-2">
                      <div className="text-right">
                        <p className="font-bold text-foreground text-lg">
                          {formatMinorAmount(order.amountMinor, order.currency)}
                        </p>
                        <p className="text-xs text-muted-foreground mt-1">
                          {formatMinorAmount(order.subtotalMinor, order.currency)} + {formatMinorAmount(order.taxMinor, order.currency)} tax
                          {order.taxRateBps > 0 ? ` (${order.taxRateBps / 100}%)` : ""}
                        </p>
                        <StatusBadge status={order.status} />
                      </div>
                      
                      <div className="flex items-center gap-2">
                        {order.receiptUrl && (
                          <a 
                            href={order.receiptUrl} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-xs font-bold text-primary hover:text-primary/80 flex items-center gap-1"
                          >
                            Receipt <ExternalLink className="w-3 h-3" />
                          </a>
                        )}
                        {order.status === 'succeeded' && config?.refunds && (
                          <button 
                            onClick={() => handleRefund(order.id, order.amountMinor)}
                            disabled={requestRefund.isPending}
                            className="text-xs font-bold text-muted-foreground hover:text-foreground transition-colors ml-2"
                          >
                            Request refund
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'payouts' && (
          <div className="space-y-6">
            <h2 className="text-2xl font-serif font-bold text-foreground">Payout History</h2>
            
            {isPayoutsLoading ? (
              <div className="space-y-4">
                {[1,2].map(i => <div key={i} className="h-24 bg-card rounded-2xl border border-border animate-pulse" />)}
              </div>
            ) : !payoutsData || payoutsData.length === 0 ? (
              <div className="text-center py-16 bg-card border border-border rounded-3xl">
                <RefreshCcw className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
                <h3 className="text-lg font-bold text-foreground mb-2">No payouts yet</h3>
                <p className="text-muted-foreground max-w-sm mx-auto">Your earnings will be paid out automatically based on your account settings.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {payoutsData.map((payout) => (
                  <div key={payout.id} className="bg-card border border-border rounded-2xl p-5">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <div className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0 mt-1">
                        <ArrowDownLeft className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <p className="font-bold text-foreground">Recipient payout</p>
                        <div className="flex items-center gap-2 mt-1 text-sm text-muted-foreground">
                          <Clock className="w-3.5 h-3.5" />
                          <span>Initiated {format(new Date(payout.createdAt), "MMM d, yyyy")}</span>
                        </div>
                        {payout.arrivalAt && (
                          <p className="text-xs text-muted-foreground mt-1">
                            Expected arrival: {format(new Date(payout.arrivalAt), "MMM d, yyyy")}
                          </p>
                        )}
                      </div>
                      </div>
                    
                      <div className="text-right flex items-center sm:flex-col sm:items-end justify-between sm:justify-center">
                        <p className="font-bold text-primary text-lg">
                          +{formatMinorAmount(payout.amountMinor, payout.currency)}
                        </p>
                        <StatusBadge status={payout.status} />
                      </div>
                    </div>
                    <div className="mt-5 pt-5 border-t border-border">
                      <div className="flex items-center justify-between gap-3 mb-3">
                        <p className="text-sm font-bold text-foreground">Sales in this payout</p>
                        <span className="text-xs text-muted-foreground">Provider-confirmed transfers</span>
                      </div>
                      {payout.sales.length === 0 ? (
                        <p className="text-sm text-muted-foreground">No marketplace sales could be matched from the provider balance data.</p>
                      ) : (
                        <div className="space-y-3">
                          {payout.sales.map((sale) => (
                            <div id={`seller-order-${sale.orderId}`} key={sale.orderId} className="rounded-xl bg-secondary/40 p-4 scroll-mt-6">
                              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
                                <div>
                                  <Link href={`/market/${encodeURIComponent(sale.listingId)}`} className="font-bold text-foreground hover:text-primary">
                                    {sale.listingName}
                                  </Link>
                                  <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                                    <a href={`?tab=payouts&orderId=${sale.orderId}#seller-order-${sale.orderId}`} className="hover:text-foreground">Order #{sale.orderId}</a>
                                    <span>{format(new Date(sale.createdAt), "MMM d, yyyy")}</span>
                                    <StatusBadge status={sale.status} />
                                  </div>
                                </div>
                                <dl className="grid grid-cols-3 gap-4 text-right text-xs">
                                  <div><dt className="text-muted-foreground">Gross</dt><dd className="font-bold text-foreground">{formatMinorAmount(sale.grossAmountMinor, sale.currency)}</dd></div>
                                  <div><dt className="text-muted-foreground">Platform fee</dt><dd className="font-bold text-foreground">−{formatMinorAmount(sale.platformFeeMinor, sale.currency)}</dd></div>
                                  <div><dt className="text-muted-foreground">Transfer</dt><dd className="font-bold text-primary">{formatMinorAmount(sale.transferAmountMinor, sale.currency)}</dd></div>
                                </dl>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'refunds' && supportRefunds !== undefined && (
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-serif font-bold text-foreground">Refund review</h2>
              <p className="text-sm text-muted-foreground mt-1">Check the order and fulfillment state before approving money movement.</p>
            </div>
            {isSupportRefundsLoading ? (
              <div className="h-32 bg-card rounded-2xl border border-border animate-pulse" />
            ) : supportRefunds.length === 0 ? (
              <div className="text-center py-16 bg-card border border-border rounded-3xl">
                <CheckCircle2 className="w-12 h-12 text-primary mx-auto mb-4" />
                <h3 className="text-lg font-bold text-foreground">No pending refund requests</h3>
              </div>
            ) : (
              <div className="space-y-4">
                {supportRefunds.map((refund) => (
                  <div key={refund.id} className="bg-card border border-border rounded-2xl p-5 space-y-4">
                    <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                      <div>
                        <p className="font-bold text-foreground">{refund.order.description}</p>
                        <p className="text-sm text-muted-foreground mt-1">
                          Order #{refund.orderId} · {format(new Date(refund.order.createdAt), "MMM d, yyyy")} · Fulfillment: {refund.fulfillmentStatus}
                        </p>
                        <p className="text-sm text-foreground mt-3">Customer reason: {refund.reason}</p>
                        {refund.denialReason && <p className="text-sm text-destructive mt-2">Denial reason: {refund.denialReason}</p>}
                        {refund.reviewedAt && (
                          <p className="text-xs text-muted-foreground mt-2">
                            Reviewed {format(new Date(refund.reviewedAt), "MMM d, yyyy")} by {refund.reviewedByUserId}
                          </p>
                        )}
                      </div>
                      <div className="sm:text-right">
                        <p className="text-xl font-bold text-foreground">{formatMinorAmount(refund.amountMinor, refund.currency)}</p>
                        <p className="text-xs text-muted-foreground">of {formatMinorAmount(refund.order.amountMinor, refund.order.currency)}</p>
                      </div>
                    </div>
                    <div className="flex flex-wrap items-center gap-2">
                      <StatusBadge status={refund.status} />
                      {(refund.status === "pending" || refund.canRetry) && (
                        <button
                          onClick={() => handleRefundDecision(refund.id, "approve")}
                          disabled={decideRefund.isPending}
                          className="px-4 py-2 bg-primary text-primary-foreground font-bold rounded-xl disabled:opacity-50"
                        >
                          {refund.status === "pending" ? "Approve refund" : "Retry provider refund"}
                        </button>
                      )}
                      {refund.status === "pending" && (
                        <button
                          onClick={() => handleRefundDecision(refund.id, "deny")}
                          disabled={decideRefund.isPending}
                          className="px-4 py-2 bg-secondary text-foreground font-bold rounded-xl border border-border disabled:opacity-50"
                        >
                          Deny with reason
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}