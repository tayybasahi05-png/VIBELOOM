import { useListProducts } from "@workspace/api-client-react";
import { Link } from "wouter";
import { Star } from "lucide-react";

export function Market() {
  const { data: products, isLoading, error } = useListProducts({});

  if (isLoading) {
    return (
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 animate-pulse">
        {[1, 2, 3, 4, 5, 6].map(i => (
          <div key={i} className="bg-card rounded-2xl aspect-[3/4] border border-border" />
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-destructive/10 text-destructive p-6 rounded-3xl text-center border border-destructive/20">
        <p className="font-semibold">Failed to load market</p>
      </div>
    );
  }

  return (
    <div className="w-full">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-serif text-foreground font-bold mb-1">Market</h1>
          <p className="text-muted-foreground">Discover unique products and services.</p>
        </div>
        <span className="rounded-full border border-border bg-secondary px-3 py-1.5 text-xs font-semibold text-muted-foreground">
          Provider-gated checkout
        </span>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-6">
        {products?.map(product => (
          <Link key={product.id} href={`/market/${product.id}`} className="group relative bg-card border border-border rounded-3xl overflow-hidden flex flex-col transition-all hover-elevate">
            <div className="aspect-square bg-secondary relative overflow-hidden">
              <img 
                src={product.imageUrl} 
                alt={product.name}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <div className="absolute top-3 right-3 bg-background/90 backdrop-blur-sm px-2.5 py-1 rounded-full text-xs font-bold text-foreground border border-border/50">
                {product.availability === "in_stock" ? "Available" : "Sold Out"}
              </div>
            </div>
            
            <div className="p-4 flex flex-col flex-1">
              <div className="flex items-start justify-between gap-2 mb-2">
                <h3 className="font-bold text-foreground leading-tight line-clamp-2">
                  {product.name}
                </h3>
              </div>
              <div className="mt-auto pt-2 flex items-end justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">{product.currency}</p>
                  <p className="font-serif text-xl font-bold text-primary">${product.price.toFixed(2)}</p>
                </div>
                <div className="flex items-center gap-1 text-sm font-medium text-foreground bg-secondary px-2 py-1 rounded-lg">
                  <Star className="w-3.5 h-3.5 fill-accent text-accent" />
                  {product.rating}
                </div>
              </div>
            </div>
          </Link>
        ))}
      </div>
      
      {products?.length === 0 && (
        <div className="text-center py-20 text-muted-foreground">
          No products found.
        </div>
      )}
    </div>
  );
}