import { useGetSession } from "@workspace/api-client-react";
import { Link } from "wouter";
import { Settings, MapPin, Calendar, Grid, BriefcaseBusiness, Store, Sparkles, Wallet, Image, Megaphone, Shield, Bell, Languages, Ban, LockKeyhole, Trash2, ChevronRight } from "lucide-react";

const PROFILE_AREAS = [
  { label: "Creator profile", detail: "Content, live history, audience and earnings", icon: Sparkles },
  { label: "Freelancer profile", detail: "Skills, portfolio, services, pricing, projects and reviews", icon: BriefcaseBusiness },
  { label: "Business profile", detail: "Products, services, offers, promotions and advertising", icon: Store },
];

const ACCOUNT_LINKS = [
  { label: "Wallet and earnings", path: "/wallet", icon: Wallet },
];

const UPCOMING_ACCOUNT_AREAS = [
  { label: "Saved media", icon: Image },
  { label: "Advertising", icon: Megaphone },
];

const SETTINGS_AREAS = [
  { label: "Account and security", icon: LockKeyhole },
  { label: "Privacy and data controls", icon: Shield },
  { label: "Notifications and calls", icon: Bell },
  { label: "Language and accessibility", icon: Languages },
  { label: "Blocked users", icon: Ban },
  { label: "Account deletion", icon: Trash2 },
];

export function Profile() {
  const { data: session, isLoading } = useGetSession();

  if (isLoading) {
    return <div className="space-y-4 animate-pulse">
      <div className="h-48 bg-card rounded-3xl" />
      <div className="h-20 bg-card rounded-3xl" />
    </div>;
  }

  const user = session?.user;

  if (!user) return null;

  return (
    <div className="w-full space-y-6">
      <div className="bg-card rounded-3xl border border-border overflow-hidden">
        <div className="h-32 bg-secondary/50 relative">
          <div className="absolute -bottom-12 left-6">
            {user.avatarUrl ? (
              <img src={user.avatarUrl} alt={user.name} className="w-24 h-24 rounded-full border-4 border-card object-cover bg-secondary" />
            ) : (
              <span className="flex h-24 w-24 items-center justify-center rounded-full border-4 border-card bg-secondary text-3xl font-bold text-foreground">
                {user.name.charAt(0).toUpperCase()}
              </span>
            )}
          </div>
        </div>
        <div className="pt-14 pb-6 px-6">
          <div>
            <div>
              <h1 className="text-2xl font-bold font-serif text-foreground">{user.name}</h1>
              <p className="text-muted-foreground">{user.handle}</p>
            </div>
          </div>
          
          <div className="flex gap-4 mt-4 text-sm text-muted-foreground">
            {user.location && (
              <div className="flex items-center gap-1">
                <MapPin className="w-4 h-4" />
                {user.location}
              </div>
            )}
            <div className="flex items-center gap-1">
              <Calendar className="w-4 h-4" />
              Joined Recently
            </div>
          </div>
        </div>
      </div>

      <section className="space-y-3">
        <div>
          <h2 className="text-xl font-serif font-bold">Professional profiles</h2>
          <p className="text-sm text-muted-foreground">Create or manage how you work and earn on VibeLoom.</p>
        </div>
        <div className="grid gap-3 md:grid-cols-3">
          {PROFILE_AREAS.map(({ label, detail, icon: Icon }) => (
            <div key={label} className="rounded-2xl border border-border bg-card p-5">
              <Icon className="mb-4 h-6 w-6 text-primary" />
              <h3 className="font-bold">{label}</h3>
              <p className="mt-1 min-h-10 text-xs leading-relaxed text-muted-foreground">{detail}</p>
              <span className="mt-4 inline-flex rounded-full bg-secondary px-3 py-1 text-xs font-semibold text-muted-foreground">Coming soon</span>
            </div>
          ))}
        </div>
      </section>

      <section className="grid gap-6 md:grid-cols-2">
        <div className="rounded-3xl border border-border bg-card p-5">
          <h2 className="mb-3 font-serif text-xl font-bold">Your activity</h2>
          <div className="space-y-1">
            {ACCOUNT_LINKS.map(({ label, path, icon: Icon }) => (
              <Link key={path} href={path} className="flex items-center gap-3 rounded-xl p-3 font-semibold hover:bg-secondary">
                <Icon className="h-5 w-5 text-primary" />
                <span className="flex-1">{label}</span>
                <ChevronRight className="h-4 w-4 text-muted-foreground" />
              </Link>
            ))}
            {UPCOMING_ACCOUNT_AREAS.map(({ label, icon: Icon }) => (
              <div key={label} className="flex items-center gap-3 rounded-xl p-3 text-muted-foreground">
                <Icon className="h-5 w-5" />
                <span className="flex-1 font-semibold">{label}</span>
                <span className="text-xs">Soon</span>
              </div>
            ))}
          </div>
        </div>
        <div className="rounded-3xl border border-border bg-card p-5">
          <div className="mb-3 flex items-center gap-2">
            <Settings className="h-5 w-5 text-primary" />
            <h2 className="font-serif text-xl font-bold">Settings</h2>
          </div>
          <div className="space-y-1">
            {SETTINGS_AREAS.map(({ label, icon: Icon }) => (
              <div key={label} className="flex items-center gap-3 rounded-xl p-3 text-sm">
                <Icon className="h-4 w-4 text-muted-foreground" />
                <span className="flex-1 font-medium">{label}</span>
                <span className="text-xs text-muted-foreground">Soon</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="col-span-1 space-y-6">
          <div className="bg-card rounded-3xl border border-border p-6">
            <h2 className="font-bold mb-4 font-serif text-lg">About</h2>
            <p className="text-sm text-muted-foreground mb-4">No bio added yet.</p>
            
            <div className="space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Followers</span>
                <span className="font-bold">0</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Following</span>
                <span className="font-bold">0</span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="col-span-1 md:col-span-2 space-y-4">
          <h2 className="font-serif text-xl font-bold">Posts</h2>
          
          <div className="bg-card rounded-3xl border border-border p-12 text-center">
            <div className="w-16 h-16 bg-secondary rounded-full flex items-center justify-center mx-auto mb-4">
              <Grid className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="font-bold text-lg mb-2">No posts yet</h3>
            <p className="text-muted-foreground text-sm mb-6 max-w-md mx-auto">
              When you post updates, photos, or items for sale, they'll show up here on your profile.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
