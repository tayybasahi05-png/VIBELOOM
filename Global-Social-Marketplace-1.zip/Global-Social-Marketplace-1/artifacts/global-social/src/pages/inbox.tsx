import { useListConversations } from "@workspace/api-client-react";
import { Link } from "wouter";
import { Search, AlertCircle, Loader2 } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { useMemo, useState } from "react";
import { VibeLoomAiMark } from "@/components/app-ai/mascot";

function formatConversationTime(value: string) {
  const date = new Date(value);
  return Number.isNaN(date.getTime())
    ? value
    : formatDistanceToNow(date, { addSuffix: true });
}

export function Inbox() {
  const [query, setQuery] = useState("");
  const {
    data: conversations,
    isLoading,
    isError,
    isFetching,
    refetch,
  } = useListConversations();
  const filteredConversations = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    if (!normalized) return conversations ?? [];
    return (conversations ?? []).filter((conversation) =>
      `${conversation.participant.name} ${conversation.participant.handle} ${conversation.preview}`
        .toLowerCase()
        .includes(normalized),
    );
  }, [conversations, query]);

  return (
    <div className="w-full h-[calc(100vh-120px)] md:h-[calc(100vh-64px)] flex flex-col">
      <div className="mb-6">
        <h1 className="text-3xl font-serif text-foreground font-bold">Messages</h1>
      </div>

      <div className="relative mb-6">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
        <input 
          type="text"
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Search conversations..."
          className="w-full bg-card border border-border rounded-2xl py-4 pl-12 pr-4 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
        />
      </div>

      <div className="flex-1 overflow-y-auto space-y-2 pb-4">
        
        {!query && (
          <Link 
            href="/inbox/app-ai" 
            className="flex items-center gap-4 p-4 mb-5 bg-card border-2 border-primary/20 rounded-2xl hover:border-primary/40 hover:bg-primary/5 transition-all group shadow-sm"
          >
            <div className="relative">
              <VibeLoomAiMark className="h-14 w-14 transition-transform duration-300 group-hover:-rotate-3 group-hover:scale-105" />
              <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-card rounded-full flex items-center justify-center">
                <div className="w-3 h-3 bg-primary rounded-full animate-pulse" />
              </div>
            </div>
            
            <div className="flex-1 min-w-0">
              <h3 className="font-bold text-foreground text-lg mb-0.5">VibeLoom App AI</h3>
              <p className="text-sm font-medium text-primary/80 truncate">
                Ask questions or contact support
              </p>
            </div>
          </Link>
        )}

        {isLoading ? (
          <div className="space-y-2 animate-pulse">
            {[1,2,3,4].map(i => (
              <div key={i} className="h-24 bg-card rounded-2xl border border-border" />
            ))}
          </div>
        ) : isError ? (
          <div className="flex min-h-56 flex-col items-center justify-center rounded-2xl border border-destructive/20 bg-destructive/10 p-6 text-center">
            <AlertCircle className="mb-3 h-8 w-8 text-destructive" />
            <h2 className="font-bold text-foreground">Messages could not be loaded</h2>
            <p className="mt-1 text-sm text-muted-foreground">Check your connection and try again.</p>
            <button
              type="button"
              onClick={() => refetch()}
              disabled={isFetching}
              className="mt-4 inline-flex min-h-11 items-center gap-2 rounded-xl bg-primary px-4 py-2 font-bold text-primary-foreground disabled:opacity-60"
            >
              {isFetching && <Loader2 className="h-4 w-4 animate-spin" />}
              Retry
            </button>
          </div>
        ) : (
          filteredConversations.map((conv) => (
            <Link 
              key={conv.id} 
              href={`/inbox/${conv.id}`}
              className="flex items-start gap-4 p-4 bg-card border border-border rounded-2xl hover:bg-secondary/50 transition-colors group"
            >
              <div className="relative">
                <img 
                  src={conv.participant.avatarUrl} 
                  alt={conv.participant.name} 
                  className="w-14 h-14 rounded-full object-cover bg-secondary"
                />
                {conv.online && (
                  <div className="absolute bottom-0 right-0 w-4 h-4 bg-primary border-2 border-card rounded-full" />
                )}
              </div>
              
              <div className="flex-1 min-w-0 pt-1">
                <div className="flex items-center justify-between mb-1">
                  <h3 className="font-bold text-foreground truncate pr-2">{conv.participant.name}</h3>
                  <span className="text-xs text-muted-foreground whitespace-nowrap">
                    {formatConversationTime(conv.updatedAt)}
                  </span>
                </div>
                <p className={`text-sm truncate ${conv.unreadCount > 0 ? 'text-foreground font-semibold' : 'text-muted-foreground'}`}>
                  {conv.preview}
                </p>
              </div>
              
              {conv.unreadCount > 0 && (
                <div className="bg-accent text-accent-foreground w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold shrink-0 self-center">
                  {conv.unreadCount}
                </div>
              )}
            </Link>
          ))
        )}
        
        {!isLoading && !isError && filteredConversations.length === 0 && (
          <div className="text-center py-20 text-muted-foreground">
            {query ? "No conversations match your search." : "No messages yet."}
          </div>
        )}
      </div>
    </div>
  );
}