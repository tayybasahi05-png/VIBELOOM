import { useState } from "react";
import { getSearchQueryKey, useSearch } from "@workspace/api-client-react";
import { Search as SearchIcon, ArrowRight } from "lucide-react";
import type { SearchType } from "@workspace/api-client-react";
import { useDebounce } from "../lib/use-debounce";
import { Link } from "wouter";

export function Search() {
  const [query, setQuery] = useState("");
  const debouncedQuery = useDebounce(query, 500);
  const [type, setType] = useState<SearchType>("all");

  const { data: results, isLoading } = useSearch({ q: debouncedQuery, type }, {
    query: {
      enabled: debouncedQuery.length > 0,
      queryKey: getSearchQueryKey({ q: debouncedQuery, type }),
    }
  });

  const types: { label: string, value: SearchType }[] = [
    { label: "All", value: "all" },
    { label: "People", value: "people" },
    { label: "Products", value: "products" },
    { label: "Posts", value: "posts" },
  ];

  return (
    <div className="w-full min-h-[calc(100vh-100px)] flex flex-col">
      <h1 className="text-3xl font-serif text-foreground font-bold mb-6">Search</h1>
      
      <div className="sticky top-0 z-10 bg-background/95 backdrop-blur pb-4 space-y-4">
        <div className="relative">
          <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-6 h-6 text-muted-foreground" />
          <input 
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search VibeLoom..."
            className="w-full bg-card border-2 border-border rounded-2xl py-4 pl-14 pr-4 text-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary focus:ring-4 focus:ring-primary/20 transition-all shadow-sm"
          />
        </div>

        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
          {types.map(t => (
            <button
              key={t.value}
              onClick={() => setType(t.value)}
              className={`px-5 py-2 rounded-xl font-medium whitespace-nowrap transition-all ${
                type === t.value 
                  ? "bg-foreground text-background" 
                  : "bg-card border border-border text-foreground hover:bg-secondary"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 py-4">
        {isLoading && debouncedQuery.length > 0 ? (
          <div className="space-y-4 animate-pulse">
            {[1,2,3].map(i => (
              <div key={i} className="flex gap-4 p-4 border border-border rounded-2xl bg-card">
                <div className="w-16 h-16 rounded-xl bg-secondary" />
                <div className="flex-1 space-y-2 py-2">
                  <div className="h-4 w-1/3 bg-secondary rounded" />
                  <div className="h-3 w-1/2 bg-secondary rounded" />
                </div>
              </div>
            ))}
          </div>
        ) : debouncedQuery.length === 0 ? (
          <div className="text-center py-20 text-muted-foreground">
            <SearchIcon className="w-12 h-12 mx-auto mb-4 opacity-20" />
            <p className="text-lg font-medium">What are you looking for?</p>
            <p className="text-sm mt-1">Search people, creators, products, posts, and ideas.</p>
          </div>
        ) : results?.results.length === 0 ? (
          <div className="text-center py-20 text-muted-foreground">
            No results found for "{debouncedQuery}".
          </div>
        ) : (
          <div className="space-y-3">
            {results?.results.map(res => {
              const card = (
                <>
                <img 
                  src={res.imageUrl} 
                  alt={res.title}
                  className={`w-16 h-16 object-cover bg-secondary ${res.kind === "person" ? "rounded-full" : "rounded-xl"}`}
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-[10px] uppercase font-bold tracking-widest text-primary bg-primary/10 px-2 py-0.5 rounded-full">
                      {res.kind}
                    </span>
                  </div>
                  <h3 className="font-bold text-foreground truncate">{res.title}</h3>
                  <p className="text-sm text-muted-foreground truncate">{res.subtitle}</p>
                </div>
                {(res.kind === "product" || res.kind === "person") && (
                  <ArrowRight className="w-5 h-5 text-muted-foreground group-hover:text-foreground opacity-0 group-hover:opacity-100 transition-all -translate-x-2 group-hover:translate-x-0" />
                )}
                </>
              );
              return res.kind === "product" || res.kind === "person" ? (
                <Link
                  key={res.id}
                  href={res.kind === "product" ? `/market/${res.id}` : `/profile/${res.id}`}
                  className="group flex items-center gap-4 rounded-2xl border border-border bg-card p-4 transition-colors hover:bg-secondary/50"
                >
                  {card}
                </Link>
              ) : (
                <div key={`${res.kind}-${res.id}`} className="flex items-center gap-4 rounded-2xl border border-border bg-card p-4">
                  {card}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}