import { useListNotifications } from "@workspace/api-client-react";
import { Bell, Heart, MessageCircle, UserPlus, ShoppingBag, Settings } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { Link } from "wouter";

function formatNotificationTime(value: string) {
  const date = new Date(value);
  return Number.isNaN(date.getTime())
    ? value
    : formatDistanceToNow(date, { addSuffix: true });
}

export function Notifications() {
  const { data: notifications, isLoading } = useListNotifications();

  const getIcon = (kind: string) => {
    switch (kind) {
      case "like": return <Heart className="w-5 h-5 text-destructive fill-destructive" />;
      case "comment": return <MessageCircle className="w-5 h-5 text-primary" />;
      case "follow": return <UserPlus className="w-5 h-5 text-accent" />;
      case "purchase": return <ShoppingBag className="w-5 h-5 text-green-600" />;
      default: return <Bell className="w-5 h-5 text-muted-foreground" />;
    }
  };

  return (
    <div className="w-full pb-10">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-serif text-foreground font-bold">Notifications</h1>
        <button className="p-3 bg-card border border-border rounded-full hover:bg-secondary transition-colors">
          <Settings className="w-5 h-5 text-foreground" />
        </button>
      </div>

      {isLoading ? (
        <div className="space-y-2 animate-pulse">
          {[1,2,3,4,5].map(i => (
            <div key={i} className="h-20 bg-card rounded-2xl border border-border" />
          ))}
        </div>
      ) : notifications?.length === 0 ? (
        <div className="text-center py-20 text-muted-foreground">
          <Bell className="w-12 h-12 mx-auto mb-4 opacity-20" />
          <p className="text-lg font-medium">All caught up!</p>
          <p className="text-sm">You have no new notifications.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {notifications?.map(notif => {
            const content = (
              <>
                {!notif.read && (
                  <div className="absolute left-0 top-0 bottom-0 w-1 bg-primary" />
                )}

                <div className="shrink-0 w-12 h-12 rounded-full bg-secondary flex items-center justify-center border border-border">
                  {getIcon(notif.kind)}
                </div>

                <div className="flex-1 min-w-0 pt-0.5">
                  <div className="flex items-start justify-between gap-4 mb-1">
                    <h3 className={`text-base leading-tight ${notif.read ? 'text-foreground font-medium' : 'text-foreground font-bold'}`}>
                      {notif.title}
                    </h3>
                    <span className="text-xs font-medium text-muted-foreground whitespace-nowrap pt-1">
                      {formatNotificationTime(notif.createdAt)}
                    </span>
                  </div>
                  <p className={`text-sm leading-relaxed ${notif.read ? 'text-muted-foreground' : 'text-foreground/90'}`}>
                    {notif.body}
                  </p>
                </div>
              </>
            );
            const className = `flex gap-4 p-5 rounded-3xl border transition-colors ${
              notif.read
                ? "bg-card border-border hover:bg-secondary/50"
                : "bg-background border-primary/20 shadow-sm relative overflow-hidden"
            }`;

            return notif.conversationId ? (
              <Link
                key={notif.id}
                href={`/inbox/${notif.conversationId}`}
                className={className}
              >
                {content}
              </Link>
            ) : (
              <div
              key={notif.id}
                className={className}
              >
                {content}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}