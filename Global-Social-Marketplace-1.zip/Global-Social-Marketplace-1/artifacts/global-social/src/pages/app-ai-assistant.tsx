import { useState, useEffect, useRef } from "react";
import { useLocation } from "wouter";
import { 
  useListAppAiConversations, 
  useCreateAppAiConversation, 
  useGetAppAiConversation, 
  useSendAppAiMessage,
  useDeleteAppAiConversation,
  type AppAiConversation,
} from "@workspace/api-client-react";
import { getGetAppAiConversationQueryKey, getListAppAiConversationsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { AlertCircle, Send, History, Plus, Loader2, ArrowLeft, LifeBuoy, RotateCcw, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { AppAiMessageBubble } from "../components/app-ai/message-bubble";
import { SupportTicketModal } from "../components/app-ai/support-ticket-modal";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger, SheetDescription } from "@/components/ui/sheet";
import { formatDistanceToNow } from "date-fns";
import { VibeLoomAiMark } from "@/components/app-ai/mascot";

const SUGGESTED_QUESTIONS = [
  "How do I send a Gift in Live?",
  "How do I buy Coins?",
  "What can I do in Market?",
  "Help me fix an Inbox problem.",
];

function sendErrorMessage(error: unknown) {
  const status =
    error && typeof error === "object" && "status" in error
      ? Number((error as { status?: unknown }).status)
      : 0;
  if (status === 401) return "Your session has expired. Sign in again, then retry.";
  if (status === 429) return "You have sent several requests quickly. Wait a minute, then retry.";
  if (status === 504) return "The assistant took too long to respond. Your message was not saved.";
  if (status >= 500) return "The assistant is temporarily unavailable. Your message was not saved.";
  return "The message could not be sent. Check your connection and retry.";
}

export function AppAiAssistant() {
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  
  const [activeConversationId, setActiveConversationId] = useState<number | null>(null);
  const [inputValue, setInputValue] = useState("");
  const [isSupportModalOpen, setIsSupportModalOpen] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [pendingPrompt, setPendingPrompt] = useState<string | null>(null);
  const [lastFailedPrompt, setLastFailedPrompt] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const attemptedInitialCreate = useRef(false);
  
  // Queries
  const {
    data: conversations,
    isLoading: isListLoading,
    isError: isListError,
    isFetching: isListFetching,
    refetch: refetchList,
  } = useListAppAiConversations();
  const { 
    data: activeConversation, 
    isLoading: isConversationLoading,
    isError: isConversationError
  } = useGetAppAiConversation(activeConversationId!, { 
    query: { enabled: !!activeConversationId, queryKey: getGetAppAiConversationQueryKey(activeConversationId!) } 
  });
  
  // Mutations
  const createConversation = useCreateAppAiConversation();
  const sendMessage = useSendAppAiMessage();
  const deleteConversation = useDeleteAppAiConversation();

  // Initialization: auto-select or create conversation
  useEffect(() => {
    if (!isListLoading && conversations !== undefined && activeConversationId === null) {
      if (conversations.length > 0) {
        // Pick the most recently updated
        const sorted = [...conversations].sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
        setActiveConversationId(sorted[0].id);
      } else if (!attemptedInitialCreate.current) {
          attemptedInitialCreate.current = true;
          createConversation.mutate({ data: { title: "New Conversation" } }, {
            onSuccess: (newConv) => {
              queryClient.invalidateQueries({ queryKey: getListAppAiConversationsQueryKey() });
              setActiveConversationId(newConv.id);
            },
          });
      }
    }
  }, [isListLoading, conversations, activeConversationId, createConversation, queryClient]);

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [activeConversation?.messages, sendMessage.isPending]);

  const handleSend = (content: string) => {
    if (!content.trim() || !activeConversationId) return;
    const prompt = content.trim();
    setInputValue("");
    setPendingPrompt(prompt);
    setLastFailedPrompt(null);
    sendMessage.reset();

    sendMessage.mutate(
      { conversationId: activeConversationId, data: { content: prompt } },
      {
        onSuccess: () => {
          setPendingPrompt(null);
          queryClient.invalidateQueries({ queryKey: getGetAppAiConversationQueryKey(activeConversationId) });
          queryClient.invalidateQueries({ queryKey: getListAppAiConversationsQueryKey() });
        },
        onError: () => {
          setPendingPrompt(null);
          setLastFailedPrompt(prompt);
        },
      }
    );
  };

  const handleStartNew = () => {
    createConversation.mutate(
      { data: { title: "New Conversation" } },
      {
        onSuccess: (newConv) => {
          queryClient.invalidateQueries({ queryKey: getListAppAiConversationsQueryKey() });
          setActiveConversationId(newConv.id);
          setLastFailedPrompt(null);
          setIsHistoryOpen(false);
        }
      }
    );
  };

  const handleDeleteConversation = (conversation: AppAiConversation) => {
    if (!window.confirm(`Delete "${conversation.title}" and its APP AI history? This cannot be undone.`)) {
      return;
    }
    deleteConversation.mutate(
      { conversationId: conversation.id },
      {
        onSuccess: () => {
          const remaining = (conversations ?? []).filter((item) => item.id !== conversation.id);
          queryClient.setQueryData(getListAppAiConversationsQueryKey(), remaining);
          queryClient.removeQueries({
            queryKey: getGetAppAiConversationQueryKey(conversation.id),
          });
          if (activeConversationId === conversation.id) {
            setActiveConversationId(remaining[0]?.id ?? null);
            setLastFailedPrompt(null);
            attemptedInitialCreate.current = remaining.length > 0;
          }
          setIsHistoryOpen(false);
        },
      },
    );
  };

  const isInitializing = activeConversationId === null || isListLoading || (activeConversationId && isConversationLoading && !activeConversation);

  return (
    <div className="flex flex-col h-[calc(100vh-120px)] md:h-[calc(100vh-64px)] w-full max-w-4xl mx-auto bg-background rounded-b-2xl overflow-hidden relative border-x border-border shadow-sm">
      {/* Header */}
      <header className="flex items-center justify-between px-4 py-4 md:px-6 bg-card border-b border-border z-10 shrink-0">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" className="md:hidden -ml-2 rounded-xl" onClick={() => setLocation("/inbox")}>
            <ArrowLeft className="w-6 h-6 text-foreground" />
          </Button>
          <div className="flex items-center gap-3.5">
             <div className="relative shrink-0">
               <VibeLoomAiMark className="h-12 w-12" />
              <div className="absolute top-0 right-0 w-3 h-3 bg-primary rounded-full border-2 border-card" />
            </div>
            <div>
              <h1 className="font-serif font-bold text-foreground text-xl md:text-2xl leading-tight mb-0.5">VibeLoom App AI</h1>
              <p className="text-sm text-primary font-bold">Product help and support</p>
            </div>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          {activeConversationId && (
            <Button 
              variant="secondary"
              className="hidden sm:flex text-sm font-bold gap-2 rounded-xl py-5"
              onClick={() => setIsSupportModalOpen(true)}
            >
              <LifeBuoy className="w-4 h-4 text-primary" />
              Contact Support
            </Button>
          )}
          
          <Sheet open={isHistoryOpen} onOpenChange={setIsHistoryOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="rounded-xl w-12 h-12 hover:bg-secondary">
                <History className="w-5 h-5 text-foreground" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[320px] sm:w-[400px] p-0 flex flex-col bg-background">
              <SheetHeader className="p-6 border-b border-border text-left bg-card">
                <SheetTitle className="font-serif text-3xl text-foreground">History</SheetTitle>
                <SheetDescription className="text-base text-muted-foreground">View your past conversations with Guide.</SheetDescription>
              </SheetHeader>
              <div className="p-4 border-b border-border bg-card/50">
                <Button onClick={handleStartNew} disabled={createConversation.isPending} className="w-full bg-primary text-primary-foreground font-bold rounded-xl py-6 gap-2 text-base hover:bg-primary/90 transition-colors">
                  {createConversation.isPending ? <Loader2 className="w-5 h-5 animate-spin" /> : <Plus className="w-5 h-5" />}
                  Start New Chat
                </Button>
              </div>
              <ScrollArea className="flex-1">
                <div className="p-4 flex flex-col gap-3">
                  {isListLoading ? (
                    <div className="py-12 flex justify-center"><Loader2 className="w-8 h-8 animate-spin text-muted-foreground" /></div>
                  ) : conversations?.length === 0 ? (
                    <div className="text-center py-12 text-muted-foreground font-medium">No history found.</div>
                  ) : (
                    conversations?.map((conv) => (
                      <div
                        key={conv.id}
                        className={`text-left p-5 rounded-2xl border-2 transition-all ${
                          conv.id === activeConversationId 
                            ? "bg-primary/5 border-primary/30" 
                            : "bg-card border-border hover:border-primary/20 hover:bg-secondary/50"
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => { setActiveConversationId(conv.id); setLastFailedPrompt(null); setIsHistoryOpen(false); }}
                            className="min-w-0 flex-1 text-left"
                          >
                            <h4 className={`font-bold text-base truncate mb-1.5 ${conv.id === activeConversationId ? 'text-primary' : 'text-foreground'}`}>
                              {conv.title || "Conversation"}
                            </h4>
                            <p className="text-sm text-muted-foreground font-medium">
                              {formatDistanceToNow(new Date(conv.updatedAt), { addSuffix: true })}
                            </p>
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteConversation(conv)}
                            disabled={deleteConversation.isPending}
                            className="rounded-xl p-2 text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
                            aria-label={`Delete ${conv.title}`}
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </ScrollArea>
            </SheetContent>
          </Sheet>
        </div>
      </header>

      {/* Main Chat Area */}
      <div className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8 flex flex-col relative bg-background noise-bg custom-scrollbar">
        {isListError || createConversation.isError ? (
          <div className="flex-1 flex flex-col items-center justify-center text-center p-6 max-w-md mx-auto">
            <div className="w-20 h-20 bg-destructive/10 text-destructive rounded-full flex items-center justify-center mb-5">
              <AlertCircle className="w-10 h-10" />
            </div>
            <h2 className="text-3xl font-serif font-bold mb-3 text-foreground">APP AI could not start</h2>
            <p className="text-muted-foreground mb-8 text-lg">
              Check your connection. If you signed out in another tab, sign in again.
            </p>
            <Button
              onClick={() => {
                attemptedInitialCreate.current = false;
                createConversation.reset();
                refetchList();
              }}
              disabled={isListFetching}
              className="py-6 px-8 rounded-xl font-bold text-lg"
            >
              {isListFetching && <Loader2 className="mr-2 h-5 w-5 animate-spin" />}
              Retry
            </Button>
          </div>
        ) : isInitializing ? (
          <div className="flex-1 flex flex-col items-center justify-center text-muted-foreground gap-5">
            <Loader2 className="w-10 h-10 animate-spin text-primary" />
            <p className="font-bold tracking-wide uppercase text-sm animate-pulse text-primary/70">Waking up Guide...</p>
          </div>
        ) : isConversationError ? (
          <div className="flex-1 flex flex-col items-center justify-center text-center p-6 max-w-md mx-auto">
            <div className="w-20 h-20 bg-destructive/10 text-destructive rounded-full flex items-center justify-center mb-5">
              <LifeBuoy className="w-10 h-10" />
            </div>
            <h2 className="text-3xl font-serif font-bold mb-3 text-foreground">Something went wrong</h2>
            <p className="text-muted-foreground mb-8 text-lg">We couldn't load this conversation history. Please check your connection.</p>
            <Button onClick={() => queryClient.invalidateQueries({ queryKey: getGetAppAiConversationQueryKey(activeConversationId!) })} className="py-6 px-8 rounded-xl font-bold text-lg">
              Retry Connection
            </Button>
          </div>
        ) : (
          <div className="flex-1 flex flex-col justify-end w-full mx-auto">
            {activeConversation?.messages.length === 0 ? (
              <div className="flex-1 flex flex-col items-center justify-center mb-12">
                <div className="mb-8 rotate-3 transform transition-transform duration-500 hover:rotate-0">
                  <VibeLoomAiMark className="h-28 w-28 shadow-lg" />
                </div>
                <h2 className="text-4xl md:text-5xl font-serif font-bold text-foreground mb-4 text-center">Ask VibeLoom App AI</h2>
                <p className="text-muted-foreground text-center max-w-lg text-lg leading-relaxed font-medium">
                  Get concise help with VibeLoom's available features, payments, troubleshooting, and support.
                </p>
              </div>
            ) : (
              <div className="flex flex-col pb-4 max-w-3xl mx-auto w-full">
                {activeConversation?.messages.map((msg) => (
                  <AppAiMessageBubble key={msg.id} message={msg} conversationId={activeConversationId!} />
                ))}
                {pendingPrompt && (
                  <div className="mb-6 flex w-full justify-end">
                    <div dir="auto" className="max-w-[90%] rounded-3xl rounded-tr-sm bg-primary p-5 text-[15px] leading-relaxed text-primary-foreground shadow-sm md:max-w-[75%]">
                      {pendingPrompt}
                    </div>
                  </div>
                )}
                
                {sendMessage.isPending && (
                  <div className="flex w-full justify-start mb-6">
                    <div className="bg-card border-2 border-border rounded-3xl rounded-tl-sm p-6 shadow-sm">
                      <div className="flex gap-2 items-center h-6">
                        <div className="w-2.5 h-2.5 rounded-full bg-primary/40 animate-bounce" style={{ animationDelay: "0ms" }} />
                        <div className="w-2.5 h-2.5 rounded-full bg-primary/40 animate-bounce" style={{ animationDelay: "150ms" }} />
                        <div className="w-2.5 h-2.5 rounded-full bg-primary/40 animate-bounce" style={{ animationDelay: "300ms" }} />
                      </div>
                    </div>
                  </div>
                )}
                {sendMessage.isError && lastFailedPrompt && (
                  <div className="mb-6 rounded-2xl border border-destructive/20 bg-destructive/10 p-4">
                    <div className="flex items-start gap-3">
                      <AlertCircle className="mt-0.5 h-5 w-5 shrink-0 text-destructive" />
                      <div className="min-w-0 flex-1">
                        <p className="font-bold text-foreground">Response failed</p>
                        <p className="mt-1 text-sm text-muted-foreground">
                          {sendErrorMessage(sendMessage.error)}
                        </p>
                      </div>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => handleSend(lastFailedPrompt)}
                        className="shrink-0 gap-2"
                      >
                        <RotateCcw className="h-4 w-4" />
                        Retry
                      </Button>
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>
            )}
          </div>
        )}
      </div>

      {/* Input Area */}
      {!isInitializing && !isConversationError && (
        <div className="p-4 md:p-6 bg-card border-t border-border shrink-0 z-10 shadow-[0_-10px_40px_rgba(0,0,0,0.02)]">
          <div className="max-w-3xl mx-auto">
            {activeConversation?.messages.length === 0 && (
              <div className="flex flex-wrap gap-2.5 mb-5 justify-center">
                {SUGGESTED_QUESTIONS.map((q, i) => (
                  <button
                    key={i}
                    onClick={() => handleSend(q)}
                    disabled={sendMessage.isPending}
                    className="text-sm font-bold text-primary bg-primary/5 hover:bg-primary/10 border border-primary/20 rounded-full px-5 py-3 transition-colors text-left"
                  >
                    {q}
                  </button>
                ))}
              </div>
            )}
            
            <form 
              onSubmit={(e) => { e.preventDefault(); handleSend(inputValue); }}
              className="relative flex items-center shadow-sm rounded-full bg-background group focus-within:ring-2 focus-within:ring-primary focus-within:ring-offset-2 focus-within:ring-offset-background transition-all"
            >
              <Input
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                dir="auto"
                placeholder="Ask me anything..."
                disabled={sendMessage.isPending}
                className="w-full bg-transparent border-2 border-border rounded-full py-7 pl-6 pr-16 text-lg focus-visible:ring-0 focus-visible:ring-offset-0 shadow-none"
              />
              <Button 
                type="submit" 
                size="icon" 
                disabled={!inputValue.trim() || sendMessage.isPending}
                className="absolute right-2 rounded-full w-11 h-11 bg-primary text-primary-foreground disabled:opacity-50 hover:bg-primary/90 transition-all"
              >
                <Send className="w-5 h-5 ml-1" />
              </Button>
            </form>
            
            <div className="mt-4 flex justify-between items-center px-2">
              <span className="text-[11px] text-muted-foreground uppercase tracking-widest font-bold">VibeLoom AI Companion</span>
              <button 
                onClick={() => setIsSupportModalOpen(true)}
                className="text-[12px] font-bold text-primary/80 hover:text-primary transition-colors flex items-center gap-1.5 sm:hidden bg-primary/5 px-3 py-1.5 rounded-full"
              >
                <LifeBuoy className="w-3.5 h-3.5" />
                Support
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Support Ticket Modal */}
      {activeConversationId && (
        <SupportTicketModal
          conversationId={activeConversationId}
          open={isSupportModalOpen}
          onOpenChange={setIsSupportModalOpen}
        />
      )}
    </div>
  );
}
