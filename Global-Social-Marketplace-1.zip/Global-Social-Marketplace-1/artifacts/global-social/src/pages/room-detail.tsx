import { useState, useEffect, useRef } from "react";
import { useParams, Link } from "wouter";
import {
  useGetLiveRoom,
  useGetSession,
  useListGifts,
  useGetWallet,
  useListCoinPacks,
  useCreateCoinCheckout,
  useSendGift,
  useListSentGifts,
  useListReceivedGifts,
  useConfirmCoinCheckout,
  getGetLiveRoomQueryKey,
  getGetWalletQueryKey,
  getListSentGiftsQueryKey,
  getListReceivedGiftsQueryKey
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import {
  Heart,
  MessageCircle,
  Share2,
  MoreVertical,
  Gift,
  X,
  Coins,
  ChevronLeft,
  Users,
  AlertCircle,
  Flag,
  UserMinus
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { GiftPanel } from "@/components/gift-panel";

export function RoomDetail() {
  const params = useParams();
  const roomId = params.roomId!;
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [isGiftPanelOpen, setIsGiftPanelOpen] = useState(false);
  const checkoutConfirmationStarted = useRef(false);

  const { data: session } = useGetSession();
  const { data: room, isLoading: isLoadingRoom, error: roomError } = useGetLiveRoom(roomId, {
    query: { queryKey: getGetLiveRoomQueryKey(roomId), refetchInterval: 3000 }
  });
  const confirmCheckout = useConfirmCoinCheckout({
    mutation: {
      onSuccess: (wallet) => {
        queryClient.setQueryData(getGetWalletQueryKey(), wallet);
        toast({
          title: "Coins added",
          description: `Your balance is now ${wallet.coinBalance.toLocaleString()} coins.`,
        });
        window.history.replaceState({}, "", window.location.pathname);
      },
      onError: (error: any) => {
        toast({
          title: "Payment verification pending",
          description: error?.message || "Your payment could not be verified yet.",
          variant: "destructive",
        });
      },
    },
  });

  useEffect(() => {
    const search = new URLSearchParams(window.location.search);
    const sessionId = search.get("session_id");
    if (
      search.get("coin_checkout") !== "success" ||
      !sessionId ||
      checkoutConfirmationStarted.current
    ) {
      return;
    }
    checkoutConfirmationStarted.current = true;
    confirmCheckout.mutate({ data: { checkoutSessionId: sessionId } });
  }, [confirmCheckout]);

  const isHost = session?.user?.id === room?.host.id;

  if (isLoadingRoom) {
    return (
      <div className="flex-1 w-full h-[80vh] flex items-center justify-center">
        <div className="animate-pulse flex flex-col items-center gap-4">
          <div className="w-16 h-16 rounded-full bg-secondary" />
          <div className="h-6 w-32 bg-secondary rounded" />
        </div>
      </div>
    );
  }

  if (roomError || !room) {
    return (
      <div className="flex-1 w-full h-[80vh] flex items-center justify-center">
        <div className="text-center p-8 bg-destructive/10 rounded-3xl border border-destructive/20 max-w-md">
          <AlertCircle className="w-12 h-12 text-destructive mx-auto mb-4" />
          <h2 className="text-xl font-bold text-foreground mb-2">Room not found</h2>
          <p className="text-muted-foreground mb-6">This room may have ended or doesn't exist.</p>
          <Link href="/live" className="px-6 py-3 bg-secondary text-foreground font-bold rounded-xl hover:bg-secondary/80 transition-colors">
            Back to Live
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="relative w-auto flex-1 min-h-[500px] bg-black rounded-none md:rounded-3xl overflow-hidden flex flex-col -mx-4 -my-4 md:mx-0 md:my-0">
      {/* Background Cover */}
      <div className="absolute inset-0">
        <img src={room.coverUrl} alt={room.title} className="w-full h-full object-cover opacity-60" />
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-transparent to-black/90" />
      </div>

      {/* Header */}
      <div className="relative z-10 flex items-center justify-between p-4">
        <div className="flex items-center gap-3">
          <Link href="/live" className="w-10 h-10 rounded-full bg-black/40 backdrop-blur flex items-center justify-center text-white hover:bg-black/60 transition-colors">
            <ChevronLeft className="w-6 h-6" />
          </Link>
          <div className="flex items-center gap-2 bg-black/40 backdrop-blur rounded-full p-1 pr-4">
            <img src={room.host.avatarUrl} alt={room.host.name} className="w-8 h-8 rounded-full border border-white/20" />
            <div className="flex flex-col">
              <span className="text-white text-xs font-bold leading-tight">{room.host.name}</span>
              <span className="text-white/70 text-[10px] leading-tight">Host</span>
            </div>
            <button disabled title="Follow (coming soon)" className="ml-2 bg-primary text-primary-foreground text-[10px] font-bold px-2 py-0.5 rounded-full opacity-50 cursor-not-allowed">
              Follow
            </button>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <div className="bg-black/40 backdrop-blur text-white px-3 py-1.5 rounded-full text-xs font-bold flex items-center gap-1.5">
            <Users className="w-3.5 h-3.5" />
            {room.viewers}
          </div>
          <button disabled title="More (coming soon)" className="w-8 h-8 rounded-full bg-black/40 backdrop-blur flex items-center justify-center text-white/70 opacity-50 cursor-not-allowed">
            <MoreVertical className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Gift Animations Area */}
      <div className="flex-1 relative z-10 pointer-events-none p-4 flex flex-col justify-end">
        {/* We will render recent gifts here */}
        <div className="space-y-2 max-h-[40%] overflow-y-auto custom-scrollbar flex flex-col-reverse items-start">
          {room.recentGifts?.map((giftTx) => (
            <div key={giftTx.id} className="bg-black/40 backdrop-blur rounded-full pr-4 pl-1 py-1 flex items-center gap-2 animate-in slide-in-from-bottom-4 fade-in">
              <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
                <Gift className="w-4 h-4 text-primary" />
              </div>
              <div className="flex flex-col">
                <span className="text-white text-xs font-bold">User {giftTx.senderUserId.slice(0,4)} sent a gift!</span>
                <span className="text-primary text-[10px] font-bold">{giftTx.quantity}x • {giftTx.totalCoins} Coins</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Controls Footer */}
      <div className="relative z-10 p-4 pb-6 flex items-center gap-3">
        <button disabled title="Chat (coming soon)" className="flex-1 bg-white/10 backdrop-blur border border-white/20 text-white/50 rounded-full py-3 px-4 text-left text-sm cursor-not-allowed">
          Say something... (coming soon)
        </button>
        
        <button onClick={() => setIsGiftPanelOpen(true)} className="flex items-center gap-2 bg-gradient-to-r from-purple-500 to-pink-500 text-white font-bold rounded-full px-4 py-3 shadow-lg hover-elevate shrink-0">
          <Gift className="w-5 h-5" />
          <span className="hidden sm:inline">Gift</span>
        </button>

        <button disabled title="React (coming soon)" className="w-12 h-12 rounded-full bg-white/10 backdrop-blur border border-white/20 flex items-center justify-center text-white/70 opacity-50 cursor-not-allowed shrink-0">
          <Heart className="w-5 h-5" />
        </button>
        
        <button disabled title="Share (coming soon)" className="hidden sm:flex w-12 h-12 rounded-full bg-white/10 backdrop-blur border border-white/20 items-center justify-center text-white/70 opacity-50 cursor-not-allowed shrink-0">
          <Share2 className="w-5 h-5" />
        </button>
      </div>

      {/* Gift Panel Overlay */}
      {isGiftPanelOpen && (
        <GiftPanel 
          roomId={roomId} 
          receiverId={room.host.id} 
          onClose={() => setIsGiftPanelOpen(false)} 
          isHost={isHost}
        />
      )}
    </div>
  );
}
