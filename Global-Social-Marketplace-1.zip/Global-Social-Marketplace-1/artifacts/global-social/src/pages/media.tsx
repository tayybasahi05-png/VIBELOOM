import { Image as ImageIcon, PlaySquare, Music, Plus } from "lucide-react";

export function Media() {
  return (
    <div className="w-full space-y-8">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-serif text-foreground font-bold">Media Library</h1>
          <p className="text-muted-foreground mt-1">Your uploaded photos, videos, and audio.</p>
        </div>
        <button className="px-5 py-2.5 bg-primary text-primary-foreground font-bold rounded-xl flex items-center gap-2 cursor-not-allowed opacity-80" disabled>
          <Plus className="w-5 h-5" />
          Upload (Soon)
        </button>
      </div>

      <div className="bg-card border border-border rounded-3xl p-1 text-sm font-medium flex max-w-sm">
        <button className="flex-1 py-2 bg-secondary text-foreground rounded-2xl shadow-sm text-center">All</button>
        <button className="flex-1 py-2 text-muted-foreground text-center">Images</button>
        <button className="flex-1 py-2 text-muted-foreground text-center">Videos</button>
      </div>

      <div className="bg-card rounded-3xl border border-border p-12 text-center mt-8">
        <div className="flex justify-center gap-4 mb-6 opacity-60">
          <div className="w-16 h-16 bg-secondary rounded-2xl rotate-[-10deg] flex items-center justify-center">
            <ImageIcon className="w-8 h-8 text-muted-foreground" />
          </div>
          <div className="w-16 h-16 bg-secondary rounded-2xl z-10 flex items-center justify-center shadow-lg">
            <PlaySquare className="w-8 h-8 text-muted-foreground" />
          </div>
          <div className="w-16 h-16 bg-secondary rounded-2xl rotate-[10deg] flex items-center justify-center">
            <Music className="w-8 h-8 text-muted-foreground" />
          </div>
        </div>
        <h2 className="text-2xl font-bold font-serif mb-3">Media Hub is building</h2>
        <p className="text-muted-foreground max-w-md mx-auto">
          A centralized place to manage all your uploaded content is coming soon. The media API endpoints are currently in staging.
        </p>
      </div>
    </div>
  );
}
