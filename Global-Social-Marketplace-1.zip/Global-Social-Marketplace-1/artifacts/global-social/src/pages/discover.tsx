import { useGetDiscover } from "@workspace/api-client-react";
import { TrendingUp, Users, Compass } from "lucide-react";
import { PostCard } from "../components/post-card";

export function Discover() {
  const { data: discover, isLoading } = useGetDiscover();

  if (isLoading) {
    return <div className="animate-pulse space-y-8">
      <div className="h-32 bg-card rounded-3xl border border-border" />
      <div className="h-64 bg-card rounded-3xl border border-border" />
    </div>;
  }

  return (
    <div className="w-full space-y-12 pb-10">
      <div>
        <h1 className="text-4xl font-serif text-foreground font-bold mb-2">Discover</h1>
        <p className="text-muted-foreground text-lg">Explore the world around you.</p>
      </div>

      {/* Categories */}
      <section>
        <div className="flex gap-3 overflow-x-auto pb-4 snap-x">
          {discover?.categories.map((cat, i) => (
            <button key={i} className="px-6 py-3 rounded-2xl bg-card border border-border text-foreground font-semibold whitespace-nowrap snap-start hover:bg-primary hover:text-primary-foreground hover:border-primary transition-all">
              {cat}
            </button>
          ))}
        </div>
      </section>

      {/* Featured Creators */}
      <section>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-serif font-bold flex items-center gap-2">
            <Users className="w-6 h-6 text-primary" />
            Top Creators
          </h2>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {discover?.creators.map(creator => (
            <div key={creator.id} className="bg-card border border-border rounded-3xl p-5 text-center flex flex-col items-center hover-elevate cursor-pointer">
              <img src={creator.avatarUrl} alt={creator.name} className="w-20 h-20 rounded-full object-cover mb-4 bg-secondary" />
              <h3 className="font-bold text-foreground text-sm line-clamp-1">{creator.name}</h3>
              <p className="text-xs text-muted-foreground mb-4">@{creator.handle}</p>
              <button className="w-full py-2 bg-secondary text-foreground font-medium rounded-xl text-sm hover:bg-primary hover:text-primary-foreground transition-colors">
                Follow
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* Trending Posts */}
      <section>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-serif font-bold flex items-center gap-2">
            <TrendingUp className="w-6 h-6 text-accent" />
            Trending Now
          </h2>
        </div>
        <div className="space-y-2">
          {discover?.trending.map(post => (
            <PostCard key={post.id} post={post} />
          ))}
        </div>
      </section>
    </div>
  );
}