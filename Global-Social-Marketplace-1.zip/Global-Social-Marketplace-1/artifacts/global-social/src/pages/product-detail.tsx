import { useGetProduct, useToggleWishlist, useCreateMarketCheckout, useGetPaymentConfig, useCreateConversation, getListConversationsQueryKey, useGetSession } from "@workspace/api-client-react";
import { useParams, Link, useLocation } from "wouter";
import { ArrowLeft, Star, Heart, CheckCircle2, ShieldCheck, MapPin, Loader2, AlertCircle, MessageCircle } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { useState } from "react";

export function ProductDetail() {
  const params = useParams();
  const id = params.productId!;
  const { data: product, isLoading, error } = useGetProduct(id);
  const toggleWishlist = useToggleWishlist();
  const createCheckout = useCreateMarketCheckout();
  const createConversation = useCreateConversation();
  const { data: paymentConfig } = useGetPaymentConfig();
  const { data: session } = useGetSession();
  const [checkoutError, setCheckoutError] = useState<string | null>(null);
  const [taxRegion, setTaxRegion] = useState<"pakistan" | "international">("international");
  const [messageError, setMessageError] = useState<string | null>(null);
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();

  const handleBuyNow = () => {
    setCheckoutError(null);
    createCheckout.mutate(
      { data: { productId: id, idempotencyKey: crypto.randomUUID(), taxRegion } },
      {
        onSuccess: (res) => {
          if (res.url) {
            window.location.href = res.url;
          } else {
            setCheckoutError("Unable to initiate checkout. Please try again later.");
          }
        },
        onError: () => {
          setCheckoutError("Checkout failed. This item may be unavailable.");
        }
      }
    );
  };

  const handleMessageSeller = () => {
    setMessageError(null);
    createConversation.mutate(
      { data: { participantId: product!.seller.id } },
      {
        onSuccess: (conversation) => {
          queryClient.setQueryData(
            getListConversationsQueryKey(),
            (current: typeof conversation[] | undefined) => {
              const withoutConversation = (current ?? []).filter((item) => item.id !== conversation.id);
              return [conversation, ...withoutConversation];
            },
          );
          setLocation(`/inbox/${conversation.id}`);
        },
        onError: () => {
          setMessageError("Unable to open a conversation with this seller.");
        },
      },
    );
  };

  if (isLoading) {
    return <div className="animate-pulse h-[60vh] bg-card rounded-3xl border border-border w-full" />;
  }

  if (error || !product) {
    return (
      <div className="text-center py-20">
        <h2 className="text-2xl font-serif text-foreground mb-4">Product not found</h2>
        <Link href="/market" className="text-primary font-medium">Back to Market</Link>
      </div>
    );
  }

  return (
    <div className="w-full pb-20">
      <Link href="/market" className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-6 transition-colors">
        <ArrowLeft className="w-5 h-5" />
        Back
      </Link>

      <div className="flex flex-col md:flex-row gap-8 lg:gap-12">
        {/* Images */}
        <div className="w-full md:w-1/2 space-y-4">
          <div className="aspect-square bg-secondary rounded-3xl overflow-hidden border border-border relative">
            <img src={product.imageUrl} alt={product.name} className="w-full h-full object-cover" />
          </div>
          {product.images && product.images.length > 0 && (
            <div className="flex gap-4 overflow-x-auto pb-2 snap-x">
              {product.images.map((img, idx) => (
                <div key={idx} className="w-24 h-24 flex-shrink-0 bg-secondary rounded-xl overflow-hidden border border-border snap-start">
                  <img src={img} alt={`${product.name} ${idx+1}`} className="w-full h-full object-cover" />
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Info */}
        <div className="w-full md:w-1/2 flex flex-col">
          <div className="mb-2">
            <span className="text-sm font-bold tracking-wider text-accent uppercase">{product.category}</span>
          </div>
          <h1 className="text-4xl font-serif font-bold text-foreground mb-4 leading-tight">{product.name}</h1>
          
          <div className="flex items-center gap-4 mb-6">
            <div className="flex items-center gap-1 bg-secondary px-3 py-1.5 rounded-xl font-medium text-foreground">
              <Star className="w-4 h-4 fill-accent text-accent" />
              {product.rating} ({product.reviewCount} reviews)
            </div>
            <div className="flex items-center gap-1.5 text-muted-foreground text-sm font-medium">
              <MapPin className="w-4 h-4" />
              {product.location}
            </div>
          </div>

          <div className="mb-8">
            <p className="text-3xl font-serif font-bold text-primary">
              {product.currency} {product.price.toFixed(2)}
            </p>
            <p className="text-sm text-muted-foreground mt-1">
              {product.quantity > 0 ? `${product.quantity} available` : "Out of stock"}
            </p>
            <label className="block text-sm font-semibold text-foreground mt-5 mb-2" htmlFor="tax-region">
              Buyer region
            </label>
            <select
              id="tax-region"
              value={taxRegion}
              onChange={(event) => setTaxRegion(event.target.value as "pakistan" | "international")}
              className="w-full px-4 py-3 bg-background border border-border rounded-xl text-foreground"
            >
              <option value="pakistan">Pakistan — 5% tax</option>
              <option value="international">International — 10% tax</option>
            </select>
            <div className="mt-3 rounded-xl bg-secondary/60 px-4 py-3 text-sm">
              <div className="flex justify-between text-muted-foreground">
                <span>Subtotal</span>
                <span>{product.currency} {product.price.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-muted-foreground mt-1">
                <span>Tax ({taxRegion === "pakistan" ? "5%" : "10%"})</span>
                <span>{product.currency} {(product.price * (taxRegion === "pakistan" ? 0.05 : 0.1)).toFixed(2)}</span>
              </div>
              <div className="flex justify-between font-bold text-foreground mt-2 pt-2 border-t border-border">
                <span>Total</span>
                <span>{product.currency} {(product.price * (taxRegion === "pakistan" ? 1.05 : 1.1)).toFixed(2)}</span>
              </div>
            </div>
          </div>

          <div className="flex gap-4 mb-4">
            <button
              onClick={handleBuyNow}
               disabled={createCheckout.isPending || product.quantity <= 0 || !paymentConfig?.marketplaceCheckout || !product.checkoutReady}
              className="flex-1 bg-primary text-primary-foreground py-4 rounded-2xl font-bold text-lg hover-elevate shadow-md disabled:opacity-50 disabled:pointer-events-none flex items-center justify-center gap-2"
            >
              {createCheckout.isPending ? (
                <><Loader2 className="w-5 h-5 animate-spin" /> Processing...</>
                ) : !paymentConfig?.marketplaceCheckout || !product.checkoutReady ? (
                 "Checkout unavailable"
               ) : product.quantity > 0 ? (
                "Buy Now"
              ) : (
                "Out of Stock"
              )}
            </button>
            <button 
              onClick={() => toggleWishlist.mutate({ productId: id })}
              disabled={toggleWishlist.isPending}
              className="w-16 flex items-center justify-center bg-card border border-border rounded-2xl hover:bg-secondary transition-colors"
            >
              <Heart className="w-6 h-6 text-foreground" />
            </button>
          </div>

          {checkoutError && (
            <div className="mb-10 bg-destructive/10 text-destructive px-4 py-3 rounded-xl flex items-start gap-3">
              <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
              <p className="text-sm font-medium">{checkoutError}</p>
            </div>
          )}

          {!checkoutError && <div className="mb-10" />}

          {/* Seller Profile */}
          <div className="bg-card border border-border rounded-3xl p-5 mb-8">
            <div className="flex items-center gap-4 mb-4">
              <Link href={`/profile/${product.seller.id}`} className="shrink-0">
                <img src={product.seller.avatarUrl} alt={product.seller.name} className="w-14 h-14 rounded-full bg-secondary object-cover" />
              </Link>
              <div>
                <div className="flex items-center gap-1">
                  <Link href={`/profile/${product.seller.id}`} className="font-bold text-foreground text-lg hover:text-primary">
                    {product.seller.name}
                  </Link>
                  {product.seller.verified && <CheckCircle2 className="w-5 h-5 text-primary fill-primary text-card" />}
                </div>
                <p className="text-sm text-muted-foreground">Verified Seller</p>
              </div>
              <button className="ml-auto px-4 py-2 border border-border font-medium rounded-xl hover:bg-secondary transition-colors">
                Follow
              </button>
            </div>
            {session && session.user.id !== product.seller.id && (
              <>
                <button
                  type="button"
                  onClick={handleMessageSeller}
                  disabled={createConversation.isPending}
                  className="mb-3 flex min-h-11 w-full items-center justify-center gap-2 rounded-xl border border-primary/30 bg-primary/5 px-4 py-2 font-bold text-primary transition-colors hover:bg-primary/10 disabled:opacity-60"
                >
                  {createConversation.isPending ? (
                    <Loader2 className="h-5 w-5 animate-spin" />
                  ) : (
                    <MessageCircle className="h-5 w-5" />
                  )}
                  Message seller
                </button>
                {messageError && (
                  <p className="mb-3 text-sm font-medium text-destructive">{messageError}</p>
                )}
              </>
            )}
            <div className="flex items-center gap-2 text-sm text-muted-foreground bg-secondary/50 p-3 rounded-xl">
              <ShieldCheck className="w-5 h-5 text-primary" />
              Secure hosted checkout. Available payment methods are confirmed for your transaction.
            </div>
          </div>

          {/* Details */}
          <div className="space-y-6">
            <div>
              <h3 className="text-xl font-serif font-bold text-foreground mb-3">Description</h3>
              <p className="text-muted-foreground leading-relaxed whitespace-pre-wrap">
                {product.description || "No description provided."}
              </p>
            </div>
            
            {product.specifications && product.specifications.length > 0 && (
              <div>
                <h3 className="text-xl font-serif font-bold text-foreground mb-3">Specifications</h3>
                <div className="bg-card border border-border rounded-2xl overflow-hidden">
                  {product.specifications.map((spec, i) => (
                    <div key={i} className={`flex border-b border-border last:border-0`}>
                      <div className="w-1/3 bg-secondary/50 p-3 text-sm font-medium text-muted-foreground">
                        {spec.label}
                      </div>
                      <div className="w-2/3 p-3 text-sm text-foreground font-medium">
                        {spec.value}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}