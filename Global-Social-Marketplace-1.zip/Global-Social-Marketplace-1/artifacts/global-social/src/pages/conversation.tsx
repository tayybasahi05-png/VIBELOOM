import { useListMessages, useSendMessage, useListConversations } from "@workspace/api-client-react";
import { useParams, Link } from "wouter";
import { ArrowLeft, Send, Loader2, AlertCircle } from "lucide-react";
import { useState, useRef, useEffect } from "react";
import { format } from "date-fns";
import { useQueryClient } from "@tanstack/react-query";
import {
  getListConversationsQueryKey,
  getListMessagesQueryKey,
  getListNotificationsQueryKey,
} from "@workspace/api-client-react";

function formatMessageTime(value: string) {
  if (/^\d{1,2}:\d{2}$/.test(value)) return value;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : format(date, "h:mm a");
}

export function ConversationDetail() {
  const { conversationId } = useParams<{ conversationId: string }>();
  const { data: conversations } = useListConversations();
  const {
    data: messages,
    isLoading,
    isError,
    isFetching,
    refetch,
  } = useListMessages(conversationId!);
  const sendMessage = useSendMessage();
  const [text, setText] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const queryClient = useQueryClient();

  const conversation = conversations?.find(c => c.id === conversationId);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (messages) {
      queryClient.invalidateQueries({ queryKey: getListConversationsQueryKey() });
      queryClient.invalidateQueries({ queryKey: getListNotificationsQueryKey() });
    }
  }, [messages, queryClient]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim() || !conversationId) return;

    sendMessage.mutate(
      { conversationId, data: { body: text } },
      {
        onSuccess: () => {
          setText("");
          queryClient.invalidateQueries({ queryKey: getListMessagesQueryKey(conversationId) });
          queryClient.invalidateQueries({ queryKey: getListConversationsQueryKey() });
        }
      }
    );
  };

  return (
    <div className="flex flex-col h-[calc(100vh-120px)] md:h-[calc(100vh-64px)] bg-card rounded-3xl border border-border overflow-hidden">
      {/* Header */}
      <div className="flex items-center gap-4 p-4 border-b border-border bg-card/80 backdrop-blur-sm z-10 shrink-0">
        <Link href="/inbox" className="p-2 -ml-2 rounded-full hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors">
          <ArrowLeft className="w-5 h-5" />
        </Link>
        {conversation ? (
          <div className="flex items-center gap-3">
            <div className="relative">
              <img src={conversation.participant.avatarUrl} alt={conversation.participant.name} className="w-10 h-10 rounded-full object-cover bg-secondary" />
              {conversation.online && (
                <div className="absolute bottom-0 right-0 w-3 h-3 bg-primary border-2 border-card rounded-full" />
              )}
            </div>
            <div>
              <h2 className="font-bold text-foreground leading-tight">{conversation.participant.name}</h2>
              <p className="text-xs text-muted-foreground">
                {conversation.online ? "Active now" : "Offline"}
              </p>
            </div>
          </div>
        ) : (
          <div className="flex items-center gap-3 animate-pulse">
            <div className="w-10 h-10 rounded-full bg-secondary" />
            <div className="space-y-2">
              <div className="h-4 w-24 bg-secondary rounded" />
              <div className="h-3 w-16 bg-secondary rounded" />
            </div>
          </div>
        )}
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {isLoading ? (
          <div className="flex items-center justify-center h-full">
            <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
          </div>
        ) : isError ? (
          <div className="flex h-full flex-col items-center justify-center text-center">
            <AlertCircle className="mb-3 h-8 w-8 text-destructive" />
            <h2 className="font-bold text-foreground">Conversation could not be loaded</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              It may not exist, or you may not have access.
            </p>
            <button
              type="button"
              onClick={() => refetch()}
              disabled={isFetching}
              className="mt-4 inline-flex min-h-11 items-center gap-2 rounded-xl bg-primary px-4 py-2 font-bold text-primary-foreground disabled:opacity-60"
            >
              {isFetching && <Loader2 className="h-4 w-4 animate-spin" />}
              Retry
            </button>
          </div>
        ) : (
          messages?.map((msg) => (
            <div 
              key={msg.id} 
              className={`flex flex-col max-w-[75%] ${msg.isMine ? "ml-auto items-end" : "mr-auto items-start"}`}
            >
              <div 
                className={`px-4 py-2.5 rounded-2xl ${
                  msg.isMine 
                    ? "bg-primary text-primary-foreground rounded-br-sm" 
                    : "bg-secondary text-foreground rounded-bl-sm"
                }`}
              >
                {msg.body}
              </div>
              <span className="text-[10px] text-muted-foreground mt-1 px-1">
                {formatMessageTime(msg.createdAt)}
              </span>
            </div>
          ))
        )}
        {!isError && messages?.length === 0 && (
          <div className="text-center py-10 text-muted-foreground">
            Say hi to start the conversation!
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="p-4 border-t border-border bg-card shrink-0">
        <form onSubmit={handleSend} className="flex items-end gap-2">
          <textarea 
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSend(e);
              }
            }}
            placeholder="Type a message..."
            className="flex-1 max-h-32 min-h-[44px] bg-background border border-border rounded-2xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary resize-none custom-scrollbar"
            rows={1}
          />
          <button 
            type="submit" 
            disabled={!text.trim() || sendMessage.isPending || isError}
            className="p-3 bg-primary text-primary-foreground rounded-full hover:bg-primary/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed shrink-0"
          >
            {sendMessage.isPending ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
          </button>
        </form>
      </div>
    </div>
  );
}
