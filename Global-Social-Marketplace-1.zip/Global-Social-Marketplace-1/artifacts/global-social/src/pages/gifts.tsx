import { Gift, HeartHandshake, Sparkles } from "lucide-react";

export function Gifts() {
  return (
    <div className="w-full space-y-8">
      <div className="text-center space-y-3 max-w-lg mx-auto mt-8">
        <div className="w-20 h-20 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-4">
          <Gift className="w-10 h-10 text-accent" />
        </div>
        <h1 className="text-4xl font-serif text-foreground font-bold">Virtual Gifts</h1>
        <p className="text-muted-foreground text-lg">
          Support your favorite creators and show appreciation with unique digital gifts.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-12 max-w-3xl mx-auto">
        <div className="bg-card border border-border p-8 rounded-3xl relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-6 opacity-10 group-hover:scale-110 transition-transform duration-500">
            <HeartHandshake className="w-32 h-32" />
          </div>
          <h3 className="text-xl font-bold mb-2">Creator Support</h3>
          <p className="text-muted-foreground mb-6 max-w-[200px] relative z-10">
            Send tokens during live streams to show your love.
          </p>
          <button disabled className="px-4 py-2 bg-secondary text-foreground font-semibold rounded-xl text-sm opacity-70 cursor-not-allowed">
            Coming Soon
          </button>
        </div>

        <div className="bg-primary/5 border border-primary/20 p-8 rounded-3xl relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-6 opacity-10 group-hover:scale-110 transition-transform duration-500">
            <Sparkles className="w-32 h-32 text-primary" />
          </div>
          <h3 className="text-xl font-bold mb-2 text-primary">Exclusive Items</h3>
          <p className="text-primary/70 mb-6 max-w-[200px] relative z-10">
            Unlock premium badges and profile highlights.
          </p>
          <button disabled className="px-4 py-2 bg-primary text-primary-foreground font-semibold rounded-xl text-sm opacity-70 cursor-not-allowed">
            Available in v2
          </button>
        </div>
      </div>
    </div>
  );
}
