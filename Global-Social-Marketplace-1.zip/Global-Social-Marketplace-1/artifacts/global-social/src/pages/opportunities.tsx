import { useListOpportunities } from "@workspace/api-client-react";
import { Sparkles, ArrowRight } from "lucide-react";

export function Opportunities() {
  const { data: opps, isLoading } = useListOpportunities();

  return (
    <div className="w-full pb-10">
      <div className="mb-10">
        <h1 className="text-4xl font-serif text-foreground font-bold flex items-center gap-3">
          <Sparkles className="w-8 h-8 text-accent" />
          Opportunities
        </h1>
        <p className="text-muted-foreground mt-2 text-lg">Exclusive benefits and programs for you.</p>
      </div>

      {isLoading ? (
        <div className="space-y-4 animate-pulse">
          {[1,2,3].map(i => (
            <div key={i} className="bg-card h-40 rounded-3xl border border-border" />
          ))}
        </div>
      ) : (
        <div className="space-y-4">
          {opps?.map(opp => (
            <div 
              key={opp.id} 
              className="group relative overflow-hidden bg-card border border-border rounded-3xl p-6 md:p-8 flex flex-col md:flex-row md:items-center justify-between gap-6 hover-elevate transition-all"
              style={{ borderLeftWidth: 6, borderLeftColor: opp.accent || 'var(--color-primary)' }}
            >
              {/* Decorative background blur */}
              <div 
                className="absolute top-0 right-0 w-64 h-64 opacity-5 pointer-events-none rounded-full blur-3xl -translate-y-1/2 translate-x-1/3"
                style={{ backgroundColor: opp.accent || 'var(--color-primary)' }}
              />
              
              <div className="flex-1 relative z-10">
                <span className="inline-block px-3 py-1 rounded-full text-xs font-bold uppercase tracking-widest mb-3 border"
                  style={{ color: opp.accent, borderColor: opp.accent + '40', backgroundColor: opp.accent + '10' }}
                >
                  {opp.type}
                </span>
                <h2 className="text-2xl font-serif font-bold text-foreground mb-2">{opp.title}</h2>
                <p className="text-muted-foreground text-base max-w-xl leading-relaxed">
                  {opp.description}
                </p>
              </div>

              <div className="relative z-10 shrink-0">
                <button 
                  className="w-full md:w-auto px-6 py-4 rounded-xl font-bold text-white shadow-sm flex items-center justify-center gap-2 transition-transform hover:scale-105 active:scale-95"
                  style={{ backgroundColor: opp.accent || 'var(--color-primary)' }}
                >
                  {opp.actionLabel}
                  <ArrowRight className="w-5 h-5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}