import { useState } from "react";
import { useGetFeed, useListStories } from "@workspace/api-client-react";
import { PostCard } from "../components/post-card";
import { StoriesTray, StoryViewer, StoryComposer } from "../components/stories";
import { Compass, Loader2 } from "lucide-react";
import { Link } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import { getListStoriesQueryKey } from "@workspace/api-client-react";

export function Home() {
  const { data: feed, isLoading, error } = useGetFeed();
  const { data: storyGroups, isLoading: isLoadingStories } = useListStories();
  const queryClient = useQueryClient();

  const [activeStoryGroupIndex, setActiveStoryGroupIndex] = useState<number | null>(null);
  const [isComposingStory, setIsComposingStory] = useState(false);

  const handleStorySuccess = () => {
    setIsComposingStory(false);
    queryClient.invalidateQueries({ queryKey: getListStoriesQueryKey() });
  };

  if (isLoading) {
    return (
      <div className="space-y-6 animate-pulse">
        {[1, 2, 3].map(i => (
          <div key={i} className="bg-card rounded-3xl h-80 w-full border border-border" />
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-destructive/10 text-destructive p-6 rounded-3xl text-center border border-destructive/20">
        <p className="font-semibold">Failed to load feed</p>
        <p className="text-sm opacity-80 mt-1">Please try again later.</p>
      </div>
    );
  }

  return (
    <div className="w-full">
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-3xl font-serif text-foreground font-bold tracking-tight">Your Feed</h1>
      </div>

      {!isLoadingStories && storyGroups && (
        <StoriesTray 
          groups={storyGroups} 
          onOpenViewer={setActiveStoryGroupIndex}
          onOpenComposer={() => setIsComposingStory(true)}
        />
      )}

      {activeStoryGroupIndex !== null && storyGroups && (
        <StoryViewer 
          groups={storyGroups} 
          initialGroupIndex={activeStoryGroupIndex} 
          onClose={() => setActiveStoryGroupIndex(null)}
        />
      )}

      {isComposingStory && (
        <StoryComposer 
          onClose={() => setIsComposingStory(false)}
          onSuccess={handleStorySuccess}
        />
      )}

      <div className="space-y-4">
        {feed?.items.map(post => (
          <PostCard key={post.id} post={post} />
        ))}
        {feed?.items.length === 0 && (
          <div className="text-center py-20 text-muted-foreground bg-card border border-border rounded-3xl">
            <div className="w-16 h-16 bg-secondary rounded-full flex items-center justify-center mx-auto mb-4">
              <Compass className="w-8 h-8 opacity-50" />
            </div>
            <h3 className="font-bold text-foreground mb-1">Your feed is empty</h3>
            <p>Follow some creators or join communities to see posts here.</p>
            <Link href="/search" className="inline-block mt-4 px-6 py-2 bg-secondary text-foreground font-bold rounded-xl hover:bg-secondary/80">
              Discover Content
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}