import { useState, useEffect, useRef, useCallback } from "react";
import { Camera, RefreshCcw, Sparkles, X, Square, Video } from "lucide-react";

interface CameraViewProps {
  onCaptureImage: (blob: Blob) => void;
  onCaptureVideo: (blob: Blob, duration?: number) => void;
  onClose: () => void;
  onSelectGallery: (file: File) => void;
  onSelectText: () => void;
  error?: string | null;
  onErrorClear?: () => void;
}

export function CameraView({ onCaptureImage, onCaptureVideo, onClose, onSelectGallery, onSelectText, error: externalError, onErrorClear }: CameraViewProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<number | undefined>(undefined);
  const progressTimerRef = useRef<number | undefined>(undefined);
  const beautyAnimFrameRef = useRef<number | undefined>(undefined);
  const processedStreamRef = useRef<MediaStream | null>(null);
  const cameraGenerationRef = useRef(0);
  const suppressRecorderStopRef = useRef(false);
  const isRecordingRef = useRef(false);
  const startTimeRef = useRef<number>(0);

  const [facingMode, setFacingMode] = useState<"user" | "environment">("user");
  const facingModeRef = useRef<"user" | "environment">("user");
  
  const [isRecording, setIsRecording] = useState(false);
  const [recordProgress, setRecordProgress] = useState(0);
  const [localError, setLocalError] = useState<string | null>(null);
  
  const error = externalError || localError;
  
  const [mode, setMode] = useState<"standard" | "beauty">("standard");
  const beautyMode = mode === "beauty";
  
  // Beauty controls
  const [brightness, setBrightness] = useState(100);
  const [warmth, setWarmth] = useState(0);
  const [smoothing, setSmoothing] = useState(0);

  const clearError = useCallback(() => {
    setLocalError(null);
    if (onErrorClear) onErrorClear();
  }, [onErrorClear]);

  const stopMediaTracks = useCallback(() => {
    cameraGenerationRef.current += 1;
    isRecordingRef.current = false;
    if (beautyAnimFrameRef.current !== undefined) {
      cancelAnimationFrame(beautyAnimFrameRef.current);
      beautyAnimFrameRef.current = undefined;
    }
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === "recording") {
      suppressRecorderStopRef.current = true;
      mediaRecorderRef.current.stop();
    }
    mediaRecorderRef.current = null;
    if (processedStreamRef.current) {
      processedStreamRef.current.getTracks().forEach((track) => track.stop());
      processedStreamRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    clearTimeout(timerRef.current);
    clearInterval(progressTimerRef.current);
    timerRef.current = undefined;
    progressTimerRef.current = undefined;
    setIsRecording(false);
    setRecordProgress(0);
  }, []);

  const startCamera = useCallback(async (facing: "user" | "environment") => {
    stopMediaTracks();
    const generation = cameraGenerationRef.current;
    setLocalError(null);
    if (onErrorClear) onErrorClear();
    
    try {
      const newStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: facing },
        audio: true
      });
      if (generation !== cameraGenerationRef.current) {
        newStream.getTracks().forEach((track) => track.stop());
        return;
      }
      streamRef.current = newStream;
      facingModeRef.current = facing;
      if (videoRef.current) {
        videoRef.current.srcObject = newStream;
      }
    } catch (err) {
      setLocalError("Camera access denied or unsupported. Please use gallery upload.");
    }
  }, [stopMediaTracks, onErrorClear]);

  useEffect(() => {
    startCamera(facingMode);
    return () => {
      stopMediaTracks();
    };
  }, [facingMode, startCamera, stopMediaTracks]);

  const toggleCamera = () => {
    setFacingMode(prev => prev === "user" ? "environment" : "user");
  };

  const getFilterString = () => {
    if (!beautyMode) return "none";
    return `brightness(${brightness}%) sepia(${warmth}%) blur(${smoothing}px)`;
  };

  const takePhoto = () => {
    if (!videoRef.current) return;
    const canvas = document.createElement("canvas");
    canvas.width = videoRef.current.videoWidth;
    canvas.height = videoRef.current.videoHeight;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    if (facingModeRef.current === "user") {
      ctx.translate(canvas.width, 0);
      ctx.scale(-1, 1);
    }
    
    if (beautyMode) {
      ctx.filter = getFilterString();
    }
    
    ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
    
    canvas.toBlob((blob) => {
      if (blob) {
        stopMediaTracks();
        onCaptureImage(blob);
      }
    }, "image/jpeg", 0.9);
  };

  const startRecording = () => {
    if (!streamRef.current || !videoRef.current) return;
    
    let recordStream = streamRef.current;

    if (beautyMode) {
      const canvas = document.createElement('canvas');
      canvas.width = videoRef.current.videoWidth;
      canvas.height = videoRef.current.videoHeight;
      const ctx = canvas.getContext('2d');
      const captureStream = canvas.captureStream?.(30);
      if (ctx && captureStream) {
        isRecordingRef.current = true;
        const draw = () => {
          if (!isRecordingRef.current) return;
          ctx.save();
          ctx.clearRect(0, 0, canvas.width, canvas.height);
          if (facingModeRef.current === "user") {
            ctx.translate(canvas.width, 0);
            ctx.scale(-1, 1);
          }
          ctx.filter = `brightness(${brightness}%) sepia(${warmth}%) blur(${smoothing}px)`;
          ctx.drawImage(videoRef.current!, 0, 0, canvas.width, canvas.height);
          ctx.restore();
          beautyAnimFrameRef.current = requestAnimationFrame(draw);
        };
        draw();
        const audioTracks = streamRef.current.getAudioTracks();
        if (audioTracks.length > 0) {
          captureStream.addTrack(audioTracks[0]);
        }
        processedStreamRef.current = captureStream;
        recordStream = captureStream;
      } else {
        setLocalError("Beauty video recording is not supported on this device. Use a standard video or photo.");
        return;
      }
    }

    try {
      const mimeType = ['video/webm;codecs=vp8,opus', 'video/webm', 'video/mp4']
        .find((type) => typeof MediaRecorder.isTypeSupported !== 'function' || MediaRecorder.isTypeSupported(type));
      if (!mimeType) throw new Error("No supported recording format");
      const recorder = new MediaRecorder(recordStream, { mimeType });
      mediaRecorderRef.current = recorder;
      chunksRef.current = [];

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };

      recorder.onstop = () => {
        const wasSuppressed = suppressRecorderStopRef.current;
        suppressRecorderStopRef.current = false;
        isRecordingRef.current = false;
        if (beautyAnimFrameRef.current !== undefined) {
          cancelAnimationFrame(beautyAnimFrameRef.current);
          beautyAnimFrameRef.current = undefined;
        }
        if (wasSuppressed) return;
        const duration = (Date.now() - startTimeRef.current) / 1000;
        const blob = new Blob(chunksRef.current, { type: mimeType });
        stopMediaTracks();
        if (blob.size > 0) onCaptureVideo(blob, Math.min(15, Math.max(1, Math.ceil(duration))));
      };

      recorder.start();
      setIsRecording(true);
      isRecordingRef.current = true;
      
      startTimeRef.current = Date.now();
      progressTimerRef.current = window.setInterval(() => {
        const elapsed = Date.now() - startTimeRef.current;
        setRecordProgress(Math.min((elapsed / 15000) * 100, 100));
      }, 50);

      timerRef.current = window.setTimeout(() => {
        if (mediaRecorderRef.current && mediaRecorderRef.current.state === "recording") {
          mediaRecorderRef.current.stop();
        }
      }, 15000);
    } catch (err) {
      setLocalError("Video recording is not supported on this device.");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === "recording") {
      mediaRecorderRef.current.stop();
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      stopMediaTracks();
      onSelectGallery(e.target.files[0]);
    }
  };

  return (
    <div className="fixed inset-0 bg-black flex flex-col overflow-hidden z-50">
      <div className="absolute top-0 left-0 right-0 p-4 flex items-center justify-between z-20 bg-gradient-to-b from-black/60 to-transparent">
        <button onClick={onClose} aria-label="Close Camera" className="p-2 bg-black/40 text-white rounded-full hover:bg-black/60 transition-colors backdrop-blur-md">
          <X className="w-6 h-6" />
        </button>
        <div className="flex gap-4">
          <button onClick={toggleCamera} aria-label="Switch Camera" className="p-2 bg-black/40 text-white rounded-full hover:bg-black/60 transition-colors backdrop-blur-md">
            <RefreshCcw className="w-6 h-6" />
          </button>
        </div>
      </div>

      <div className="flex-1 relative flex items-center justify-center bg-black">
        {error ? (
          <div className="text-white text-center p-8 z-30">
            <p className="mb-6 font-bold">{error}</p>
            <div className="flex flex-col gap-4 items-center">
              <label className="inline-flex items-center gap-2 px-6 py-3 bg-secondary text-secondary-foreground rounded-full font-bold cursor-pointer hover:bg-secondary/80 transition-colors">
                Gallery Upload
                <input type="file" accept="image/jpeg,image/png,image/webp,video/mp4,video/webm" className="hidden" onChange={handleFileSelect} />
              </label>
              <button onClick={onSelectText} className="text-white/80 hover:text-white text-sm font-bold">
                Text Status
              </button>
              {externalError && (
                 <button onClick={clearError} className="text-white/60 hover:text-white text-sm font-bold">Clear Error</button>
              )}
            </div>
          </div>
        ) : (
          <video 
            ref={videoRef} 
            autoPlay 
            playsInline 
            muted 
            className={`absolute inset-0 w-full h-full object-cover transition-transform duration-300 ${facingMode === "user" ? "scale-x-[-1]" : ""}`}
            style={{ filter: getFilterString() }}
          />
        )}
      </div>

      {beautyMode && !error && !isRecording && (
        <div className="absolute bottom-40 left-0 right-0 px-6 py-4 bg-black/40 backdrop-blur-md z-20 space-y-4 rounded-t-3xl border-t border-white/10">
          <div className="flex items-center gap-4">
            <span className="text-xs font-bold text-white w-20">Brightness</span>
            <input type="range" aria-label="Brightness" min="100" max="150" value={brightness} onChange={e => setBrightness(Number(e.target.value))} className="flex-1 accent-primary" />
          </div>
          <div className="flex items-center gap-4">
            <span className="text-xs font-bold text-white w-20">Warmth</span>
            <input type="range" aria-label="Warmth" min="0" max="50" value={warmth} onChange={e => setWarmth(Number(e.target.value))} className="flex-1 accent-primary" />
          </div>
          <div className="flex items-center gap-4">
            <span className="text-xs font-bold text-white w-20">Smooth</span>
            <input type="range" aria-label="Smoothness" min="0" max="4" step="0.5" value={smoothing} onChange={e => setSmoothing(Number(e.target.value))} className="flex-1 accent-primary" />
          </div>
        </div>
      )}

      <div className="absolute bottom-0 left-0 right-0 h-40 bg-gradient-to-t from-black/80 to-transparent flex flex-col items-center justify-end pb-6 gap-6 z-20">
        {!error && (
          <div className="relative flex items-center justify-center">
            {isRecording && (
              <svg className="absolute inset-0 w-24 h-24 -ml-2 -mt-2 rotate-[-90deg] pointer-events-none">
                <circle cx="48" cy="48" r="44" stroke="rgba(255,255,255,0.2)" strokeWidth="4" fill="none" />
                <circle cx="48" cy="48" r="44" stroke="hsl(var(--destructive))" strokeWidth="4" fill="none" strokeDasharray="276" strokeDashoffset={276 - (276 * recordProgress) / 100} className="transition-all duration-75 ease-linear" />
              </svg>
            )}
            
            {isRecording ? (
              <button onClick={stopRecording} aria-label="Stop Recording" className="w-20 h-20 bg-destructive rounded-full flex items-center justify-center hover:bg-destructive/80 transition-transform scale-95 z-10">
                <Square className="w-8 h-8 text-white fill-white" />
              </button>
            ) : (
              <div className="flex items-center gap-8">
                <button onClick={takePhoto} aria-label="Take Photo" className="w-16 h-16 bg-white/30 rounded-full flex items-center justify-center hover:bg-white/40 backdrop-blur-md p-1 transition-transform active:scale-95">
                  <div className="w-full h-full bg-white rounded-full flex items-center justify-center">
                    <Camera className="w-6 h-6 text-black" />
                  </div>
                </button>
                
                <button onClick={startRecording} aria-label="Record Video" className="w-16 h-16 bg-white/30 rounded-full flex items-center justify-center hover:bg-white/40 backdrop-blur-md p-1 transition-transform active:scale-95">
                  <div className="w-full h-full bg-destructive rounded-full flex items-center justify-center">
                    <Video className="w-6 h-6 text-white" />
                  </div>
                </button>
              </div>
            )}
          </div>
        )}

        {!isRecording && (
          <div className="flex items-center gap-6 overflow-x-auto w-full px-6 justify-center custom-scrollbar pb-2">
            <button onClick={onSelectText} className="text-white/80 hover:text-white text-sm font-bold whitespace-nowrap px-2 py-1">Text Status</button>
            <button onClick={() => setMode("standard")} className={`text-sm font-bold whitespace-nowrap px-2 py-1 ${mode === "standard" ? "text-white bg-white/20 rounded-full" : "text-white/80 hover:text-white"}`}>Standard</button>
            <button onClick={() => setMode("beauty")} className={`text-sm font-bold whitespace-nowrap flex items-center gap-1 px-2 py-1 ${mode === "beauty" ? "text-white bg-white/20 rounded-full" : "text-white/80 hover:text-white"}`}>
              <Sparkles className="w-4 h-4" /> Beauty
            </button>
            <label className="text-white/80 hover:text-white text-sm font-bold cursor-pointer whitespace-nowrap px-2 py-1">
              Gallery
              <input type="file" accept="image/jpeg,image/png,image/webp,video/mp4,video/webm" className="hidden" onChange={handleFileSelect} />
            </label>
          </div>
        )}
      </div>
    </div>
  );
}
