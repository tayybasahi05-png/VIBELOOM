import { useEffect, useRef, useState, useCallback } from "react";
import { Story, StoryGroup, useMarkStoryViewed, useDeleteStory, useGetSession } from "@workspace/api-client-react";
import { X, ChevronLeft, ChevronRight, Pause, Play, Volume2, VolumeX, Trash2 } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { getListStoriesQueryKey } from "@workspace/api-client-react";

interface StoryViewerProps {
  groups: StoryGroup[];
  initialGroupIndex: number;
  onClose: () => void;
}

export function StoryViewer({ groups, initialGroupIndex, onClose }: StoryViewerProps) {
  const { data: session } = useGetSession();
  const queryClient = useQueryClient();
  const [groupIndex, setGroupIndex] = useState(initialGroupIndex);
  const [storyIndex, setStoryIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [progress, setProgress] = useState(0);

  const markViewed = useMarkStoryViewed();
  const deleteStory = useDeleteStory();
  const markedStoryIdsRef = useRef(new Set<number>());
  const markViewedRef = useRef(markViewed.mutate);

  const currentGroup = groups[groupIndex];
  const currentStory = currentGroup?.stories[storyIndex];

  const videoRef = useRef<HTMLVideoElement>(null);
  const progressTimerRef = useRef<number | undefined>(undefined);
  const startTimeRef = useRef<number>(Date.now());
  const pausedTimeRef = useRef<number>(0);
  const remainingTimeRef = useRef<number>(5000); // default 5s

  useEffect(() => {
    markViewedRef.current = markViewed.mutate;
  }, [markViewed.mutate]);

  const advanceStory = useCallback(() => {
    if (!currentGroup) return;
    if (storyIndex < currentGroup.stories.length - 1) {
      setStoryIndex(s => s + 1);
      setProgress(0);
    } else if (groupIndex < groups.length - 1) {
      setGroupIndex(g => g + 1);
      setStoryIndex(0);
      setProgress(0);
    } else {
      onClose();
    }
  }, [currentGroup, storyIndex, groupIndex, groups.length, onClose]);

  const previousStory = useCallback(() => {
    if (!currentGroup) return;
    if (storyIndex > 0) {
      setStoryIndex(s => s - 1);
      setProgress(0);
    } else if (groupIndex > 0) {
      const prevGroup = groups[groupIndex - 1];
      setGroupIndex(g => g - 1);
      setStoryIndex(prevGroup.stories.length - 1);
      setProgress(0);
    }
  }, [currentGroup, storyIndex, groupIndex, groups]);

  // Mark viewed
  useEffect(() => {
    if (
      currentStory &&
      !currentStory.viewed &&
      currentStory.authorUserId !== session?.user?.id &&
      !markedStoryIdsRef.current.has(currentStory.id)
    ) {
      markedStoryIdsRef.current.add(currentStory.id);
      markViewedRef.current({ storyId: currentStory.id }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListStoriesQueryKey() });
        }
      });
    }
  }, [currentStory?.id, currentStory?.viewed, currentStory?.authorUserId, session?.user?.id, queryClient]);

  // Handle timer
  useEffect(() => {
    if (!currentStory) return;
    
    // Clear any existing timer
    if (progressTimerRef.current) cancelAnimationFrame(progressTimerRef.current);

    if (isPaused) {
      if (videoRef.current) videoRef.current.pause();
      return;
    }

    if (currentStory.type === "video" && videoRef.current) {
      videoRef.current.play().catch(() => setIsPaused(true)); // Auto-play might be blocked
    }

    let durationMs = (currentStory.durationSeconds || 5) * 1000;
    
    const animate = () => {
      if (currentStory.type === "video" && videoRef.current) {
        if (!videoRef.current.duration) {
          progressTimerRef.current = requestAnimationFrame(animate);
          return;
        }
        const currentP = (videoRef.current.currentTime / videoRef.current.duration) * 100;
        setProgress(currentP);
        if (currentP >= 99.5) advanceStory();
        else progressTimerRef.current = requestAnimationFrame(animate);
      } else {
        const elapsed = Date.now() - startTimeRef.current;
        const currentP = Math.min((elapsed / durationMs) * 100, 100);
        setProgress(currentP);
        if (currentP >= 100) advanceStory();
        else progressTimerRef.current = requestAnimationFrame(animate);
      }
    };

    if (currentStory.type !== "video" || videoRef.current) {
      progressTimerRef.current = requestAnimationFrame(animate);
    }

    return () => {
      if (progressTimerRef.current) cancelAnimationFrame(progressTimerRef.current);
    };
  }, [currentStory, isPaused, advanceStory]);

  // Reset timers on story change
  useEffect(() => {
    startTimeRef.current = Date.now();
    setProgress(0);
    setIsPaused(false);
  }, [currentStory]);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight') advanceStory();
      else if (e.key === 'ArrowLeft') previousStory();
      else if (e.key === 'Escape') onClose();
      else if (e.key === ' ') setIsPaused(p => !p);
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [advanceStory, previousStory, onClose]);

  const handleDelete = async () => {
    if (!currentStory) return;
    setIsPaused(true);
    if (confirm("Delete this story?")) {
      await deleteStory.mutateAsync({ storyId: currentStory.id });
      queryClient.invalidateQueries({ queryKey: getListStoriesQueryKey() });
      if (currentGroup?.stories.length === 1) {
        if (groups.length === 1) onClose();
        else advanceStory();
      } else {
        advanceStory();
      }
    } else {
      setIsPaused(false);
      startTimeRef.current = Date.now() - (progress / 100) * ((currentStory.durationSeconds || 5) * 1000);
    }
  };

  if (!currentGroup || !currentStory) return null;

  const getInitials = (name?: string) => name ? name.charAt(0).toUpperCase() : "?";

  return (
    <div className="fixed inset-0 z-50 bg-black flex items-center justify-center overflow-hidden">
      <div className="w-full max-w-md mx-auto h-[100dvh] bg-black overflow-hidden flex flex-col relative">
        
        {/* Progress Bars */}
        <div className="absolute top-0 left-0 right-0 p-4 z-20 flex gap-1 pt-6 bg-gradient-to-b from-black/60 to-transparent">
          {currentGroup.stories.map((s, idx) => (
            <div key={s.id} className="h-1 bg-white/30 flex-1 rounded-full overflow-hidden">
              <div 
                className="h-full bg-white transition-all ease-linear"
                style={{
                  width: idx === storyIndex ? `${progress}%` : idx < storyIndex ? '100%' : '0%',
                  transitionDuration: idx === storyIndex && !isPaused ? '100ms' : '0ms'
                }}
              />
            </div>
          ))}
        </div>

        {/* Header */}
        <div className="absolute top-0 left-0 right-0 p-4 pt-10 z-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            {currentGroup.author.avatarUrl ? (
              <img src={currentGroup.author.avatarUrl} alt={currentGroup.author.name} className="w-10 h-10 rounded-full border border-white/20 object-cover shrink-0" />
            ) : (
              <div className="w-10 h-10 rounded-full border border-white/20 bg-secondary flex items-center justify-center text-secondary-foreground font-bold shrink-0">
                {getInitials(currentGroup.author.name)}
              </div>
            )}
            <div>
              <p className="text-white font-bold text-sm leading-tight drop-shadow-md">{currentGroup.author.name}</p>
              <p className="text-white/80 text-xs drop-shadow-md">
                {new Date(currentStory.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            {currentStory.authorUserId === session?.user?.id && (
              <button onClick={handleDelete} aria-label="Delete Story" className="p-2 text-white/80 hover:text-white hover:bg-white/10 rounded-full transition-colors">
                <Trash2 className="w-5 h-5" />
              </button>
            )}
            <button onClick={() => setIsPaused(!isPaused)} aria-label={isPaused ? "Play" : "Pause"} className="p-2 text-white/80 hover:text-white hover:bg-white/10 rounded-full transition-colors">
              {isPaused ? <Play className="w-5 h-5" /> : <Pause className="w-5 h-5" />}
            </button>
            <button onClick={onClose} aria-label="Close Viewer" className="p-2 text-white/80 hover:text-white hover:bg-white/10 rounded-full transition-colors">
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Tap Zones */}
        <div className="absolute inset-0 z-10 flex">
          <div 
            className="w-1/3 h-full cursor-pointer" 
            onClick={previousStory}
            onPointerDown={() => setIsPaused(true)}
            onPointerUp={() => { setIsPaused(false); startTimeRef.current = Date.now() - (progress / 100) * ((currentStory.durationSeconds || 5) * 1000); }}
          />
          <div 
            className="w-2/3 h-full cursor-pointer" 
            onClick={advanceStory}
            onPointerDown={() => setIsPaused(true)}
            onPointerUp={() => { setIsPaused(false); startTimeRef.current = Date.now() - (progress / 100) * ((currentStory.durationSeconds || 5) * 1000); }}
          />
        </div>

        {/* Content */}
        <div className="flex-1 bg-black relative flex items-center justify-center">
          {currentStory.type === "text" ? (
            <div className="w-full h-full p-8 flex items-center justify-center bg-gradient-to-br from-primary to-accent">
              <p className="text-white text-3xl font-serif font-bold text-center leading-snug drop-shadow-lg">{currentStory.text}</p>
            </div>
          ) : currentStory.type === "image" ? (
            <img src={currentStory.mediaUrl!} alt="Story" className="w-full h-full object-contain" />
          ) : currentStory.type === "video" ? (
            <div className="w-full h-full relative">
              <video 
                ref={videoRef} 
                src={currentStory.mediaUrl!} 
                className="w-full h-full object-contain"
                playsInline
                muted={isMuted}
                onEnded={advanceStory}
              />
              <button 
                onClick={(e) => { e.stopPropagation(); setIsMuted(!isMuted); }} 
                className="absolute bottom-6 right-6 p-3 bg-black/40 text-white rounded-full z-20 backdrop-blur-md hover:bg-black/60 transition-colors"
              >
                {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
              </button>
            </div>
          ) : null}
        </div>
        
        {/* Preload Next Media */}
        <div className="hidden">
          {groups[groupIndex]?.stories[storyIndex + 1]?.mediaUrl && groups[groupIndex].stories[storyIndex + 1].type === "image" && (
            <img src={groups[groupIndex].stories[storyIndex + 1].mediaUrl!} alt="preload" />
          )}
          {groups[groupIndex + 1]?.stories[0]?.mediaUrl && groups[groupIndex + 1].stories[0].type === "image" && (
            <img src={groups[groupIndex + 1].stories[0].mediaUrl!} alt="preload" />
          )}
        </div>

      </div>
    </div>
  );
}
