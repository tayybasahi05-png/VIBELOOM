import { useState, useRef, useEffect } from "react";
import { useGetSession, useRequestStoryUploadUrl, useFinalizeStoryUpload, useCreateStory } from "@workspace/api-client-react";
import { CameraView } from "./camera-view";
import { X, Send, Maximize, Minimize } from "lucide-react";

interface StoryComposerProps {
  onClose: () => void;
  onSuccess: () => void;
}

type ComposeMode = "camera" | "text" | "preview";

const VALID_MIMES = ["image/jpeg", "image/png", "image/webp", "video/mp4", "video/webm"];

export function StoryComposer({ onClose, onSuccess }: StoryComposerProps) {
  const { data: session } = useGetSession();
  const [mode, setMode] = useState<ComposeMode>("camera");
  const [mediaBlob, setMediaBlob] = useState<Blob | null>(null);
  const [mediaType, setMediaType] = useState<"image" | "video" | null>(null);
  const [mediaUrl, setMediaUrl] = useState<string | null>(null);
  const [videoDuration, setVideoDuration] = useState<number | undefined>(undefined);
  const [textContent, setTextContent] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [imageFit, setImageFit] = useState<"contain" | "cover">("contain");

  const [uploadState, setUploadState] = useState<{
    status: "idle" | "requesting" | "uploading" | "finalizing" | "error";
    progress: number;
    uploadUrlData?: { uploadURL: string; objectPath: string; contentType: string; durationSeconds?: number };
  }>({ status: "idle", progress: 0 });

  const requestUrl = useRequestStoryUploadUrl();
  const finalizeUpload = useFinalizeStoryUpload();
  const createStory = useCreateStory();

  const previewVideoRef = useRef<HTMLVideoElement>(null);
  const xhrRef = useRef<XMLHttpRequest | null>(null);

  useEffect(() => {
    return () => {
      if (mediaUrl) URL.revokeObjectURL(mediaUrl);
      if (xhrRef.current) xhrRef.current.abort();
    };
  }, [mediaUrl]);

  const handleCaptureImage = (blob: Blob) => {
    setMediaBlob(blob);
    setMediaType("image");
    setMediaUrl(URL.createObjectURL(blob));
    setMode("preview");
  };

  const handleCaptureVideo = (blob: Blob, duration?: number) => {
    setMediaBlob(blob);
    setMediaType("video");
    setMediaUrl(URL.createObjectURL(blob));
    setVideoDuration(duration);
    setMode("preview");
  };

  const handleGallerySelect = (file: File) => {
    setError(null);
    if (!VALID_MIMES.includes(file.type)) {
      setError("Unsupported file format. Use JPEG, PNG, WebP, MP4, or WebM.");
      return;
    }

    if (file.type.startsWith("image/")) {
      if (file.size > 10 * 1024 * 1024) {
        setError("Image must be under 10MB");
        return;
      }
      const url = URL.createObjectURL(file);
      const img = new Image();
      img.onload = () => {
        URL.revokeObjectURL(url);
        if (img.width > 4096 || img.height > 4096) {
          setError("Image dimensions must be 4096x4096 or smaller");
          return;
        }
        handleCaptureImage(file);
      };
      img.onerror = () => {
        URL.revokeObjectURL(url);
        setError("Invalid image file");
      };
      img.src = url;
    } else if (file.type.startsWith("video/")) {
      if (file.size > 50 * 1024 * 1024) {
        setError("Video must be under 50MB");
        return;
      }
      const url = URL.createObjectURL(file);
      const video = document.createElement("video");
      video.onloadedmetadata = () => {
        URL.revokeObjectURL(url);
        const duration = video.duration;
        if (!isFinite(duration) || duration <= 0 || duration > 15) {
          setError("Video must be between 1 and 15 seconds long.");
          return;
        }
        handleCaptureVideo(file, duration);
      };
      video.onerror = () => {
        URL.revokeObjectURL(url);
        setError("Invalid video file");
      };
      video.src = url;
    }
  };

  const handleCancelUpload = () => {
    if (xhrRef.current) {
      xhrRef.current.abort();
    }
    setUploadState(prev => ({ ...prev, status: "error" }));
    setError("Upload canceled.");
  };

  const handleSubmit = async (useExistingUrl = false) => {
    if (uploadState.status === "uploading" || uploadState.status === "requesting" || uploadState.status === "finalizing") return;
    setError(null);

    try {
      if (mode === "text") {
        if (!textContent.trim()) throw new Error("Text cannot be empty");
        setUploadState({ status: "requesting", progress: 0 });
        await createStory.mutateAsync({
          data: {
            type: "text",
            text: textContent.trim()
          }
        });
        onSuccess();
        return;
      }

      if (mediaBlob && mediaType) {
        let urlData = uploadState.uploadUrlData;
        
        if (!useExistingUrl || !urlData) {
          setUploadState({ status: "requesting", progress: 0 });
          
          const contentType = mediaBlob.type || (mediaType === "image" ? "image/jpeg" : "video/mp4");
          
          let durationSeconds = undefined;
          if (mediaType === "video") {
            durationSeconds = videoDuration ? Math.ceil(videoDuration) : Math.ceil(previewVideoRef.current?.duration || 0);
            if (!isFinite(durationSeconds) || durationSeconds <= 0 || durationSeconds > 15) {
              throw new Error("Video must be between 1 and 15 seconds long.");
            }
          }

          const reqRes = await requestUrl.mutateAsync({
            data: {
              name: `story-${Date.now()}.${mediaType === "image" ? "jpg" : "mp4"}`,
              size: mediaBlob.size,
              contentType: contentType as any,
              durationSeconds
            }
          });
          
          urlData = {
            uploadURL: reqRes.uploadURL,
            objectPath: reqRes.objectPath,
            contentType,
            durationSeconds
          };
          setUploadState(prev => ({ ...prev, uploadUrlData: urlData }));
        }

        setUploadState(prev => ({ ...prev, status: "uploading", progress: 0 }));

        await new Promise<void>((resolve, reject) => {
          const xhr = new XMLHttpRequest();
          xhrRef.current = xhr;
          
          xhr.upload.onprogress = (e) => {
            if (e.lengthComputable) {
              setUploadState(prev => ({ ...prev, progress: Math.round((e.loaded / e.total) * 100) }));
            }
          };
          
          xhr.onload = () => {
            if (xhr.status >= 200 && xhr.status < 300) {
              resolve();
            } else {
              reject(new Error("Upload failed with status " + xhr.status));
            }
          };
          
          xhr.onerror = () => reject(new Error("Network error during upload"));
          xhr.onabort = () => reject(new Error("Upload canceled"));
          
          xhr.open("PUT", urlData!.uploadURL);
          xhr.setRequestHeader("Content-Type", urlData!.contentType);
          xhr.send(mediaBlob);
        });

        setUploadState(prev => ({ ...prev, status: "finalizing" }));

        await finalizeUpload.mutateAsync({
          data: {
            objectPath: urlData!.objectPath,
            contentType: urlData!.contentType as any,
            size: mediaBlob.size,
            durationSeconds: urlData!.durationSeconds
          }
        });

        await createStory.mutateAsync({
          data: {
            type: mediaType,
            objectPath: urlData!.objectPath,
            contentType: urlData!.contentType,
            sizeBytes: mediaBlob.size,
            durationSeconds: urlData!.durationSeconds
          }
        });

        onSuccess();
      }
    } catch (err: any) {
      if (err.message !== "Upload canceled") {
        setError(err.message || "Failed to post story");
      }
      setUploadState(prev => ({ ...prev, status: "error" }));
    }
  };

  const getInitials = (name?: string) => name ? name.charAt(0).toUpperCase() : "?";
  const isUploading = ["requesting", "uploading", "finalizing"].includes(uploadState.status);
  const canRetry = uploadState.status === "error" && uploadState.uploadUrlData;

  const handleClearError = () => setError(null);

  if (mode === "camera") {
    return (
      <CameraView 
        onClose={onClose} 
        onCaptureImage={handleCaptureImage} 
        onCaptureVideo={handleCaptureVideo}
        onSelectGallery={handleGallerySelect}
        onSelectText={() => { setMode("text"); setError(null); }}
        error={error}
        onErrorClear={handleClearError}
      />
    );
  }

  return (
    <div className="fixed inset-0 bg-background z-50 flex flex-col md:max-w-md md:mx-auto md:border-x md:border-border overflow-hidden">
      <div className="flex items-center justify-between p-4 border-b border-border bg-card z-10">
        <button onClick={() => { setMode("camera"); setError(null); }} aria-label="Back to Camera" className="p-2 hover:bg-secondary rounded-full transition-colors" disabled={isUploading}>
          <X className="w-5 h-5 text-foreground" />
        </button>
        <div className="flex gap-2">
          {mode === "preview" && mediaType === "image" && (
            <button 
              onClick={() => setImageFit(prev => prev === "contain" ? "cover" : "contain")} 
              aria-label="Toggle Image Fit"
              className="p-2 hover:bg-secondary rounded-full text-foreground transition-colors" 
              disabled={isUploading}
            >
              {imageFit === "contain" ? <Maximize className="w-5 h-5" /> : <Minimize className="w-5 h-5" />}
            </button>
          )}
        </div>
      </div>

      <div className="flex-1 relative flex flex-col min-h-0 overflow-hidden">
        {error && !isUploading && (
          <div className="absolute top-4 left-4 right-4 bg-destructive text-destructive-foreground px-4 py-2 rounded-xl text-sm font-bold z-30 text-center shadow-lg">
            {error}
          </div>
        )}

        {isUploading && (
          <div className="absolute inset-0 z-30 bg-black/80 flex flex-col items-center justify-center p-8 backdrop-blur-sm">
            <div className="w-full max-w-xs bg-card rounded-2xl p-6 flex flex-col items-center gap-4 shadow-xl border border-border">
              <h3 className="font-bold text-foreground text-lg">
                {uploadState.status === "requesting" ? "Preparing..." : 
                 uploadState.status === "uploading" ? "Uploading..." : "Finalizing..."}
              </h3>
              <div className="w-full h-3 bg-secondary rounded-full overflow-hidden">
                <div className="h-full bg-primary transition-all duration-200" style={{ width: `${uploadState.progress}%` }} />
              </div>
              <p className="text-sm font-bold text-muted-foreground">{uploadState.progress}%</p>
              {uploadState.status === "uploading" && (
                <button onClick={handleCancelUpload} className="mt-4 text-sm text-destructive hover:bg-destructive/10 rounded-lg font-bold px-6 py-2 transition-colors">
                  Cancel
                </button>
              )}
            </div>
          </div>
        )}

        {mode === "text" ? (
          <div className="flex-1 flex items-center justify-center p-8 bg-gradient-to-br from-primary/10 to-accent/10">
            <textarea
              autoFocus
              value={textContent}
              onChange={(e) => setTextContent(e.target.value)}
              placeholder="What's on your mind?"
              className="w-full h-full bg-transparent text-center text-3xl font-serif font-bold text-foreground resize-none focus:outline-none placeholder:text-muted-foreground/50"
              maxLength={280}
              disabled={isUploading}
            />
          </div>
        ) : (
          <div className="flex-1 bg-black relative flex items-center justify-center overflow-hidden">
            {mediaType === "image" && mediaUrl && (
              <img src={mediaUrl} alt="Preview" className={`w-full h-full ${imageFit === "cover" ? "object-cover" : "object-contain"}`} />
            )}
            {mediaType === "video" && mediaUrl && (
              <video ref={previewVideoRef} src={mediaUrl} autoPlay loop playsInline className="w-full h-full object-contain" />
            )}
          </div>
        )}

        <div className="p-4 bg-card border-t border-border flex items-center gap-4 z-10">
          <div className="shrink-0">
            {session?.user?.avatarUrl ? (
              <img src={session.user.avatarUrl} alt="You" className="w-10 h-10 rounded-full object-cover border border-border" />
            ) : (
              <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center text-secondary-foreground font-bold border border-border">
                {getInitials(session?.user?.name)}
              </div>
            )}
          </div>
          
          {canRetry ? (
            <button 
              onClick={() => handleSubmit(true)} 
              className="flex-1 py-3 px-6 bg-accent text-accent-foreground font-bold rounded-xl flex items-center justify-center gap-2 hover:bg-accent/90 transition-colors"
            >
              Retry Upload
              <Send className="w-4 h-4" />
            </button>
          ) : (
            <button 
              onClick={() => handleSubmit(false)} 
              disabled={isUploading || (mode === "text" && !textContent.trim())}
              className="flex-1 py-3 px-6 bg-primary text-primary-foreground font-bold rounded-xl flex items-center justify-center gap-2 hover:bg-primary/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Share Story
              <Send className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
