import { StoryGroup, useGetSession } from "@workspace/api-client-react";
import { Plus } from "lucide-react";

interface StoriesTrayProps {
  groups: StoryGroup[];
  onOpenViewer: (groupIndex: number) => void;
  onOpenComposer: () => void;
}

export function StoriesTray({ groups, onOpenViewer, onOpenComposer }: StoriesTrayProps) {
  const { data: session } = useGetSession();
  
  // See if user has their own story active
  const userGroupIndex = groups.findIndex(g => g.author.id === session?.user?.id);
  const userHasStory = userGroupIndex !== -1;

  const getInitials = (name?: string) => name ? name.charAt(0).toUpperCase() : "?";

  return (
    <div className="w-full bg-card rounded-3xl border border-border p-4 mb-6 shadow-sm overflow-hidden flex items-center">
      <div className="flex gap-4 overflow-x-auto custom-scrollbar pb-2 pt-1 px-1 flex-nowrap shrink-0 max-w-full">
        
        {/* Add Story Button / Current User Story */}
        <div className="flex flex-col items-center gap-2 shrink-0 w-20">
          <button 
            onClick={() => userHasStory ? onOpenViewer(userGroupIndex) : onOpenComposer()}
            aria-label={userHasStory ? "View Your Story" : "Add Story"}
            className="relative group focus:outline-none"
          >
            <div className={`w-16 h-16 rounded-full p-[2px] transition-transform group-hover:scale-105 group-active:scale-95 ${userHasStory ? 'bg-gradient-to-tr from-accent to-primary' : 'bg-transparent border-2 border-dashed border-border'}`}>
              {session?.user?.avatarUrl ? (
                <img 
                  src={session.user.avatarUrl} 
                  alt="You" 
                  className="w-full h-full rounded-full object-cover border-2 border-card"
                />
              ) : (
                <div className="w-full h-full rounded-full border-2 border-card bg-secondary flex items-center justify-center text-secondary-foreground font-bold text-xl">
                  {getInitials(session?.user?.name)}
                </div>
              )}
            </div>
            {!userHasStory && (
              <div className="absolute bottom-0 right-0 w-5 h-5 bg-primary rounded-full flex items-center justify-center border-2 border-card shadow-sm text-primary-foreground">
                <Plus className="w-3 h-3 font-bold" />
              </div>
            )}
          </button>
          <span className="text-[11px] font-bold text-foreground truncate w-full text-center tracking-tight">Your Story</span>
        </div>

        {/* Other Stories */}
        {groups.map((group, idx) => {
          if (group.author.id === session?.user?.id) return null; // Handled above
          return (
            <div key={group.author.id} className="flex flex-col items-center gap-2 shrink-0 w-20">
              <button 
                onClick={() => onOpenViewer(idx)}
                aria-label={`View story by ${group.author.name}`}
                className="relative group focus:outline-none"
              >
                <div className={`w-16 h-16 rounded-full p-[2px] transition-transform group-hover:scale-105 group-active:scale-95 ${group.hasUnviewed ? 'bg-gradient-to-tr from-accent to-primary' : 'bg-muted border border-border'}`}>
                  {group.author.avatarUrl ? (
                    <img 
                      src={group.author.avatarUrl} 
                      alt={group.author.name} 
                      className="w-full h-full rounded-full object-cover border-2 border-card"
                    />
                  ) : (
                    <div className="w-full h-full rounded-full border-2 border-card bg-secondary flex items-center justify-center text-secondary-foreground font-bold text-xl">
                      {getInitials(group.author.name)}
                    </div>
                  )}
                </div>
              </button>
              <span className={`text-[11px] truncate w-full text-center tracking-tight ${group.hasUnviewed ? 'font-bold text-foreground' : 'font-medium text-muted-foreground'}`}>
                {group.author.name}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
