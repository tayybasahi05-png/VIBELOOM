import { useState, useRef, useEffect } from "react";
import {
  useListGifts,
  useGetWallet,
  useListCoinPacks,
  useCreateCoinCheckout,
  useSendGift,
  getGetWalletQueryKey,
  getGetLiveRoomQueryKey,
  getListSentGiftsQueryKey,
  getListReceivedGiftsQueryKey,
  Gift as GiftType,
  CoinPack
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import {
  Gift,
  X,
  Coins,
  Loader2,
  ChevronRight,
  ArrowLeft,
  CheckCircle2,
  AlertCircle
} from "lucide-react";

export function GiftPanel({ roomId, receiverId, onClose, isHost }: { roomId: string, receiverId: string, onClose: () => void, isHost: boolean }) {
  const [view, setView] = useState<"catalog" | "buy_coins" | "history">("catalog");

  return (
    <div className="absolute inset-0 z-50 bg-black/60 backdrop-blur-sm flex flex-col justify-end">
      <div className="bg-card w-full h-[85%] sm:h-[70%] max-w-lg mx-auto sm:mb-8 sm:rounded-3xl rounded-t-3xl border border-border flex flex-col animate-in slide-in-from-bottom-full shadow-2xl overflow-hidden">
        {view === "catalog" && (
          <GiftCatalog 
            roomId={roomId}
            receiverId={receiverId}
            onClose={onClose} 
            onGoToBuyCoins={() => setView("buy_coins")} 
            onGoToHistory={() => setView("history")} 
            isHost={isHost}
          />
        )}
        {view === "buy_coins" && (
          <BuyCoins roomId={roomId} onBack={() => setView("catalog")} />
        )}
        {view === "history" && (
          <HistoryView onBack={() => setView("catalog")} isHost={isHost} />
        )}
      </div>
    </div>
  );
}

function GiftCatalog({ roomId, receiverId, onClose, onGoToBuyCoins, onGoToHistory, isHost }: { roomId: string, receiverId: string, onClose: () => void, onGoToBuyCoins: () => void, onGoToHistory: () => void, isHost: boolean }) {
  const { data: gifts, isLoading: isLoadingGifts } = useListGifts();
  const { data: wallet, isLoading: isLoadingWallet } = useGetWallet();
  const [selectedGift, setSelectedGift] = useState<GiftType | null>(null);
  const [quantity, setQuantity] = useState(1);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const idempotencyKey = useRef<string>(crypto.randomUUID());
  
  const sendGift = useSendGift({
    mutation: {
      onSuccess: () => {
        toast({ title: "Gift sent!", description: `You sent ${quantity} ${selectedGift?.name}(s)` });
        queryClient.invalidateQueries({ queryKey: getGetWalletQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetLiveRoomQueryKey(roomId) });
        queryClient.invalidateQueries({ queryKey: getListSentGiftsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getListReceivedGiftsQueryKey() });
        // Reset state for next send
        idempotencyKey.current = crypto.randomUUID();
        setSelectedGift(null);
        setQuantity(1);
      },
      onError: (err: any) => {
        toast({ title: "Failed to send", description: err.message || "Something went wrong", variant: "destructive" });
      }
    },
    request: {
      headers: {
        'Idempotency-Key': idempotencyKey.current
      }
    }
  });

  const totalCost = (selectedGift?.coinCost || 0) * quantity;
  const canAfford = wallet && totalCost <= wallet.coinBalance;

  const handleSend = () => {
    if (!selectedGift || !canAfford || sendGift.isPending) return;
    
    sendGift.mutate({
      roomId,
      data: {
        giftId: selectedGift.id,
        quantity
      }
    });
  };

  return (
    <>
      <div className="p-4 flex items-center justify-between border-b border-border bg-card sticky top-0 z-10">
        <h3 className="font-serif text-xl font-bold flex items-center gap-2">
          <Gift className="w-5 h-5 text-primary" />
          Send a Gift
        </h3>
        <div className="flex items-center gap-2">
          <button onClick={onGoToHistory} className="text-xs font-bold text-muted-foreground hover:text-foreground px-3 py-1.5 bg-secondary rounded-full">
            History
          </button>
          <button onClick={onClose} className="p-2 bg-secondary rounded-full text-muted-foreground hover:text-foreground transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="flex-1 p-4 overflow-y-auto custom-scrollbar">
        {isLoadingGifts ? (
          <div className="grid grid-cols-3 sm:grid-cols-4 gap-3 animate-pulse">
            {[1,2,3,4,5,6,7,8].map(i => <div key={i} className="bg-secondary rounded-2xl aspect-square" />)}
          </div>
        ) : (
          <div className="grid grid-cols-3 sm:grid-cols-4 gap-3">
            {gifts?.filter(g => g.active).map(gift => (
              <button
                key={gift.id}
                onClick={() => setSelectedGift(gift)}
                className={`flex flex-col items-center justify-center p-3 rounded-2xl border-2 transition-all ${
                  selectedGift?.id === gift.id 
                    ? "border-primary bg-primary/10 shadow-sm" 
                    : "border-transparent bg-secondary hover:bg-secondary/80"
                }`}
              >
                <div className="w-12 h-12 mb-2 bg-black/5 rounded-full flex items-center justify-center">
                  {gift.iconUrl && /^(https?:|data:)/.test(gift.iconUrl) ? (
                    <img src={gift.iconUrl} alt={gift.name} className="w-8 h-8 object-contain" />
                  ) : gift.iconUrl ? (
                    <span className="text-3xl" aria-hidden="true">{gift.iconUrl}</span>
                  ) : (
                    <Gift className="w-6 h-6 text-primary" />
                  )}
                </div>
                <span className="text-xs font-bold text-foreground text-center line-clamp-1">{gift.name}</span>
                <span className="text-[10px] font-semibold text-muted-foreground flex items-center gap-1 mt-1">
                  <Coins className="w-3 h-3 text-accent" />
                  {gift.coinCost}
                </span>
              </button>
            ))}
          </div>
        )}
      </div>

      <div className="p-4 border-t border-border bg-card/95 backdrop-blur">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-accent/10 flex items-center justify-center">
              <Coins className="w-4 h-4 text-accent" />
            </div>
            <div className="flex flex-col">
              <span className="text-xs font-medium text-muted-foreground">Balance</span>
              {isLoadingWallet ? (
                <div className="w-12 h-4 bg-secondary animate-pulse rounded" />
              ) : (
                <span className="text-sm font-bold text-foreground">{wallet?.coinBalance.toLocaleString()} {wallet?.currency}</span>
              )}
            </div>
          </div>
          <button onClick={onGoToBuyCoins} className="text-sm font-bold text-primary flex items-center gap-1 hover:underline">
            Get more <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="flex items-center gap-3">
          {selectedGift && (
            <div className="flex items-center bg-secondary rounded-xl overflow-hidden shrink-0">
              <button 
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="px-3 py-3 hover:bg-black/5 active:bg-black/10 transition-colors text-foreground font-bold"
              >
                -
              </button>
              <div className="w-10 text-center font-bold text-sm">
                {quantity}
              </div>
              <button 
                onClick={() => setQuantity(quantity + 1)}
                className="px-3 py-3 hover:bg-black/5 active:bg-black/10 transition-colors text-foreground font-bold"
              >
                +
              </button>
            </div>
          )}
          
          <button 
            disabled={!selectedGift || sendGift.isPending}
            onClick={handleSend}
            className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl font-bold text-white transition-all shadow-md
              ${!selectedGift 
                ? "bg-secondary text-muted-foreground shadow-none" 
                : canAfford
                  ? "bg-gradient-to-r from-purple-500 to-pink-500 hover:opacity-90 active:scale-[0.98]"
                  : "bg-destructive text-destructive-foreground hover:bg-destructive/90 active:scale-[0.98]"
              }`}
          >
            {sendGift.isPending ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : !selectedGift ? (
              "Select a Gift"
            ) : !canAfford ? (
              `Need ${totalCost - (wallet?.coinBalance || 0)} more coins`
            ) : (
              <>Send {quantity > 1 ? `${quantity} ` : ''}for {totalCost} <Coins className="w-4 h-4" /></>
            )}
          </button>
        </div>
      </div>
    </>
  );
}

function BuyCoins({ roomId, onBack }: { roomId: string; onBack: () => void }) {
  const { data: packs, isLoading } = useListCoinPacks();
  const checkout = useCreateCoinCheckout();
  const checkoutKeys = useRef<Record<string, string>>({});

  const handleBuy = (packId: string) => {
    const idempotencyKey =
      checkoutKeys.current[packId] ??
      (checkoutKeys.current[packId] = crypto.randomUUID());
    checkout.mutate({ data: { packId, idempotencyKey, roomId } }, {
      onSuccess: (data) => {
        window.location.href = data.url;
      }
    });
  };

  return (
    <>
      <div className="p-4 flex items-center gap-3 border-b border-border bg-card sticky top-0 z-10">
        <button onClick={onBack} className="p-2 -ml-2 hover:bg-secondary rounded-full transition-colors">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h3 className="font-serif text-xl font-bold">Get Coins</h3>
      </div>
      <div className="flex-1 p-4 overflow-y-auto custom-scrollbar">
        {isLoading ? (
          <div className="space-y-3 animate-pulse">
            {[1,2,3].map(i => <div key={i} className="h-20 bg-secondary rounded-2xl" />)}
          </div>
        ) : (
          <div className="space-y-3">
            {packs?.map(pack => (
              <div key={pack.id} className="flex items-center justify-between p-4 bg-secondary rounded-2xl border border-transparent hover:border-primary/20 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-accent/20 flex items-center justify-center">
                    <Coins className="w-6 h-6 text-accent" />
                  </div>
                  <div>
                    <h4 className="font-bold text-foreground">{pack.coinAmount.toLocaleString()} Coins</h4>
                    <p className="text-xs font-medium text-muted-foreground">+Bonus available</p>
                  </div>
                </div>
                <button 
                  onClick={() => handleBuy(pack.id)}
                  disabled={checkout.isPending}
                  className="px-4 py-2 bg-card border-2 border-primary text-primary font-bold rounded-xl hover:bg-primary hover:text-primary-foreground transition-colors"
                >
                  ${(pack.priceCents / 100).toFixed(2)}
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </>
  );
}

import { useListSentGifts, useListReceivedGifts } from "@workspace/api-client-react";

function HistoryView({ onBack, isHost }: { onBack: () => void, isHost: boolean }) {
  const { data: sentGifts, isLoading: isLoadingSent } = useListSentGifts();
  const { data: receivedGifts, isLoading: isLoadingReceived } = useListReceivedGifts();

  const gifts = isHost ? receivedGifts : sentGifts;
  const isLoading = isHost ? isLoadingReceived : isLoadingSent;

  return (
    <>
      <div className="p-4 flex items-center gap-3 border-b border-border bg-card sticky top-0 z-10">
        <button onClick={onBack} className="p-2 -ml-2 hover:bg-secondary rounded-full transition-colors">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h3 className="font-serif text-xl font-bold">{isHost ? "Gifts Received" : "Gifts Sent"}</h3>
      </div>
      <div className="flex-1 p-4 overflow-y-auto custom-scrollbar">
        {isLoading ? (
          <div className="space-y-3 animate-pulse">
            {[1,2,3].map(i => <div key={i} className="h-16 bg-secondary rounded-2xl" />)}
          </div>
        ) : gifts?.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-40 text-muted-foreground">
            <Gift className="w-8 h-8 mb-2 opacity-20" />
            <p className="font-medium">No history yet</p>
          </div>
        ) : (
          <div className="space-y-3">
            {gifts?.map(gift => (
              <div key={gift.id} className="flex items-center justify-between p-3 bg-secondary rounded-2xl">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-card flex items-center justify-center">
                    <Gift className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-foreground">
                      {gift.quantity}x Gift #{gift.giftId.slice(0,4)}
                    </h4>
                    <p className="text-xs text-muted-foreground">
                      {new Date(gift.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>
                <div className="font-bold text-sm flex items-center gap-1">
                  {isHost ? "+" : "-"}{gift.totalCoins} <Coins className="w-3 h-3 text-accent" />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </>
  );
}
