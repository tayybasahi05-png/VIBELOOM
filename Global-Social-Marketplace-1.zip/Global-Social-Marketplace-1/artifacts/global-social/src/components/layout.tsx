import { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import {
  getListNotificationsQueryKey,
  useGetSession,
  useListNotifications,
} from "@workspace/api-client-react";
import { useClerk } from "@clerk/react";
import { 
  Home, 
  ShoppingBag, 
  MessageCircle, 
  Search, 
  Radio, 
  Award, 
  Wallet, 
  Bell, 
  LogOut,
  User as UserIcon,
  FileText,
  Users,
  Image as ImageIcon,
  Megaphone
} from "lucide-react";

const PRIMARY_NAV = [
  { path: "/home", label: "Home", icon: Home },
  { path: "/market", label: "Market", icon: ShoppingBag },
  { path: "/live", label: "Live", icon: Radio },
  { path: "/inbox", label: "Inbox", icon: MessageCircle },
  { path: "/profile", label: "Profile", icon: UserIcon },
];

const EXPLORE_NAV = [
  { path: "/notifications", label: "Notifications", icon: Bell },
  { path: "/opportunities", label: "Opportunities", icon: Award },
  { path: "/blogs", label: "Blogs", icon: FileText },
  { path: "/communities", label: "Communities", icon: Users },
  { path: "/wallet", label: "Wallet", icon: Wallet },
  { path: "/media", label: "Media", icon: ImageIcon },
  { path: "/advertising", label: "Advertising", icon: Megaphone },
];

export function Layout({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const { signOut } = useClerk();
  const { data: session } = useGetSession();
  const { data: notifications } = useListNotifications({
    query: {
      queryKey: getListNotificationsQueryKey(),
      refetchInterval: 15_000,
    },
  });
  const unreadNotificationCount =
    notifications?.filter((notification) => !notification.read).length ?? 0;

  return (
    <div className="min-h-[100dvh] bg-background noise-bg flex flex-col md:flex-row">
      {/* Sidebar for Desktop */}
      <aside className="hidden md:flex w-72 flex-col border-r border-border bg-card p-6 gap-8 sticky top-0 h-screen overflow-y-auto custom-scrollbar">
        <Link href="/home" className="flex items-center gap-3 shrink-0">
          <img src={`${import.meta.env.BASE_URL}vibeloom-logo.jpeg`} alt="" className="h-11 w-11 rounded-xl border border-border object-cover shadow-sm" />
          <span className="font-serif text-2xl font-semibold text-foreground tracking-tight">VibeLoom</span>
        </Link>
        
        <div className="flex-1 space-y-8">
          <div>
            <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-4 px-2">Primary</h3>
            <nav className="space-y-1">
              {PRIMARY_NAV.map((item) => {
                const active = location.startsWith(item.path);
                return (
                  <Link
                    key={item.path}
                    href={item.path}
                    className={`flex items-center justify-between px-4 py-3 rounded-xl transition-all ${
                      active 
                        ? "bg-primary text-primary-foreground font-semibold shadow-sm" 
                        : "text-muted-foreground hover:bg-secondary hover:text-foreground font-medium"
                    }`}
                  >
                    <div className="flex items-center gap-4">
                      <item.icon className="w-5 h-5" />
                      {item.label}
                    </div>
                    {item.path === "/inbox" && session?.unreadCount ? (
                      <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${active ? "bg-primary-foreground text-primary" : "bg-accent text-accent-foreground"}`}>
                        {session.unreadCount}
                      </span>
                    ) : null}
                  </Link>
                );
              })}
            </nav>
          </div>

          <div>
            <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-4 px-2">Explore</h3>
            <nav className="space-y-1">
              {EXPLORE_NAV.map((item) => {
                const active = location.startsWith(item.path);
                return (
                  <Link
                    key={item.path}
                    href={item.path}
                    className={`flex items-center justify-between px-4 py-3 rounded-xl transition-all ${
                      active 
                        ? "bg-secondary text-foreground font-semibold" 
                        : "text-muted-foreground hover:bg-secondary hover:text-foreground font-medium"
                    }`}
                  >
                    <span className="flex items-center gap-4">
                      <item.icon className="w-5 h-5" />
                      {item.label}
                    </span>
                    {item.path === "/notifications" && unreadNotificationCount > 0 ? (
                      <span className="min-w-6 rounded-full bg-accent px-2 py-0.5 text-center text-xs font-bold text-accent-foreground">
                        {unreadNotificationCount}
                      </span>
                    ) : null}
                  </Link>
                );
              })}
            </nav>
          </div>
        </div>

        {session?.user && (
          <div className="flex items-center gap-3 pt-6 border-t border-border shrink-0 mt-auto">
            <Link href="/profile" className="shrink-0 block">
              {session.user.avatarUrl ? (
                <img src={session.user.avatarUrl} alt={session.user.name} className="w-10 h-10 rounded-full object-cover bg-secondary border border-border" />
              ) : (
                <span className="flex h-10 w-10 items-center justify-center rounded-full border border-border bg-secondary text-sm font-bold text-foreground">
                  {session.user.name.charAt(0).toUpperCase()}
                </span>
              )}
            </Link>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold text-foreground truncate">{session.user.name}</p>
              <p className="text-xs text-muted-foreground truncate">{session.user.handle}</p>
            </div>
            <button onClick={() => signOut({ redirectUrl: "/" })} className="p-2 text-muted-foreground hover:text-destructive transition-colors rounded-lg hover:bg-destructive/10" aria-label="Sign out">
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        )}
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 pb-20 md:pb-0 relative h-[100dvh] overflow-y-auto">
        {/* Mobile Header (Home header mostly, but visible everywhere on mobile) */}
        <header className="md:hidden sticky top-0 z-40 bg-card/90 backdrop-blur-xl border-b border-border flex items-center justify-between p-4 shadow-sm">
          <Link href="/home" className="flex items-center gap-2">
            <img src={`${import.meta.env.BASE_URL}vibeloom-logo.jpeg`} alt="" className="h-9 w-9 rounded-lg border border-border object-cover shadow-sm" />
            <span className="font-serif text-xl font-semibold text-foreground tracking-tight">VibeLoom</span>
          </Link>
          <div className="flex items-center gap-3">
            <Link href="/search" className="text-foreground p-2 hover:bg-secondary rounded-full transition-colors">
              <Search className="w-5 h-5" />
            </Link>
            <Link href="/notifications" className="text-foreground p-2 hover:bg-secondary rounded-full transition-colors relative">
              <Bell className="w-5 h-5" />
            </Link>
            {session?.user && (
              <Link href="/profile" className="block shrink-0 ml-1">
                {session.user.avatarUrl ? (
                  <img src={session.user.avatarUrl} alt="Profile" className="w-8 h-8 rounded-full object-cover bg-secondary border-2 border-primary/20" />
                ) : (
                  <span className="flex h-8 w-8 items-center justify-center rounded-full border-2 border-primary/20 bg-secondary text-xs font-bold text-foreground">
                    {session.user.name.charAt(0).toUpperCase()}
                  </span>
                )}
              </Link>
            )}
          </div>
        </header>

        <div className="flex-1 w-full max-w-4xl mx-auto p-4 md:p-8">
          {children}
        </div>
      </main>

      {/* Mobile Bottom Nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-card border-t border-border flex items-center justify-around p-2 pb-[env(safe-area-inset-bottom)] shadow-[0_-4px_20px_rgba(0,0,0,0.05)] dark:shadow-none">
        {[
          { path: "/home", icon: Home, label: "Home" },
          { path: "/market", icon: ShoppingBag, label: "Market" },
          { path: "/live", icon: Radio, label: "Live" },
          { path: "/inbox", icon: MessageCircle, label: "Inbox" },
          { path: "/profile", icon: UserIcon, label: "Profile" },
        ].map((item) => {
          const active = location.startsWith(item.path);
          return (
            <Link
              key={item.path}
              href={item.path}
              className={`flex flex-col items-center justify-center w-16 h-12 rounded-xl transition-all ${
                active ? "text-primary" : "text-muted-foreground"
              }`}
            >
              <div className="relative">
                <item.icon className={`w-6 h-6 ${active ? "fill-primary/20" : ""}`} />
                {item.path === "/inbox" && session?.unreadCount ? (
                  <span className="absolute -top-1.5 -right-1.5 w-4 h-4 bg-accent text-accent-foreground text-[10px] font-bold rounded-full flex items-center justify-center border border-card">
                    {session.unreadCount}
                  </span>
                ) : null}
              </div>
              <span className="text-[10px] font-semibold leading-none mt-1">{item.label}</span>
            </Link>
          )
        })}
      </nav>
    </div>
  );
}
