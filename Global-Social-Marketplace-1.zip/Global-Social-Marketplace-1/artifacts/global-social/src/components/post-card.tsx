import { Heart, MessageCircle, Share2, Bookmark, CheckCircle2 } from "lucide-react";
import { useLikePost, useSavePost, getGetFeedQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import type { Post } from "@workspace/api-client-react";

export function PostCard({ post }: { post: Post }) {
  const queryClient = useQueryClient();
  const likeMutation = useLikePost();
  const saveMutation = useSavePost();

  const handleLike = () => {
    likeMutation.mutate({ postId: post.id }, {
      onSuccess: (res) => {
        // Optimistic update in real app, here we just invalidate
        queryClient.invalidateQueries({ queryKey: getGetFeedQueryKey() });
      }
    });
  };

  const handleSave = () => {
    saveMutation.mutate({ postId: post.id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetFeedQueryKey() });
      }
    });
  };

  return (
    <article className="bg-card rounded-3xl border border-border shadow-sm overflow-hidden mb-6 transition-all hover-elevate">
      {/* Header */}
      <div className="p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <img src={post.author.avatarUrl} alt={post.author.name} className="w-12 h-12 rounded-full object-cover bg-secondary" />
          <div>
            <div className="flex items-center gap-1.5">
              <h3 className="font-bold text-foreground">{post.author.name}</h3>
              {post.author.verified && <CheckCircle2 className="w-4 h-4 text-primary fill-primary text-card" />}
            </div>
            <p className="text-sm text-muted-foreground">@{post.author.handle} · {post.author.role}</p>
          </div>
        </div>
        {post.sponsored && (
          <span className="text-[10px] uppercase font-bold tracking-wider text-muted-foreground border border-border px-2 py-1 rounded-full">
            Sponsored
          </span>
        )}
      </div>

      {/* Content */}
      <div className="px-4 pb-3">
        <p className="text-foreground leading-relaxed whitespace-pre-wrap">{post.body}</p>
      </div>

      {/* Media */}
      {post.mediaUrl && (
        <div className="w-full bg-secondary aspect-[4/3] sm:aspect-video relative overflow-hidden">
          {post.mediaType === "video" ? (
            <video src={post.mediaUrl} controls playsInline className="h-full w-full object-cover">
              Your browser does not support video playback.
            </video>
          ) : (
            <img src={post.mediaUrl} alt="Post media" className="w-full h-full object-cover" />
          )}
        </div>
      )}

      {/* Actions */}
      <div className="p-4 flex items-center justify-between border-t border-border/50">
        <div className="flex items-center gap-6">
          <button 
            onClick={handleLike}
            disabled={likeMutation.isPending}
            className={`flex items-center gap-2 font-medium transition-colors ${post.liked ? 'text-destructive' : 'text-muted-foreground hover:text-foreground'}`}
          >
            <Heart className={`w-5 h-5 ${post.liked ? 'fill-current' : ''}`} />
            <span>{post.likes}</span>
          </button>
          <button className="flex items-center gap-2 text-muted-foreground hover:text-foreground font-medium transition-colors">
            <MessageCircle className="w-5 h-5" />
            <span>{post.comments}</span>
          </button>
          <button className="flex items-center gap-2 text-muted-foreground hover:text-foreground font-medium transition-colors">
            <Share2 className="w-5 h-5" />
            <span>{post.shares}</span>
          </button>
        </div>
        <button 
          onClick={handleSave}
          disabled={saveMutation.isPending}
          className={`p-2 rounded-full transition-colors ${post.saved ? 'bg-primary/10 text-primary' : 'text-muted-foreground hover:bg-secondary'}`}
        >
          <Bookmark className={`w-5 h-5 ${post.saved ? 'fill-current' : ''}`} />
        </button>
      </div>
    </article>
  );
}