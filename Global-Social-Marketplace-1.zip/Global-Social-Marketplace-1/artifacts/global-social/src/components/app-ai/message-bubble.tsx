import { useState } from "react";
import { Check, Copy, Flag, Loader2, ThumbsDown, ThumbsUp } from "lucide-react";
import {
  useRateAppAiMessage,
  useReportAppAiMessage,
  type AppAiConversationDetail,
  type AppAiMessage,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { getGetAppAiConversationQueryKey } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";

function textDirection(content: string): "rtl" | "ltr" {
  return /[\u0600-\u06ff]/.test(content) ? "rtl" : "ltr";
}

// Helper for formatting markdown-like text to legible elements
function FormattedText({ content }: { content: string }) {
  const blocks = content.split('\n\n').filter(b => b.trim());
  
  return (
    <div className="space-y-4">
      {blocks.map((block, i) => {
        // Detect numbered lists: "1. Item\n2. Item"
        if (/^\d+\.\s/.test(block)) {
          const items = block.split('\n').filter(item => /^\d+\.\s/.test(item));
          if (items.length > 0) {
            return (
              <ol key={i} className="list-decimal list-outside ml-6 space-y-2.5">
                {items.map((item, j) => {
                  const text = item.replace(/^\d+\.\s/, '');
                  return <li key={j} className="pl-1 leading-relaxed text-foreground/90">{renderInline(text)}</li>;
                })}
              </ol>
            );
          }
        }
        
        // Detect bullet lists: "- Item" or "* Item"
        if (/^[-*]\s/.test(block)) {
          const items = block.split('\n').filter(item => /^[-*]\s/.test(item));
          if (items.length > 0) {
            return (
              <ul key={i} className="list-disc list-outside ml-6 space-y-2.5">
                {items.map((item, j) => {
                  const text = item.replace(/^[-*]\s/, '');
                  return <li key={j} className="pl-1 leading-relaxed text-foreground/90">{renderInline(text)}</li>;
                })}
              </ul>
            );
          }
        }

        return <p key={i} className="leading-relaxed text-foreground/90">{renderInline(block)}</p>;
      })}
    </div>
  );
}

function renderInline(text: string) {
  // Handle bold **text**
  const parts = text.split(/(\*\*.*?\*\*)/g);
  return parts.map((part, index) => {
    if (part.startsWith('**') && part.endsWith('**')) {
      return <strong key={index} className="font-bold text-foreground">{part.slice(2, -2)}</strong>;
    }
    return <span key={index}>{part}</span>;
  });
}

export function AppAiMessageBubble({ message, conversationId }: { message: AppAiMessage, conversationId: number }) {
  const isUser = message.role === "user";
  const rateMessage = useRateAppAiMessage();
  const reportMessage = useReportAppAiMessage();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);
  const [reportOpen, setReportOpen] = useState(false);
  const [reportReason, setReportReason] = useState("");
  const [reported, setReported] = useState(false);

  const handleRate = (helpful: boolean) => {
    if (message.helpful === helpful) return; // already rated same
    rateMessage.mutate(
      { messageId: message.id, data: { helpful } },
      {
        onSuccess: (updatedMessage) => {
          // Update cache locally for immediate feedback
          queryClient.setQueryData(
            getGetAppAiConversationQueryKey(conversationId),
            (old: AppAiConversationDetail | undefined) => {
              if (!old) return old;
              return {
                ...old,
                messages: old.messages.map((m) =>
                  m.id === updatedMessage.id ? updatedMessage : m
                )
              };
            }
          );
        }
      }
    );
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(message.content);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1500);
    } catch {
      toast({
        title: "Copy failed",
        description: "Select the response text and copy it manually.",
        variant: "destructive",
      });
    }
  };

  const handleReport = (event: React.FormEvent) => {
    event.preventDefault();
    const reason = reportReason.trim();
    if (reason.length < 3) return;
    reportMessage.mutate(
      { messageId: message.id, data: { reason } },
      {
        onSuccess: () => {
          setReported(true);
          setReportOpen(false);
          setReportReason("");
          toast({
            title: "Response reported",
            description: "Thank you. The report was saved for review.",
          });
        },
      },
    );
  };

  return (
    <div className={`flex w-full ${isUser ? "justify-end" : "justify-start"} mb-6`}>
      <div className={`flex flex-col gap-2.5 max-w-[90%] md:max-w-[75%]`}>
        <div
          dir={textDirection(message.content)}
          className={`
            p-5 sm:p-6 rounded-3xl
            ${isUser 
              ? "bg-primary text-primary-foreground rounded-tr-sm shadow-sm" 
              : "bg-card border-2 border-border text-foreground rounded-tl-sm shadow-sm"
            }
          `}
        >
          {isUser ? (
            <div className="whitespace-pre-wrap leading-relaxed text-[15px]">{message.content}</div>
          ) : (
            <div className="text-[15px]"><FormattedText content={message.content} /></div>
          )}
        </div>
        
        {!isUser && (
          <div className="flex items-center gap-1.5 pl-2">
            <button
              type="button"
              onClick={handleCopy}
              className="p-2 rounded-xl text-muted-foreground transition-all hover:bg-secondary hover:text-foreground"
              aria-label="Copy response"
              title="Copy response"
            >
              {copied ? <Check className="w-4 h-4 text-primary" /> : <Copy className="w-4 h-4" />}
            </button>
            <button 
              onClick={() => handleRate(true)}
              disabled={rateMessage.isPending}
              className={`p-2 rounded-xl transition-all ${message.helpful === true ? 'text-primary bg-primary/15' : 'text-muted-foreground hover:bg-secondary hover:text-foreground'}`}
              aria-label="Helpful"
              title="Helpful"
            >
              <ThumbsUp className="w-4 h-4" />
            </button>
            <button 
              onClick={() => handleRate(false)}
              disabled={rateMessage.isPending}
              className={`p-2 rounded-xl transition-all ${message.helpful === false ? 'text-destructive bg-destructive/15' : 'text-muted-foreground hover:bg-secondary hover:text-foreground'}`}
              aria-label="Not helpful"
              title="Not helpful"
            >
              <ThumbsDown className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => setReportOpen(true)}
              disabled={reported}
              className={`p-2 rounded-xl transition-all ${
                reported
                  ? "text-primary bg-primary/10"
                  : "text-muted-foreground hover:bg-secondary hover:text-foreground"
              }`}
              aria-label={reported ? "Response reported" : "Report response"}
              title={reported ? "Response reported" : "Report response"}
            >
              {reported ? <Check className="w-4 h-4" /> : <Flag className="w-4 h-4" />}
            </button>
          </div>
        )}
      </div>
      <Dialog open={reportOpen} onOpenChange={setReportOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="font-serif text-2xl">Report this response</DialogTitle>
            <DialogDescription>
              Tell us what was inaccurate, unsafe, or unhelpful. Do not include passwords or payment details.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleReport} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor={`report-${message.id}`}>Reason</Label>
              <Textarea
                id={`report-${message.id}`}
                value={reportReason}
                onChange={(event) => setReportReason(event.target.value)}
                minLength={3}
                maxLength={500}
                placeholder="Describe the problem with this response"
                className="min-h-28"
              />
            </div>
            {reportMessage.isError && (
              <p className="text-sm font-medium text-destructive">
                The report could not be saved. Check your connection and retry.
              </p>
            )}
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setReportOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={reportMessage.isPending || reportReason.trim().length < 3}>
                {reportMessage.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Submit report
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
