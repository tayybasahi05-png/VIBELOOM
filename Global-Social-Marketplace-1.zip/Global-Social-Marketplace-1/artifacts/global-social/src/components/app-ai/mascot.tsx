interface VibeLoomAiMarkProps {
  className?: string;
}

export function VibeLoomAiMark({ className = "" }: VibeLoomAiMarkProps) {
  return (
    <span
      aria-hidden="true"
      className={`relative inline-flex items-center justify-center overflow-hidden rounded-[42%] bg-primary text-primary-foreground shadow-sm ${className}`}
    >
      <span className="absolute h-[58%] w-[34%] -rotate-[28deg] rounded-full border-[2px] border-current" />
      <span className="absolute h-[58%] w-[34%] rotate-[28deg] rounded-full border-[2px] border-current opacity-75" />
      <span className="relative h-[14%] w-[14%] rounded-full bg-current shadow-[0_0_0_3px_hsl(var(--primary))]" />
    </span>
  );
}
