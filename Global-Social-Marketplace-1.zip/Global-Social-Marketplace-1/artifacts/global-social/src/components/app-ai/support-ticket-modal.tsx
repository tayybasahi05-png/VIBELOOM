import { useState } from "react";
import { useCreateAppAiSupportTicket } from "@workspace/api-client-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, CheckCircle2 } from "lucide-react";

interface Props {
  conversationId: number;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function SupportTicketModal({ conversationId, open, onOpenChange }: Props) {
  const [subject, setSubject] = useState("");
  const [details, setDetails] = useState("");
  const [ticketId, setTicketId] = useState<number | null>(null);

  const createTicket = useCreateAppAiSupportTicket();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!subject.trim() || !details.trim()) return;
    createTicket.mutate(
      { data: { conversationId, subject, details } },
      {
        onSuccess: (data) => {
          setTicketId(data.id);
        },
      }
    );
  };

  const resetAndClose = () => {
    onOpenChange(false);
    setTimeout(() => {
      setSubject("");
      setDetails("");
      setTicketId(null);
      createTicket.reset();
    }, 300);
  };

  return (
    <Dialog open={open} onOpenChange={(val) => { if (!val) resetAndClose(); else onOpenChange(val); }}>
      <DialogContent className="sm:max-w-md">
        {ticketId ? (
          <div className="py-6 flex flex-col items-center justify-center text-center space-y-4">
            <div className="w-16 h-16 bg-primary/10 text-primary rounded-full flex items-center justify-center mb-2">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <DialogTitle className="text-3xl font-serif text-foreground">Ticket Created</DialogTitle>
            <DialogDescription className="text-base text-muted-foreground">
              Your support ticket has been submitted successfully. Our team will review it shortly.
            </DialogDescription>
            <div className="bg-secondary/50 px-6 py-5 rounded-2xl mt-4 border border-border w-full">
              <p className="text-xs text-muted-foreground uppercase tracking-widest font-bold mb-2">Ticket ID</p>
              <p className="text-2xl font-mono text-foreground font-semibold">#{ticketId}</p>
            </div>
            <Button onClick={resetAndClose} className="w-full mt-6 bg-primary text-primary-foreground font-bold py-6 rounded-xl text-lg hover:bg-primary/90 transition-colors">
              Done
            </Button>
          </div>
        ) : (
          <>
            <DialogHeader>
              <DialogTitle className="text-3xl font-serif text-foreground">Contact Support</DialogTitle>
              <DialogDescription className="text-base">
                Need human assistance? Open a support ticket and our team will get back to you.
              </DialogDescription>
            </DialogHeader>

            <form onSubmit={handleSubmit} className="space-y-5 py-4">
              <div className="space-y-2">
                <Label htmlFor="subject" className="font-bold text-foreground">Subject</Label>
                <Input
                  id="subject"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="Brief summary of your issue"
                  className="bg-card border-2 rounded-xl py-6 focus-visible:ring-primary text-base"
                  required
                  minLength={3}
                  maxLength={160}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="details" className="font-bold text-foreground">Details</Label>
                <Textarea
                  id="details"
                  value={details}
                  onChange={(e) => setDetails(e.target.value)}
                  placeholder="Please provide as much context as possible..."
                  className="bg-card border-2 rounded-xl min-h-[140px] resize-none focus-visible:ring-primary text-base p-4"
                  required
                  minLength={10}
                  maxLength={4000}
                />
              </div>

              {createTicket.isError && (
                <div className="p-4 bg-destructive/10 text-destructive border border-destructive/20 rounded-xl text-sm font-bold flex items-center gap-2">
                  Failed to create ticket. Please try again.
                </div>
              )}

              <DialogFooter className="pt-4 flex gap-3">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={resetAndClose}
                  className="flex-1 rounded-xl font-bold py-6 border-2 hover:bg-secondary/50 transition-colors"
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  disabled={createTicket.isPending || !subject.trim() || !details.trim()}
                  className="flex-1 rounded-xl font-bold py-6 bg-primary text-primary-foreground hover:bg-primary/90 transition-colors disabled:opacity-50"
                >
                  {createTicket.isPending ? <Loader2 className="w-5 h-5 animate-spin" /> : "Submit Ticket"}
                </Button>
              </DialogFooter>
            </form>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
