import assert from "node:assert/strict";
import type { AddressInfo } from "node:net";
import test, { after, before, beforeEach } from "node:test";
import express from "express";
import { and, eq, inArray } from "drizzle-orm";
import {
  db,
  inboxConversationParticipantsTable,
  inboxConversationsTable,
  inboxMessagesTable,
  pool,
  usersTable,
} from "@workspace/db";
import { setAuthResolverForTests } from "../src/middlewares/requireAuthenticatedRequest";
import platformRouter from "../src/routes/platform";

const users = ["inbox-test-a", "inbox-test-b", "inbox-test-c", "inbox-test-d"];
const [userA, userB, userC, userD] = users;
const conversationAB = "inbox-test-conversation-ab";
const conversationCD = "inbox-test-conversation-cd";
const conversations = [conversationAB, conversationCD];
const nonexistentConversation = "inbox-test-conversation-missing";

const app = express();
app.use(express.json());
app.use(platformRouter);

let baseUrl = "";
let server: ReturnType<typeof app.listen>;

function authHeaders(userId: string, json = false): HeadersInit {
  return {
    "x-test-user-id": userId,
    ...(json ? { "content-type": "application/json" } : {}),
  };
}

function messagesUrl(conversationId: string): string {
  return `${baseUrl}/inbox/conversations/${conversationId}/messages`;
}

async function clean(): Promise<void> {
  await db.delete(inboxConversationsTable).where(inArray(inboxConversationsTable.id, conversations));
  await db.delete(usersTable).where(inArray(usersTable.id, users));
}

before(async () => {
  setAuthResolverForTests((req) => {
    const userId = req.header("x-test-user-id") ?? null;
    return {
      userId,
      sessionClaims: userId
        ? { firstName: "Inbox", lastName: "Tester", username: userId }
        : null,
    } as ReturnType<typeof import("@clerk/express").getAuth>;
  });
  server = app.listen(0);
  await new Promise<void>((resolve) => server.once("listening", resolve));
  baseUrl = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
});

beforeEach(async () => {
  await clean();
  await db.insert(usersTable).values(users.map((id) => ({ id, name: id, handle: id })));
  await pool.query(
    `insert into inbox_conversations (id)
     values ($1), ($2)`,
    [conversationAB, conversationCD],
  );
  await db.insert(inboxConversationParticipantsTable).values([
    { conversationId: conversationAB, userId: userA },
    { conversationId: conversationAB, userId: userB },
    { conversationId: conversationCD, userId: userC },
    { conversationId: conversationCD, userId: userD },
  ]);
});

after(async () => {
  await clean();
  setAuthResolverForTests();
  await new Promise<void>((resolve, reject) =>
    server.close((error) => (error ? reject(error) : resolve())),
  );
  await pool.end();
});

test("authenticated users list only conversations they participate in", async () => {
  const [responseA, responseC] = await Promise.all([
    fetch(`${baseUrl}/inbox/conversations`, { headers: authHeaders(userA) }),
    fetch(`${baseUrl}/inbox/conversations`, { headers: authHeaders(userC) }),
  ]);
  assert.equal(responseA.status, 200);
  assert.equal(responseC.status, 200);
  assert.deepEqual(
    ((await responseA.json()) as Array<{ id: string }>).map(({ id }) => id),
    [conversationAB],
  );
  assert.deepEqual(
    ((await responseC.json()) as Array<{ id: string }>).map(({ id }) => id),
    [conversationCD],
  );
});

test("a non-member gets the same 404 as a nonexistent conversation for reads and sends", async () => {
  const requests = [
    fetch(messagesUrl(conversationAB), { headers: authHeaders(userC) }),
    fetch(messagesUrl(nonexistentConversation), { headers: authHeaders(userC) }),
    fetch(messagesUrl(conversationAB), {
      method: "POST",
      headers: authHeaders(userC, true),
      body: JSON.stringify({ body: "not allowed" }),
    }),
    fetch(messagesUrl(nonexistentConversation), {
      method: "POST",
      headers: authHeaders(userC, true),
      body: JSON.stringify({ body: "not allowed" }),
    }),
  ];
  const responses = await Promise.all(requests);
  assert.deepEqual(responses.map(({ status }) => status), [404, 404, 404, 404]);
  const payloads = await Promise.all(responses.map((response) => response.json()));
  assert.deepEqual(payloads, payloads.map(() => ({ error: "Conversation not found" })));
});

test("members can send and read messages that survive a fresh PostgreSQL connection", async () => {
  const sendResponse = await fetch(messagesUrl(conversationAB), {
    method: "POST",
    headers: authHeaders(userA, true),
    body: JSON.stringify({ body: "persist this message" }),
  });
  assert.equal(sendResponse.status, 201);
  const sent = (await sendResponse.json()) as { id: string; senderId: string; body: string };
  assert.equal(sent.senderId, userA);
  assert.equal(sent.body, "persist this message");

  const readResponse = await fetch(messagesUrl(conversationAB), {
    headers: authHeaders(userB),
  });
  assert.equal(readResponse.status, 200);
  assert.deepEqual(
    ((await readResponse.json()) as Array<{ id: string; isMine: boolean }>).map(
      ({ id, isMine }) => ({ id, isMine }),
    ),
    [{ id: sent.id, isMine: false }],
  );

  const ReconnectedPool = pool.constructor as new (options: {
    connectionString: string | undefined;
  }) => typeof pool;
  const reconnectedPool = new ReconnectedPool({ connectionString: process.env.DATABASE_URL });
  try {
    const persisted = await reconnectedPool.query<{
      id: string;
      sender_id: string;
      body: string;
    }>(
      `select id, sender_id, body
         from inbox_messages
        where id = $1`,
      [sent.id],
    );
    assert.deepEqual(persisted.rows, [
      { id: sent.id, sender_id: userA, body: "persist this message" },
    ]);
  } finally {
    await reconnectedPool.end();
  }
});

test("overlapping reads advance markers without losing unread-count correctness", async () => {
  const firstAt = new Date(Date.now() - 2_000);
  const secondAt = new Date(Date.now() - 1_000);
  await db.insert(inboxMessagesTable).values([
    {
      id: "inbox-test-message-first",
      conversationId: conversationAB,
      senderId: userA,
      body: "first",
      createdAt: firstAt,
    },
    {
      id: "inbox-test-message-second",
      conversationId: conversationAB,
      senderId: userA,
      body: "second",
      createdAt: secondAt,
    },
  ]);
  await db
    .update(inboxConversationParticipantsTable)
    .set({ lastReadAt: new Date(Date.now() - 3_000) })
    .where(
      and(
        eq(inboxConversationParticipantsTable.conversationId, conversationAB),
        eq(inboxConversationParticipantsTable.userId, userB),
      ),
    );

  const unreadResponse = await fetch(`${baseUrl}/inbox/conversations`, {
    headers: authHeaders(userB),
  });
  assert.equal(
    ((await unreadResponse.json()) as Array<{ unreadCount: number }>)[0]?.unreadCount,
    2,
  );

  const reads = await Promise.all([
    fetch(messagesUrl(conversationAB), { headers: authHeaders(userB) }),
    fetch(messagesUrl(conversationAB), { headers: authHeaders(userB) }),
  ]);
  assert.deepEqual(reads.map(({ status }) => status), [200, 200]);

  const [membership] = await db
    .select({ lastReadAt: inboxConversationParticipantsTable.lastReadAt })
    .from(inboxConversationParticipantsTable)
    .where(
      and(
        eq(inboxConversationParticipantsTable.conversationId, conversationAB),
        eq(inboxConversationParticipantsTable.userId, userB),
      ),
    );
  assert.ok(membership.lastReadAt >= secondAt);

  const readListResponse = await fetch(`${baseUrl}/inbox/conversations`, {
    headers: authHeaders(userB),
  });
  assert.equal(
    ((await readListResponse.json()) as Array<{ unreadCount: number }>)[0]?.unreadCount,
    0,
  );
});

test("message notifications are participant-scoped and share the inbox read marker", async () => {
  const sentAt = new Date(Date.now() + 1_000);
  await db.insert(inboxMessagesTable).values({
    id: "inbox-test-notification-message",
    conversationId: conversationAB,
    senderId: userA,
    body: "private notification body",
    createdAt: sentAt,
  });

  const [recipientResponse, senderResponse, outsiderResponse] = await Promise.all([
    fetch(`${baseUrl}/notifications`, { headers: authHeaders(userB) }),
    fetch(`${baseUrl}/notifications`, { headers: authHeaders(userA) }),
    fetch(`${baseUrl}/notifications`, { headers: authHeaders(userC) }),
  ]);
  assert.deepEqual(
    [recipientResponse.status, senderResponse.status, outsiderResponse.status],
    [200, 200, 200],
  );

  const recipientNotifications = (await recipientResponse.json()) as Array<{
    body: string;
    conversationId: string | null;
    read: boolean;
  }>;
  assert.deepEqual(recipientNotifications, [
    {
      id: "message-inbox-test-notification-message",
      kind: "message",
      title: `New message from ${userA}`,
      body: "private notification body",
      createdAt: sentAt.toISOString(),
      read: false,
      conversationId: conversationAB,
    },
  ]);
  assert.deepEqual(await senderResponse.json(), []);
  assert.deepEqual(await outsiderResponse.json(), []);

  const readResponse = await fetch(messagesUrl(conversationAB), {
    headers: authHeaders(userB),
  });
  assert.equal(readResponse.status, 200);

  const afterReadResponse = await fetch(`${baseUrl}/notifications`, {
    headers: authHeaders(userB),
  });
  assert.equal(afterReadResponse.status, 200);
  assert.equal(
    ((await afterReadResponse.json()) as Array<{ read: boolean }>)[0]?.read,
    true,
  );
});