import assert from "node:assert/strict";
import type { AddressInfo } from "node:net";
import test, { after, before, beforeEach } from "node:test";
import express from "express";
import { inArray } from "drizzle-orm";
import {
  db,
  giftTransfersTable,
  pool,
  stripeCheckoutRecordsTable,
  usersTable,
  walletsTable,
} from "@workspace/db";
import { seedLiveData } from "../src/lib/live-service";
import { setAuthResolverForTests } from "../src/middlewares/requireAuthenticatedRequest";
import liveRouter from "../src/routes/live";
import walletRouter from "../src/routes/wallet";

const userA = "ownership-test-user-a";
const userB = "ownership-test-user-b";
const testUsers = [userA, userB];
const checkoutSessionId = "cs_ownership_test_user_b";
const giftKeys = ["ownership-a-sent", "ownership-b-sent"];

const app = express();
app.use(express.json());
app.use((req, _res, next) => {
  req.log = {
    warn() {},
  } as typeof req.log;
  next();
});
app.use(liveRouter);
app.use(walletRouter);

let baseUrl = "";
let server: ReturnType<typeof app.listen>;

function authHeaders(userId?: string): HeadersInit {
  return userId ? { "x-test-user-id": userId } : {};
}

async function clean(): Promise<void> {
  await db
    .delete(stripeCheckoutRecordsTable)
    .where(inArray(stripeCheckoutRecordsTable.userId, testUsers));
  await db
    .delete(giftTransfersTable)
    .where(inArray(giftTransfersTable.idempotencyKey, giftKeys));
  await db.delete(walletsTable).where(inArray(walletsTable.userId, testUsers));
  await db.delete(usersTable).where(inArray(usersTable.id, testUsers));
}

before(async () => {
  setAuthResolverForTests((req) => {
    const userId = req.header("x-test-user-id") ?? null;
    return {
      userId,
      sessionClaims: userId
        ? { firstName: "Ownership", lastName: "Tester", username: userId }
        : null,
    } as ReturnType<typeof import("@clerk/express").getAuth>;
  });
  await seedLiveData();
  server = app.listen(0);
  await new Promise<void>((resolve) => server.once("listening", resolve));
  baseUrl = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
});

beforeEach(async () => {
  await clean();
  await db
    .insert(usersTable)
    .values(testUsers.map((id) => ({ id, name: id, handle: `@${id}` })));
  await db.insert(walletsTable).values([
    { userId: userA, coinBalance: 111, creatorEarnings: 11 },
    { userId: userB, coinBalance: 222, creatorEarnings: 22 },
  ]);
  await db.insert(giftTransfersTable).values([
    {
      roomId: "live-1",
      giftId: "rose",
      senderUserId: userA,
      receiverUserId: "demo-host-zara",
      quantity: 1,
      totalCoins: 10,
      idempotencyKey: giftKeys[0],
    },
    {
      roomId: "live-2",
      giftId: "sparkle",
      senderUserId: userB,
      receiverUserId: "demo-host-imran",
      quantity: 1,
      totalCoins: 50,
      idempotencyKey: giftKeys[1],
    },
  ]);
  await db.insert(stripeCheckoutRecordsTable).values({
    userId: userB,
    checkoutSessionId,
    packId: "coins-100",
    coinAmount: 100,
    amountMinor: 199,
    currency: "usd",
  });
});

after(async () => {
  await clean();
  setAuthResolverForTests();
  await new Promise<void>((resolve, reject) =>
    server.close((error) => (error ? reject(error) : resolve())),
  );
  await pool.end();
});

test("protected wallet and live-gift routes return 401 when signed out", async () => {
  const requests = [
    fetch(`${baseUrl}/wallet`),
    fetch(`${baseUrl}/wallet/transactions`),
    fetch(`${baseUrl}/wallet/gifts/sent`),
    fetch(`${baseUrl}/wallet/gifts/received`),
    fetch(`${baseUrl}/wallet/checkout`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ packId: "coins-100", idempotencyKey: "signed-out" }),
    }),
    fetch(`${baseUrl}/wallet/checkout/confirm`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ checkoutSessionId }),
    }),
    fetch(`${baseUrl}/live/rooms/live-1/gifts`, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "idempotency-key": "signed-out",
      },
      body: JSON.stringify({ giftId: "rose", quantity: 1 }),
    }),
  ];
  const responses = await Promise.all(requests);
  assert.deepEqual(
    responses.map((response) => response.status),
    responses.map(() => 401),
  );
});

test("authenticated Clerk user IDs select only their wallet summaries", async () => {
  const [responseA, responseB] = await Promise.all([
    fetch(`${baseUrl}/wallet`, { headers: authHeaders(userA) }),
    fetch(`${baseUrl}/wallet`, { headers: authHeaders(userB) }),
  ]);
  assert.equal(responseA.status, 200);
  assert.equal(responseB.status, 200);
  assert.deepEqual(await responseA.json(), {
    coinBalance: 111,
    earnings: 11,
    pendingPayout: 0,
    currency: "USD",
  });
  assert.deepEqual(await responseB.json(), {
    coinBalance: 222,
    earnings: 22,
    pendingPayout: 0,
    currency: "USD",
  });
});

test("authenticated Clerk user IDs select only their sent gift history", async () => {
  const [responseA, responseB] = await Promise.all([
    fetch(`${baseUrl}/wallet/gifts/sent`, { headers: authHeaders(userA) }),
    fetch(`${baseUrl}/wallet/gifts/sent`, { headers: authHeaders(userB) }),
  ]);
  const giftsA = (await responseA.json()) as Array<{ senderUserId: string; giftId: string }>;
  const giftsB = (await responseB.json()) as Array<{ senderUserId: string; giftId: string }>;
  assert.deepEqual(giftsA.map(({ senderUserId, giftId }) => ({ senderUserId, giftId })), [
    { senderUserId: userA, giftId: "rose" },
  ]);
  assert.deepEqual(giftsB.map(({ senderUserId, giftId }) => ({ senderUserId, giftId })), [
    { senderUserId: userB, giftId: "sparkle" },
  ]);
});

test("checkout confirmation hides records owned by another authenticated user", async () => {
  const response = await fetch(`${baseUrl}/wallet/checkout/confirm`, {
    method: "POST",
    headers: {
      ...authHeaders(userA),
      "content-type": "application/json",
    },
    body: JSON.stringify({ checkoutSessionId }),
  });
  assert.equal(response.status, 404);
  assert.deepEqual(await response.json(), { error: "Checkout record not found" });
});