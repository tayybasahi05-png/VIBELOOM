import test, { after, before, beforeEach } from "node:test";
import assert from "node:assert/strict";
import Stripe from "stripe";
import { and, eq, inArray, sql } from "drizzle-orm";
import {
  connectedPaymentAccountsTable,
  db,
  marketPaymentInventoryTable,
  marketListingsTable,
  paymentDisputesTable,
  paymentOrdersTable,
  paymentPayoutsTable,
  paymentRefundsTable,
  paymentReservationsTable,
  paymentTransfersTable,
  pool,
  stripeWebhookEventsTable,
  usersTable,
} from "@workspace/db";
import {
  createMarketCheckout,
  decidePaymentRefund,
  getConnectedAccount,
  getPaymentOrder,
  listPaymentOrders,
  listPayouts,
  listPaymentRefunds,
  listSupportPaymentRefunds,
  requestPaymentRefund,
  setPaymentCheckoutBeforeLockForTests,
  setPaymentProductResolverForTests,
  setPaymentStripeRequesterForTests,
} from "../src/lib/payment-service";
import { processPaymentEvent, WebhookHandlers } from "../src/webhookHandlers";
import { StripeProviderError } from "../src/stripeConnector";
import {
  createPersistedProduct,
  getPersistedProduct,
  listSellerPersistedProducts,
  updatePersistedProduct,
} from "../src/lib/platform-data";

const buyerA = "payment-test-buyer-a";
const buyerB = "payment-test-buyer-b";
const seller = "payment-test-seller";
const support = "payment-test-support";
const productId = "payment-test-product";
const accountId = "acct_payment_test_seller";
const testUsers = [buyerA, buyerB, seller, support];
const event = (id: string, type: string, object: object, account?: string) => ({
  id, type, account, created: 1, livemode: false, api_version: null,
  data: { object }, object: "event", pending_webhooks: 0, request: null,
}) as Stripe.Event;

let sessionCounter = 0;
let sessions = new Map<string, { id: string; url: string }>();

function installStripeMock(options: { reject?: boolean; timeoutOnce?: boolean } = {}) {
  let timedOut = false;
  setPaymentStripeRequesterForTests(async (path, request = {}) => {
    if (path.startsWith("/v1/products/search")) return { data: [{ id: "prod_test" }] } as never;
    if (path.startsWith("/v1/prices?")) return {
      data: [
        { id: "price_test_pk", unit_amount: 4410, currency: "usd" },
        { id: "price_test_international", unit_amount: 4620, currency: "usd" },
      ],
    } as never;
    if (path === "/v1/prices") return { id: `price_test_${request.body?.get("unit_amount")}` } as never;
    if (path.startsWith("/v1/checkout/sessions/")) {
      const id = path.split("/").at(-1)!;
      return sessions.get(id) as never;
    }
    if (path === "/v1/checkout/sessions") {
      if (options.reject) throw new StripeProviderError("rejected", 400);
      const key = request.idempotencyKey!;
      let session = sessions.get(key);
      if (!session) {
        session = { id: `cs_test_${++sessionCounter}`, url: `https://checkout.test/${sessionCounter}` };
        sessions.set(key, session);
        sessions.set(session.id, session);
      }
      if (options.timeoutOnce && !timedOut) {
        timedOut = true;
        throw new StripeProviderError("timeout", 504, "timeout");
      }
      return session as never;
    }
    if (path === "/v1/payouts?limit=100") return { data: [], has_more: false } as never;
    if (path === "/v1/refunds") {
      assert.match(request.idempotencyKey ?? "", /^refund-request:\d+$/);
      assert.equal(request.body?.get("reverse_transfer"), "true");
      assert.equal(request.body?.get("refund_application_fee"), "true");
      return { id: `re_${request.idempotencyKey}` } as never;
    }
    throw new Error(`Unexpected Stripe request: ${path}`);
  });
}

async function clean() {
  await db.delete(stripeWebhookEventsTable).where(sql`${stripeWebhookEventsTable.id} LIKE 'evt_payment_test_%'`);
  const orders = await db.select({ id: paymentOrdersTable.id }).from(paymentOrdersTable).where(inArray(paymentOrdersTable.buyerUserId, [buyerA, buyerB]));
  const orderIds = orders.map((row) => row.id);
  if (orderIds.length) {
    await db.delete(paymentTransfersTable).where(inArray(paymentTransfersTable.orderId, orderIds));
    await db.delete(paymentDisputesTable).where(inArray(paymentDisputesTable.orderId, orderIds));
    await db.delete(paymentRefundsTable).where(inArray(paymentRefundsTable.orderId, orderIds));
    await db.delete(paymentReservationsTable).where(inArray(paymentReservationsTable.orderId, orderIds));
    await db.delete(paymentOrdersTable).where(inArray(paymentOrdersTable.id, orderIds));
  }
  await db.delete(paymentPayoutsTable).where(inArray(paymentPayoutsTable.userId, [buyerA, buyerB]));
  await db.delete(connectedPaymentAccountsTable).where(inArray(connectedPaymentAccountsTable.userId, testUsers));
  await db.delete(marketPaymentInventoryTable).where(eq(marketPaymentInventoryTable.productId, productId));
  await db.delete(marketListingsTable).where(eq(marketListingsTable.id, productId));
}

before(async () => {
  process.env.STRIPE_ENABLED = "true";
  process.env.STRIPE_MARKETPLACE_APPROVED = "true";
  process.env.STRIPE_REFUNDS_APPROVED = "true";
  process.env.STRIPE_MODE = "test";
  process.env.STRIPE_WEBHOOK_SECRET = "whsec_payment_test";
  await db.insert(usersTable).values(testUsers.map((id) => ({ id, handle: id }))).onConflictDoNothing();
  await db.update(usersTable).set({ role: "support" }).where(eq(usersTable.id, support));
  setPaymentProductResolverForTests((id) => id === productId ? {
    id: productId,
    name: "Payment test product",
    price: 42,
    currency: "USD",
    imageUrl: "",
    seller: { id: seller, name: "Test seller", handle: "@test", avatarUrl: "", location: "", verified: true, role: "business" },
    location: "",
    rating: 5,
    reviewCount: 0,
    availability: "Only 2 left",
    checkoutReady: true,
    category: "Test",
    description: "",
    condition: "New",
    images: [],
    quantity: 2,
    delivery: "",
    returnPolicy: "",
    specifications: [],
  } : undefined);
});

beforeEach(async () => {
  await clean();
  sessions = new Map();
  sessionCounter = 0;
  setPaymentCheckoutBeforeLockForTests();
  await db.insert(connectedPaymentAccountsTable).values({
    userId: seller, providerAccountId: accountId, chargesEnabled: true, payoutsEnabled: true, status: "enabled",
  });
  await db.insert(marketListingsTable).values({
    id: productId,
    sellerUserId: seller,
    name: "Payment test product",
    description: "",
    category: "Test",
    imageUrl: "https://example.test/product.jpg",
    amountMinor: 4200,
    currency: "usd",
  });
  await db.insert(marketPaymentInventoryTable).values({ productId, availableQuantity: 2 })
    .onConflictDoUpdate({ target: marketPaymentInventoryTable.productId, set: { availableQuantity: 2 } });
  installStripeMock();
});

after(async () => {
  await clean();
  setPaymentProductResolverForTests();
  setPaymentCheckoutBeforeLockForTests();
  setPaymentStripeRequesterForTests();
  await pool.end();
});

test("same idempotency key creates one order and one reservation under concurrency", async () => {
  const results = await Promise.all([
    createMarketCheckout(buyerA, productId, "same-key", "https://app.test"),
    createMarketCheckout(buyerA, productId, "same-key", "https://app.test"),
  ]);
  assert.equal(results[0].order.id, results[1].order.id);
  const orders = await db.select().from(paymentOrdersTable).where(eq(paymentOrdersTable.buyerUserId, buyerA));
  const reservations = await db.select().from(paymentReservationsTable).where(eq(paymentReservationsTable.productId, productId));
  const [inventory] = await db.select().from(marketPaymentInventoryTable).where(eq(marketPaymentInventoryTable.productId, productId));
  assert.equal(orders.length, 1);
  assert.equal(reservations.length, 1);
  assert.equal(inventory.availableQuantity, 1);
});

test("payout reconciliation only returns the authenticated seller's persisted sales", async () => {
  const [order] = await db.insert(paymentOrdersTable).values({
    buyerUserId: buyerA,
    sellerUserId: seller,
    kind: "market_purchase",
    referenceId: productId,
    description: "Payment test product",
    amountMinor: 4410,
    subtotalMinor: 4200,
    taxMinor: 210,
    currency: "usd",
    idempotencyKey: "payout-sale",
    status: "succeeded",
    metadata: { platformFeeMinor: "420" },
  }).returning();
  await db.insert(paymentTransfersTable).values({
    orderId: order.id,
    userId: seller,
    providerTransferId: "tr_payout_sale",
    amountMinor: 4410,
    currency: "usd",
    status: "paid",
  });
  setPaymentStripeRequesterForTests(async (path, request = {}) => {
    assert.equal(request.connectedAccountId, accountId);
    if (path === "/v1/payouts?limit=100") return {
      data: [{ id: "po_test", amount: 3990, currency: "usd", status: "paid", arrival_date: 1, failure_code: null, created: 1 }],
      has_more: false,
    } as never;
    if (path === "/v1/balance_transactions?limit=100&payout=po_test") return {
      data: [{ id: "txn_unknown", source: "tr_not_persisted" }],
      has_more: true,
    } as never;
    if (path === "/v1/balance_transactions?limit=100&payout=po_test&starting_after=txn_unknown") return {
      data: [
        { id: "txn_sale", source: "tr_payout_sale", amount: 4410 },
        { id: "txn_fee", source: "fee_payout_sale", amount: -420 },
      ],
      has_more: false,
    } as never;
    throw new Error(`Unexpected Stripe request: ${path}`);
  });

  const payouts = await listPayouts(seller);
  assert.equal(payouts.length, 1);
  assert.deepEqual(payouts[0].sales.map((sale) => ({
    orderId: sale.orderId,
    listingId: sale.listingId,
    grossAmountMinor: sale.grossAmountMinor,
    platformFeeMinor: sale.platformFeeMinor,
    transferAmountMinor: sale.transferAmountMinor,
  })), [{
    orderId: order.id,
    listingId: productId,
    grossAmountMinor: 4410,
    platformFeeMinor: 420,
    transferAmountMinor: 3990,
  }]);
  assert.equal(payouts[0].reconciliationStatus, "complete");
  assert.deepEqual(await listPayouts(buyerB), []);
});

test("market checkout applies 5% Pakistan tax and rejects a conflicting region retry", async () => {
  const checkout = await createMarketCheckout(
    buyerA,
    productId,
    "pakistan-tax-key",
    "https://app.test",
    "pakistan",
  );
  assert.equal(checkout.order.subtotalMinor, 4200);
  assert.equal(checkout.order.taxMinor, 210);
  assert.equal(checkout.order.taxRateBps, 500);
  assert.equal(checkout.order.taxRegion, "pakistan");
  assert.equal(checkout.order.amountMinor, 4410);
  await assert.rejects(
    createMarketCheckout(buyerA, productId, "pakistan-tax-key", "https://app.test", "international"),
    /different request/,
  );
});

test("market checkout applies 10% international tax", async () => {
  const checkout = await createMarketCheckout(
    buyerA,
    productId,
    "international-tax-key",
    "https://app.test",
    "international",
  );
  assert.equal(checkout.order.subtotalMinor, 4200);
  assert.equal(checkout.order.taxMinor, 420);
  assert.equal(checkout.order.taxRateBps, 1000);
  assert.equal(checkout.order.taxRegion, "international");
  assert.equal(checkout.order.amountMinor, 4620);
});

test("payable listings reject unsupported currency and invalid Stripe amounts", async () => {
  const input = {
    name: "Invalid payment listing",
    imageUrl: "https://example.test/product.jpg",
    category: "Test",
    description: "Validation test",
    condition: "New",
    quantity: 1,
  };
  await assert.rejects(
    createPersistedProduct(seller, `${productId}-eur`, { ...input, price: 42, currency: "EUR" }),
    /valid USD price/,
  );
  await assert.rejects(
    createPersistedProduct(seller, `${productId}-zero`, { ...input, price: 0, currency: "USD" }),
    /valid USD price/,
  );
  await assert.rejects(
    createPersistedProduct(seller, `${productId}-large`, { ...input, price: 1_000_000, currency: "USD" }),
    /valid USD price/,
  );
});

test("listing management is owner-only and supports zero stock and unpublishing", async () => {
  const otherSellerListings = await listSellerPersistedProducts(buyerA);
  assert.equal(otherSellerListings.length, 0);

  const unauthorized = await updatePersistedProduct(buyerA, productId, {
    name: "Changed by someone else",
    price: 20,
    imageUrl: "https://example.test/changed.jpg",
    category: "Test",
    description: "Unauthorized",
    condition: "New",
    quantity: 0,
    expectedQuantity: 2,
    status: "unpublished",
  });
  assert.equal(unauthorized, undefined);

  const legacyStopped = await updatePersistedProduct(seller, productId, { status: "unpublished" });
  assert.equal(legacyStopped?.status, "unpublished");
  assert.equal(legacyStopped?.description, "");
  const legacyResumed = await updatePersistedProduct(seller, productId, { status: "published" });
  assert.equal(legacyResumed?.status, "published");

  const updated = await updatePersistedProduct(seller, productId, {
    name: "Updated product",
    price: 45,
    imageUrl: "https://example.test/updated.jpg",
    category: "Updated",
    description: "Updated details",
    condition: "Used",
    quantity: 0,
    expectedQuantity: 2,
    status: "unpublished",
  });
  assert.equal(updated?.quantity, 0);
  assert.equal(updated?.status, "unpublished");
  assert.equal(await getPersistedProduct(productId), undefined);
  await assert.rejects(
    createMarketCheckout(buyerA, productId, "unpublished-key", "https://app.test"),
    /Product not found/,
  );

  const republished = await updatePersistedProduct(seller, productId, {
    name: "Updated product",
    price: 45,
    imageUrl: "https://example.test/updated.jpg",
    category: "Updated",
    description: "Updated details",
    condition: "Used",
    quantity: 3,
    expectedQuantity: 0,
    status: "published",
  });
  assert.equal(republished?.checkoutReady, true);
  assert.equal(republished?.quantity, 3);
  assert.equal((await getPersistedProduct(productId))?.price, 45);
});

test("a stale inventory edit cannot restore stock reserved by checkout", async () => {
  await db.update(marketPaymentInventoryTable).set({ availableQuantity: 1 })
    .where(eq(marketPaymentInventoryTable.productId, productId));
  const edit = updatePersistedProduct(seller, productId, {
    name: "Concurrent edit",
    price: 42,
    imageUrl: "https://example.test/product.jpg",
    category: "Test",
    description: "Concurrent edit",
    condition: "New",
    quantity: 1,
    expectedQuantity: 1,
    status: "published",
  });
  const checkout = createMarketCheckout(buyerA, productId, "concurrent-edit-key", "https://app.test");
  const [editResult, checkoutResult] = await Promise.allSettled([edit, checkout]);
  assert.equal(checkoutResult.status, "fulfilled");
  const [inventory] = await db.select().from(marketPaymentInventoryTable)
    .where(eq(marketPaymentInventoryTable.productId, productId));
  if (editResult.status === "rejected") {
    assert.match(String(editResult.reason), /Inventory changed/);
    assert.equal(inventory.availableQuantity, 0);
  } else {
    assert.equal(inventory.availableQuantity, 0);
  }
});

test("unpublishing after checkout's initial product read blocks the reservation", async () => {
  let releaseCheckout!: () => void;
  let checkoutRead!: () => void;
  const checkoutCanContinue = new Promise<void>((resolve) => { releaseCheckout = resolve; });
  const checkoutHasRead = new Promise<void>((resolve) => { checkoutRead = resolve; });
  setPaymentCheckoutBeforeLockForTests(async () => {
    checkoutRead();
    await checkoutCanContinue;
  });

  const checkout = createMarketCheckout(buyerA, productId, "unpublish-race-key", "https://app.test");
  await checkoutHasRead;
  const unpublished = await updatePersistedProduct(seller, productId, {
    name: "Payment test product",
    price: 42,
    imageUrl: "https://example.test/product.jpg",
    category: "Test",
    description: "Stopped",
    condition: "New",
    quantity: 2,
    expectedQuantity: 2,
    status: "unpublished",
  });
  assert.equal(unpublished?.status, "unpublished");
  releaseCheckout();
  await assert.rejects(checkout, /Product not found/);
  const reservations = await db.select().from(paymentReservationsTable)
    .where(eq(paymentReservationsTable.productId, productId));
  assert.equal(reservations.length, 0);
});

test("checkout uses the latest locked listing price instead of a stale product snapshot", async () => {
  await updatePersistedProduct(seller, productId, {
    name: "Freshly priced product",
    price: 45,
    imageUrl: "https://example.test/product.jpg",
    category: "Test",
    description: "Fresh price",
    condition: "New",
    quantity: 2,
    expectedQuantity: 2,
    status: "published",
  });
  const checkout = await createMarketCheckout(buyerA, productId, "fresh-price-key", "https://app.test");
  assert.equal(checkout.order.subtotalMinor, 4500);
  assert.equal(checkout.order.description, "Freshly priced product");
});

test("different keys reserve atomically and cannot oversell", async () => {
  await db.update(marketPaymentInventoryTable).set({ availableQuantity: 1 }).where(eq(marketPaymentInventoryTable.productId, productId));
  const settled = await Promise.allSettled([
    createMarketCheckout(buyerA, productId, "key-a", "https://app.test"),
    createMarketCheckout(buyerB, productId, "key-b", "https://app.test"),
  ]);
  assert.equal(settled.filter((item) => item.status === "fulfilled").length, 1);
  assert.equal(settled.filter((item) => item.status === "rejected").length, 1);
  const [inventory] = await db.select().from(marketPaymentInventoryTable).where(eq(marketPaymentInventoryTable.productId, productId));
  assert.equal(inventory.availableQuantity, 0);
});

test("definitive provider failure releases stock exactly once", async () => {
  installStripeMock({ reject: true });
  await assert.rejects(createMarketCheckout(buyerA, productId, "reject-key", "https://app.test"));
  await assert.rejects(createMarketCheckout(buyerA, productId, "reject-key", "https://app.test"));
  const [inventory] = await db.select().from(marketPaymentInventoryTable).where(eq(marketPaymentInventoryTable.productId, productId));
  const [order] = await db.select().from(paymentOrdersTable).where(eq(paymentOrdersTable.buyerUserId, buyerA));
  const [reservation] = await db.select().from(paymentReservationsTable).where(eq(paymentReservationsTable.orderId, order.id));
  assert.equal(inventory.availableQuantity, 2);
  assert.equal(reservation.status, "released");
});

test("ambiguous timeout retry uses the reserved order after unpublishing and repricing", async () => {
  installStripeMock({ timeoutOnce: true });
  await assert.rejects(createMarketCheckout(buyerA, productId, "timeout-key", "https://app.test"));
  const changed = await updatePersistedProduct(seller, productId, {
    name: "Changed after reservation",
    price: 99,
    imageUrl: "https://example.test/product.jpg",
    category: "Test",
    description: "Changed after reservation",
    condition: "New",
    quantity: 1,
    expectedQuantity: 1,
    status: "unpublished",
  });
  assert.equal(changed?.status, "unpublished");
  const recovered = await createMarketCheckout(buyerA, productId, "timeout-key", "https://app.test");
  const [reservation] = await db.select().from(paymentReservationsTable).where(eq(paymentReservationsTable.orderId, recovered.order.id));
  const [inventory] = await db.select().from(marketPaymentInventoryTable).where(eq(marketPaymentInventoryTable.productId, productId));
  assert.equal(recovered.order.status, "pending");
  assert.equal(recovered.order.subtotalMinor, 4200);
  assert.equal(recovered.order.description, "Payment test product");
  assert.equal(reservation.status, "reserved");
  assert.equal(inventory.availableQuantity, 1);
  assert.equal(sessionCounter, 1);
});

test("duplicate and delayed checkout webhooks are exactly once and monotonic", async () => {
  const checkout = await createMarketCheckout(buyerA, productId, "webhook-key", "https://app.test");
  const session = {
    id: sessions.get("market:payment-test-buyer-a:webhook-key")!.id,
    payment_status: "paid", payment_intent: "pi_test", amount_total: 4620, currency: "usd",
    client_reference_id: buyerA,
    metadata: {
      orderId: String(checkout.order.id),
      productId,
      recipientAccountId: accountId,
      amountMinor: "4620",
      subtotalMinor: "4200",
      taxMinor: "420",
      taxRateBps: "1000",
      taxRegion: "international",
    },
  };
  await db.transaction((tx) => processPaymentEvent(event("evt_payment_test_paid", "checkout.session.completed", session), tx));
  await db.transaction((tx) => processPaymentEvent(event("evt_payment_test_paid_again", "checkout.session.completed", session), tx));
  await db.transaction((tx) => processPaymentEvent(event("evt_payment_test_late_expiry", "checkout.session.expired", session), tx));
  const [order] = await db.select().from(paymentOrdersTable).where(eq(paymentOrdersTable.id, checkout.order.id));
  const [reservation] = await db.select().from(paymentReservationsTable).where(eq(paymentReservationsTable.orderId, checkout.order.id));
  assert.equal(order.status, "succeeded");
  assert.equal(reservation.status, "fulfilled");
});

test("destination transfer is linked to the paid marketplace order and seller", async () => {
  const checkout = await createMarketCheckout(buyerA, productId, "transfer-key", "https://app.test");
  const session = {
    id: sessions.get("market:payment-test-buyer-a:transfer-key")!.id,
    payment_status: "paid", payment_intent: "pi_transfer", amount_total: 4620, currency: "usd",
    client_reference_id: buyerA,
    metadata: {
      orderId: String(checkout.order.id),
      productId,
      recipientAccountId: accountId,
      amountMinor: "4620",
      subtotalMinor: "4200",
      taxMinor: "420",
      taxRateBps: "1000",
      taxRegion: "international",
    },
  };
  await db.transaction((tx) => processPaymentEvent(event("evt_payment_test_transfer_paid", "checkout.session.completed", session), tx));
  await db.transaction((tx) => processPaymentEvent(event("evt_payment_test_transfer_created", "transfer.created", {
    id: "tr_payment_test",
    destination: accountId,
    transfer_group: `market_order_${checkout.order.id}`,
    amount: 3780,
    currency: "usd",
    reversed: false,
  }), tx));
  const [transfer] = await db.select().from(paymentTransfersTable)
    .where(eq(paymentTransfersTable.providerTransferId, "tr_payment_test"));
  assert.equal(transfer.orderId, checkout.order.id);
  assert.equal(transfer.userId, seller);
});

test("signed duplicate webhook delivery is claimed once", async () => {
  const payload = Buffer.from(JSON.stringify(event("evt_payment_test_duplicate", "unknown.event", {})));
  const signature = Stripe.webhooks.generateTestHeaderString({ payload: payload.toString(), secret: process.env.STRIPE_WEBHOOK_SECRET! });
  await Promise.all([WebhookHandlers.processWebhook(payload, signature), WebhookHandlers.processWebhook(payload, signature)]);
  const [row] = await db.select().from(stripeWebhookEventsTable).where(eq(stripeWebhookEventsTable.id, "evt_payment_test_duplicate"));
  assert.equal(row.status, "succeeded");
});

test("refund, dispute, and payout terminal states do not regress", async () => {
  const checkout = await createMarketCheckout(buyerA, productId, "state-key", "https://app.test");
  await db.update(paymentOrdersTable).set({ status: "succeeded", providerPaymentIntentId: "pi_state", providerChargeId: "ch_state" }).where(eq(paymentOrdersTable.id, checkout.order.id));
  const [refund] = await db.insert(paymentRefundsTable).values({
    orderId: checkout.order.id, requestedByUserId: buyerA, providerRefundId: "re_state", amountMinor: 100, currency: "usd", reason: "test", idempotencyKey: "refund-state", status: "completed",
  }).returning();
  await db.transaction((tx) => processPaymentEvent(event("evt_payment_test_refund_old", "refund.updated", { id: "re_state", status: "pending" }), tx));
  await db.transaction((tx) => processPaymentEvent(event("evt_payment_test_dispute_won", "charge.dispute.closed", { id: "dp_state", charge: "ch_state", payment_intent: "pi_state", amount: 4200, currency: "usd", status: "won", reason: "fraudulent", evidence_details: {} }), tx));
  await db.transaction((tx) => processPaymentEvent(event("evt_payment_test_dispute_old", "charge.dispute.updated", { id: "dp_state", charge: "ch_state", payment_intent: "pi_state", amount: 4200, currency: "usd", status: "under_review", reason: "fraudulent", evidence_details: {} }), tx));
  await db.insert(connectedPaymentAccountsTable).values({ userId: buyerA, providerAccountId: "acct_buyer_a" });
  await db.transaction((tx) => processPaymentEvent(event("evt_payment_test_payout_paid", "payout.paid", { id: "po_state", amount: 500, currency: "usd", status: "paid", arrival_date: null, failure_code: null }, "acct_buyer_a"), tx));
  await db.transaction((tx) => processPaymentEvent(event("evt_payment_test_payout_old", "payout.updated", { id: "po_state", amount: 500, currency: "usd", status: "pending", arrival_date: null, failure_code: null }, "acct_buyer_a"), tx));
  const [savedRefund] = await db.select().from(paymentRefundsTable).where(eq(paymentRefundsTable.id, refund.id));
  const [dispute] = await db.select().from(paymentDisputesTable).where(eq(paymentDisputesTable.providerDisputeId, "dp_state"));
  const [payout] = await db.select().from(paymentPayoutsTable).where(eq(paymentPayoutsTable.providerPayoutId, "po_state"));
  assert.deepEqual([savedRefund.status, dispute.status, payout.status], ["completed", "won", "paid"]);
});

test("support can deny without moving money and approve through an idempotent provider refund", async () => {
  const checkout = await createMarketCheckout(buyerA, productId, "refund-review-key", "https://app.test");
  await db.update(paymentOrdersTable).set({ status: "succeeded", providerPaymentIntentId: "pi_refund_review" })
    .where(eq(paymentOrdersTable.id, checkout.order.id));

  const deniedRequest = await requestPaymentRefund(buyerA, checkout.order.id, 100, "not as described", "refund-deny-request");
  const denied = await decidePaymentRefund(support, deniedRequest.id, "deny", "Item was delivered as described");
  assert.equal(denied?.status, "denied");

  const approvedRequest = await requestPaymentRefund(buyerA, checkout.order.id, 200, "damaged", "refund-approve-request");
  const queue = await listSupportPaymentRefunds(support);
  assert.equal(queue[0]?.fulfillmentStatus, "reserved");
  const approved = await decidePaymentRefund(support, approvedRequest.id, "approve");
  assert.equal(approved?.status, "approved");
  await db.transaction((tx) => processPaymentEvent(event("evt_payment_test_refund_completed", "refund.updated", {
    id: `re_refund-request:${approvedRequest.id}`,
    status: "succeeded",
    payment_intent: "pi_refund_review",
    amount: 200,
    currency: "usd",
    metadata: { refundRequestId: String(approvedRequest.id) },
  }), tx));
  const buyerRefunds = await listPaymentRefunds(buyerA);
  assert.equal(buyerRefunds.find((refund) => refund.id === approvedRequest.id)?.status, "completed");
  await assert.rejects(listSupportPaymentRefunds(buyerA), /Support operator access required/);
});

test("authoritative refund success overrides a local provider failure state", async () => {
  const checkout = await createMarketCheckout(buyerA, productId, "refund-webhook-key", "https://app.test");
  await db.update(paymentOrdersTable).set({ status: "succeeded", providerPaymentIntentId: "pi_refund_webhook" })
    .where(eq(paymentOrdersTable.id, checkout.order.id));
  const request = await requestPaymentRefund(buyerA, checkout.order.id, 150, "provider delayed", "refund-webhook-request");
  await db.update(paymentRefundsTable).set({ status: "failed", providerRefundId: "re_delayed" })
    .where(eq(paymentRefundsTable.id, request.id));
  await db.transaction((tx) => processPaymentEvent(event("evt_payment_test_refund_delayed_success", "refund.updated", {
    id: "re_delayed",
    status: "succeeded",
    payment_intent: "pi_refund_webhook",
    amount: 150,
    currency: "usd",
    metadata: { refundRequestId: String(request.id) },
  }), tx));
  const [saved] = await db.select().from(paymentRefundsTable).where(eq(paymentRefundsTable.id, request.id));
  assert.equal(saved.status, "completed");
});

test("concurrent refund requests cannot reserve more than the order balance", async () => {
  const checkout = await createMarketCheckout(buyerA, productId, "refund-balance-key", "https://app.test");
  await db.update(paymentOrdersTable).set({ status: "succeeded", providerPaymentIntentId: "pi_refund_balance" })
    .where(eq(paymentOrdersTable.id, checkout.order.id));
  const results = await Promise.allSettled([
    requestPaymentRefund(buyerA, checkout.order.id, 3000, "first request", "refund-balance-first"),
    requestPaymentRefund(buyerA, checkout.order.id, 3000, "second request", "refund-balance-second"),
  ]);
  assert.equal(results.filter((result) => result.status === "fulfilled").length, 1);
  assert.equal(results.filter((result) => result.status === "rejected").length, 1);
});

test("refund idempotency keys reject a different request payload", async () => {
  const checkout = await createMarketCheckout(buyerA, productId, "refund-conflict-key", "https://app.test");
  await db.update(paymentOrdersTable).set({ status: "succeeded", providerPaymentIntentId: "pi_refund_conflict" })
    .where(eq(paymentOrdersTable.id, checkout.order.id));
  await requestPaymentRefund(buyerA, checkout.order.id, 100, "first reason", "refund-conflict-request");
  await assert.rejects(
    requestPaymentRefund(buyerA, checkout.order.id, 200, "changed reason", "refund-conflict-request"),
    /different refund request/,
  );
});

test("concurrent refund idempotency reuse across orders resolves as a conflict", async () => {
  const first = await createMarketCheckout(buyerA, productId, "refund-cross-order-one", "https://app.test");
  const second = await createMarketCheckout(buyerA, productId, "refund-cross-order-two", "https://app.test");
  await db.update(paymentOrdersTable).set({ status: "succeeded", providerPaymentIntentId: "pi_refund_cross" })
    .where(inArray(paymentOrdersTable.id, [first.order.id, second.order.id]));
  const results = await Promise.allSettled([
    requestPaymentRefund(buyerA, first.order.id, 100, "same payload", "refund-cross-order-request"),
    requestPaymentRefund(buyerA, second.order.id, 100, "same payload", "refund-cross-order-request"),
  ]);
  assert.equal(results.filter((result) => result.status === "fulfilled").length, 1);
  const rejection = results.find((result): result is PromiseRejectedResult => result.status === "rejected");
  assert.match(String(rejection?.reason), /different refund request/);
});

test("cross-user order, refund, Connect, and payout access is isolated", async () => {
  const checkout = await createMarketCheckout(buyerA, productId, "isolation-key", "https://app.test");
  await db.update(paymentOrdersTable).set({ providerPaymentIntentId: "pi_isolation", status: "succeeded" }).where(eq(paymentOrdersTable.id, checkout.order.id));
  assert.equal(await getPaymentOrder(buyerB, checkout.order.id), null);
  assert.equal((await listPaymentOrders(buyerB)).items.length, 0);
  await assert.rejects(requestPaymentRefund(buyerB, checkout.order.id, 100, "not mine", "foreign-refund"));
  assert.equal((await getConnectedAccount(buyerB)).exists, false);
  assert.deepEqual(await listPayouts(buyerB), []);
});