import { build } from "esbuild";
import { rm } from "node:fs/promises";
import { spawnSync } from "node:child_process";

const outfile = new URL("./dist-tests/wallet-gift-ownership.test.cjs", import.meta.url);
await rm(new URL("./dist-tests", import.meta.url), { recursive: true, force: true });
await build({
  entryPoints: [new URL("./test/wallet-gift-ownership.test.ts", import.meta.url).pathname],
  outfile: outfile.pathname,
  platform: "node",
  bundle: true,
  format: "cjs",
  sourcemap: "inline",
  external: ["pg-native"],
});
const result = spawnSync(process.execPath, ["--test", outfile.pathname], {
  stdio: "inherit",
  env: { ...process.env, NODE_ENV: "test" },
});
await rm(new URL("./dist-tests", import.meta.url), { recursive: true, force: true });
process.exit(result.status ?? 1);