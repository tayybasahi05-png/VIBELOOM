import { getAuth } from "@clerk/express";
import type { Request, RequestHandler } from "express";

type RequestAuth = ReturnType<typeof getAuth>;
type AuthResolver = (req: Request) => RequestAuth;

let resolveAuth: AuthResolver = getAuth;

export function getRequestAuth(req: Request): RequestAuth {
  return resolveAuth(req);
}

export function setAuthResolverForTests(resolver?: AuthResolver): void {
  if (process.env.NODE_ENV !== "test") {
    throw new Error("Auth resolver overrides are only available in tests");
  }
  resolveAuth = resolver ?? getAuth;
}

export const requireAuthenticatedRequest: RequestHandler = (req, res, next) => {
  if (!getRequestAuth(req).userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  next();
};