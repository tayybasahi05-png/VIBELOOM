import Stripe from "stripe";
import { and, eq, sql } from "drizzle-orm";
import {
  connectedPaymentAccountsTable,
  db,
  marketPaymentInventoryTable,
  paymentDisputesTable,
  paymentOrdersTable,
  paymentPayoutsTable,
  paymentRefundsTable,
  paymentReservationsTable,
  paymentTransfersTable,
  stripeCheckoutRecordsTable,
  stripeWebhookEventsTable,
} from "@workspace/db";
import { creditPaidCheckout, getCoinPack } from "./lib/wallet-service";
import { applyPaidMarketOrder } from "./lib/payment-service";

/**
 * Webhooks are the authoritative asynchronous payment signal. The event row is
 * claimed before any business mutation so provider retries cannot run work
 * concurrently; failed claims are explicitly retryable.
 */
export class WebhookHandlers {
  static async processWebhook(payload: Buffer, signature: string): Promise<void> {
    if (!Buffer.isBuffer(payload)) throw new Error("Stripe webhook payload must be a raw Buffer");
    const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
    if (!webhookSecret) throw new Error("Stripe webhook signing secret is unavailable");
    const stripe = new Stripe("sk_test_webhook_verification_only");
    const event = stripe.webhooks.constructEvent(payload, signature, webhookSecret);

    const claimed = await db.transaction(async (tx) => {
      const [created] = await tx.insert(stripeWebhookEventsTable)
        .values({ id: event.id, type: event.type, status: "processing" })
        .onConflictDoNothing()
        .returning();
      if (created) return true;
      const [existing] = await tx.select().from(stripeWebhookEventsTable).where(eq(stripeWebhookEventsTable.id, event.id)).for("update");
      if (!existing || existing.status === "succeeded") return false;
      if (existing.status === "processing" && existing.receivedAt > new Date(Date.now() - 10 * 60_000)) return false;
      await tx.update(stripeWebhookEventsTable).set({ status: "processing", errorMessage: null, receivedAt: new Date(), processedAt: null }).where(eq(stripeWebhookEventsTable.id, event.id));
      return true;
    });
    if (!claimed) return;

    try {
      await db.transaction(async (tx) => {
        await processPaymentEvent(event, tx);
        await tx.update(stripeWebhookEventsTable).set({ status: "succeeded", errorMessage: null, processedAt: new Date() }).where(eq(stripeWebhookEventsTable.id, event.id));
      });
    } catch (error) {
      await db.update(stripeWebhookEventsTable).set({ status: "failed", errorMessage: error instanceof Error ? error.message : "Unknown webhook error" }).where(eq(stripeWebhookEventsTable.id, event.id));
      throw error;
    }
  }

}

const TERMINAL_DISPUTE_STATUSES = new Set(["won", "lost", "warning_closed"]);
const TERMINAL_PAYOUT_STATUSES = new Set(["paid", "failed", "canceled"]);
const TERMINAL_REFUND_STATUSES = new Set(["completed", "denied"]);

export async function processPaymentEvent(
  event: Stripe.Event,
  tx: Parameters<Parameters<typeof db.transaction>[0]>[0],
): Promise<void> {
    if (event.type === "checkout.session.completed" || event.type === "checkout.session.async_payment_succeeded") {
      const session = event.data.object as Stripe.Checkout.Session;
      await applyPaidMarketOrder(tx, session);
      if (session.payment_status === "paid" && session.metadata?.packId) {
        const [coinCheckout] = await tx.select().from(stripeCheckoutRecordsTable).where(eq(stripeCheckoutRecordsTable.checkoutSessionId, session.id));
        const legacyPack = coinCheckout ? getCoinPack(coinCheckout.packId) : undefined;
        const expectedAmountMinor = coinCheckout?.amountMinor ?? legacyPack?.priceCents;
        const expectedCurrency = coinCheckout?.currency || legacyPack?.currency;
        if (coinCheckout && expectedAmountMinor != null && session.amount_total === expectedAmountMinor && session.currency?.toLowerCase() === expectedCurrency &&
          session.metadata.coinAmount === String(coinCheckout.coinAmount)) {
          await creditPaidCheckout(session.id, typeof session.payment_intent === "string" ? session.payment_intent : null);
        }
      }
    } else if (event.type === "checkout.session.async_payment_failed" || event.type === "checkout.session.expired") {
      const session = event.data.object as Stripe.Checkout.Session;
      const orderId = Number(session.metadata?.orderId);
      const [order] = await tx.select().from(paymentOrdersTable).where(eq(paymentOrdersTable.providerCheckoutSessionId, session.id));
      if (order) {
        const [released] = await tx.update(paymentReservationsTable).set({ status: "released", updatedAt: new Date() })
          .where(and(eq(paymentReservationsTable.orderId, order.id), eq(paymentReservationsTable.status, "reserved"))).returning();
        if (released) await tx.update(marketPaymentInventoryTable).set({
          availableQuantity: sql`${marketPaymentInventoryTable.availableQuantity} + ${released.quantity}`,
          updatedAt: new Date(),
        }).where(eq(marketPaymentInventoryTable.productId, released.productId));
      }
      if (Number.isInteger(orderId)) await tx.update(paymentOrdersTable).set({ status: event.type === "checkout.session.expired" ? "canceled" : "failed", updatedAt: new Date() }).where(and(eq(paymentOrdersTable.id, orderId), sql`${paymentOrdersTable.status} NOT IN ('succeeded', 'partially_refunded', 'refunded', 'disputed')`));
      if (session.id) await tx.update(paymentOrdersTable).set({ status: event.type === "checkout.session.expired" ? "canceled" : "failed", updatedAt: new Date() }).where(and(eq(paymentOrdersTable.providerCheckoutSessionId, session.id), sql`${paymentOrdersTable.status} NOT IN ('succeeded', 'partially_refunded', 'refunded', 'disputed')`));
    } else if (event.type.startsWith("payment_intent.")) {
      const intent = event.data.object as Stripe.PaymentIntent;
      const status = intent.status === "succeeded" ? "succeeded" :
        intent.status === "requires_action" ? "requires_action" :
        intent.status === "canceled" ? "canceled" : intent.status === "requires_payment_method" ? "failed" : "pending";
      await tx.update(paymentOrdersTable).set({
        status,
        providerChargeId: typeof intent.latest_charge === "string" ? intent.latest_charge : undefined,
        updatedAt: new Date(),
      }).where(and(eq(paymentOrdersTable.providerPaymentIntentId, intent.id), status === "succeeded" ? sql`true` : sql`${paymentOrdersTable.status} NOT IN ('succeeded', 'partially_refunded', 'refunded', 'disputed')`));
    } else if (event.type === "charge.succeeded") {
      const charge = event.data.object as Stripe.Charge;
      await tx.update(paymentOrdersTable).set({
        providerChargeId: charge.id,
        receiptUrl: charge.receipt_url,
        updatedAt: new Date(),
      }).where(eq(paymentOrdersTable.providerPaymentIntentId, charge.payment_intent as string));
    } else if (event.type === "charge.refunded") {
      const charge = event.data.object as Stripe.Charge;
      const [order] = await tx.select().from(paymentOrdersTable).where(
        charge.payment_intent
          ? sql`${paymentOrdersTable.providerChargeId} = ${charge.id} OR ${paymentOrdersTable.providerPaymentIntentId} = ${charge.payment_intent as string}`
          : eq(paymentOrdersTable.providerChargeId, charge.id),
      );
      if (order) {
        const refunded = Math.min(order.amountMinor, charge.amount_refunded);
        await tx.update(paymentOrdersTable).set({ providerChargeId: charge.id, refundedAmountMinor: refunded, status: refunded >= order.amountMinor ? "refunded" : "partially_refunded", updatedAt: new Date() }).where(eq(paymentOrdersTable.id, order.id));
      }
    } else if (event.type.startsWith("charge.dispute.")) {
      const dispute = event.data.object as Stripe.Dispute;
      const [existingDispute] = await tx.select().from(paymentDisputesTable)
        .where(eq(paymentDisputesTable.providerDisputeId, dispute.id)).for("update");
      if (existingDispute && TERMINAL_DISPUTE_STATUSES.has(existingDispute.status) && existingDispute.status !== dispute.status) return;
      const [order] = await tx.select().from(paymentOrdersTable).where(
        sql`${paymentOrdersTable.providerChargeId} = ${dispute.charge as string} OR ${paymentOrdersTable.providerPaymentIntentId} = ${dispute.payment_intent as string}`,
      );
      await tx.insert(paymentDisputesTable).values({
        orderId: order?.id ?? null, providerDisputeId: dispute.id, amountMinor: dispute.amount,
        currency: dispute.currency.toLowerCase(), status: dispute.status, reason: dispute.reason,
        responseDueAt: dispute.evidence_details?.due_by ? new Date(dispute.evidence_details.due_by * 1000) : null,
      }).onConflictDoUpdate({
        target: paymentDisputesTable.providerDisputeId,
        set: { status: dispute.status, reason: dispute.reason, responseDueAt: dispute.evidence_details?.due_by ? new Date(dispute.evidence_details.due_by * 1000) : null, updatedAt: new Date() },
      });
      if (order) await tx.update(paymentOrdersTable).set({ status: "disputed", updatedAt: new Date() }).where(eq(paymentOrdersTable.id, order.id));
    } else if (event.type === "account.updated") {
      const account = event.data.object as Stripe.Account;
      const status = account.charges_enabled && account.payouts_enabled ? "enabled" : account.details_submitted ? "pending" : "restricted";
      await tx.update(connectedPaymentAccountsTable).set({
        country: account.country, defaultCurrency: account.default_currency,
        detailsSubmitted: account.details_submitted, chargesEnabled: account.charges_enabled,
        payoutsEnabled: account.payouts_enabled, status,
        requirements: account.requirements?.currently_due ?? [], updatedAt: new Date(),
      }).where(eq(connectedPaymentAccountsTable.providerAccountId, account.id));
    } else if (event.type.startsWith("transfer.")) {
      const transfer = event.data.object as Stripe.Transfer;
      const [account] = await tx.select().from(connectedPaymentAccountsTable).where(eq(connectedPaymentAccountsTable.providerAccountId, transfer.destination as string));
      const orderId = /^market_order_(\d+)$/.exec(transfer.transfer_group ?? "")?.[1];
      if (account) await tx.insert(paymentTransfersTable).values({
        orderId: orderId ? Number(orderId) : null,
        userId: account.userId, providerTransferId: transfer.id, amountMinor: transfer.amount,
        currency: transfer.currency.toLowerCase(), status: transfer.reversed ? "reversed" : "paid",
      }).onConflictDoUpdate({
        target: paymentTransfersTable.providerTransferId,
        set: { status: transfer.reversed ? "reversed" : "paid", updatedAt: new Date() },
      });
    } else if (event.type.startsWith("payout.")) {
      const payout = event.data.object as Stripe.Payout;
      const accountId = event.account;
      if (accountId) {
        const [account] = await tx.select().from(connectedPaymentAccountsTable).where(eq(connectedPaymentAccountsTable.providerAccountId, accountId));
        const [existingPayout] = await tx.select().from(paymentPayoutsTable)
          .where(eq(paymentPayoutsTable.providerPayoutId, payout.id)).for("update");
        if (account && !(existingPayout && TERMINAL_PAYOUT_STATUSES.has(existingPayout.status) && existingPayout.status !== payout.status)) await tx.insert(paymentPayoutsTable).values({
          userId: account.userId, providerPayoutId: payout.id, amountMinor: payout.amount,
          currency: payout.currency.toLowerCase(), status: payout.status,
          arrivalAt: payout.arrival_date ? new Date(payout.arrival_date * 1000) : null,
          failureCode: payout.failure_code,
        }).onConflictDoUpdate({
          target: paymentPayoutsTable.providerPayoutId,
          set: {
            status: payout.status,
            arrivalAt: payout.arrival_date ? new Date(payout.arrival_date * 1000) : null,
            failureCode: payout.failure_code,
            updatedAt: new Date(),
          },
        });
      }
    } else if (event.type.startsWith("refund.")) {
      const refund = event.data.object as Stripe.Refund;
      const requestId = Number(refund.metadata?.refundRequestId);
      const lookup = Number.isInteger(requestId) && requestId > 0
        ? sql`${paymentRefundsTable.providerRefundId} = ${refund.id} OR ${paymentRefundsTable.id} = ${requestId}`
        : eq(paymentRefundsTable.providerRefundId, refund.id);
      const [existingRefund] = await tx.select().from(paymentRefundsTable).where(lookup).for("update");
      if (!existingRefund) return;
      if (TERMINAL_REFUND_STATUSES.has(existingRefund.status)) return;
      const [order] = await tx.select().from(paymentOrdersTable)
        .where(eq(paymentOrdersTable.id, existingRefund.orderId));
      const paymentIntentId = typeof refund.payment_intent === "string"
        ? refund.payment_intent
        : refund.payment_intent?.id;
      const validBinding =
        (!existingRefund.providerRefundId || existingRefund.providerRefundId === refund.id) &&
        (!Number.isInteger(requestId) || requestId === existingRefund.id) &&
        order?.providerPaymentIntentId === paymentIntentId &&
        refund.amount === existingRefund.amountMinor &&
        refund.currency.toLowerCase() === existingRefund.currency.toLowerCase();
      if (!validBinding) return;
      const nextStatus = refund.status === "succeeded"
        ? "completed"
        : refund.status === "failed" || refund.status === "canceled"
          ? "failed"
          : "approved";
      await tx.update(paymentRefundsTable).set({
        providerRefundId: refund.id,
        status: nextStatus,
        updatedAt: new Date(),
      }).where(eq(paymentRefundsTable.id, existingRefund.id));
    }
}