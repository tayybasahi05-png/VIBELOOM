import { randomUUID } from "node:crypto";
import { and, desc, eq, inArray } from "drizzle-orm";
import {
  db,
  giftCatalogTable,
  giftTransfersTable,
  liveRoomsTable,
  usersTable,
  walletLedgerTable,
  walletsTable,
} from "@workspace/db";
import type { Request } from "express";
import { getRequestAuth } from "../middlewares/requireAuthenticatedRequest";

const demoUsers = [
  {
    id: "demo-host-zara",
    name: "Zara Adeel",
    handle: "@zarastudio",
    avatarUrl:
      "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop",
    location: "Lahore, Pakistan",
    verified: true,
    role: "business",
  },
  {
    id: "demo-host-imran",
    name: "Imran Raza",
    handle: "@imranbuilds",
    avatarUrl:
      "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&auto=format&fit=crop",
    location: "Karachi, Pakistan",
    verified: true,
    role: "freelancer",
  },
] as const;

export async function seedLiveData(): Promise<void> {
  await db.transaction(async (tx) => {
    await tx.insert(usersTable).values([...demoUsers]).onConflictDoNothing();
    await tx
      .insert(walletsTable)
      .values(demoUsers.map(({ id }) => ({ userId: id })))
      .onConflictDoNothing();
    await tx
      .insert(giftCatalogTable)
      .values([
        { id: "rose", name: "Rose", coinCost: 10, iconUrl: "🌹" },
        { id: "sparkle", name: "Sparkle", coinCost: 50, iconUrl: "✨" },
        { id: "crown", name: "Crown", coinCost: 250, iconUrl: "👑" },
      ])
      .onConflictDoNothing();
    await tx
      .insert(liveRoomsTable)
      .values([
        {
          id: "live-1",
          title: "Studio tour: new summer pieces",
          category: "Style",
          hostUserId: "demo-host-zara",
          coverUrl:
            "https://images.unsplash.com/photo-1445205170230-053b83016050?w=1200&auto=format&fit=crop",
          viewers: 2384,
          isLive: true,
          tags: ["fashion", "behind the scenes"],
        },
        {
          id: "live-2",
          title: "Build a client-ready portfolio",
          category: "Freelancing",
          hostUserId: "demo-host-imran",
          coverUrl:
            "https://images.unsplash.com/photo-1556761175-b413da4baf72?w=1200&auto=format&fit=crop",
          viewers: 892,
          isLive: true,
          tags: ["portfolio", "career"],
        },
      ])
      .onConflictDoNothing();
  });
}

type AuthClaims = Record<string, unknown>;

export async function ensureAuthenticatedUser(req: Request): Promise<string> {
  const auth = getRequestAuth(req);
  const userId = auth.userId;
  if (!userId) {
    throw new Error("Authentication required");
  }
  const claims = (auth.sessionClaims ?? {}) as AuthClaims;
  const firstName = typeof claims.firstName === "string" ? claims.firstName : "";
  const lastName = typeof claims.lastName === "string" ? claims.lastName : "";
  const name = `${firstName} ${lastName}`.trim() || "Member";
  const username =
    typeof claims.username === "string" && claims.username.length > 0
      ? claims.username
      : `member-${userId.slice(-12)}`;
  const imageUrl = typeof claims.imageUrl === "string" ? claims.imageUrl : "";

  await db
    .insert(usersTable)
    .values({
      id: userId,
      name,
      handle: username.startsWith("@") ? username : `@${username}`,
      avatarUrl: imageUrl,
      location: "",
      verified: false,
      role: "member",
    })
    .onConflictDoNothing();
  await db.insert(walletsTable).values({ userId }).onConflictDoNothing();
  return userId;
}

function mapUser(user: typeof usersTable.$inferSelect) {
  return {
    id: user.id,
    name: user.name,
    handle: user.handle,
    avatarUrl: user.avatarUrl,
    location: user.location,
    verified: user.verified,
    role: user.role as "member" | "creator" | "business" | "freelancer",
  };
}

export function mapTransfer(
  transfer: typeof giftTransfersTable.$inferSelect,
) {
  return {
    id: String(transfer.id),
    roomId: transfer.roomId,
    giftId: transfer.giftId,
    senderUserId: transfer.senderUserId,
    receiverUserId: transfer.receiverUserId,
    quantity: transfer.quantity,
    totalCoins: transfer.totalCoins,
    createdAt: transfer.createdAt.toISOString(),
  };
}

async function recentGifts(roomId: string) {
  const rows = await db
    .select()
    .from(giftTransfersTable)
    .where(eq(giftTransfersTable.roomId, roomId))
    .orderBy(desc(giftTransfersTable.createdAt))
    .limit(25);
  return rows.reverse().map(mapTransfer);
}

async function mapRoom(room: typeof liveRoomsTable.$inferSelect) {
  const [host] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.id, room.hostUserId));
  return {
    id: room.id,
    title: room.title,
    category: room.category,
    host: host ? mapUser(host) : {
      id: room.hostUserId,
      name: "Creator",
      handle: "@creator",
      avatarUrl: "",
      location: "",
      verified: false,
      role: "creator" as const,
    },
    coverUrl: room.coverUrl,
    viewers: room.viewers,
    isLive: room.isLive,
    tags: room.tags,
    recentGifts: await recentGifts(room.id),
  };
}

export async function listRooms() {
  await seedLiveData();
  const rooms = await db
    .select()
    .from(liveRoomsTable)
    .where(eq(liveRoomsTable.isLive, true))
    .orderBy(desc(liveRoomsTable.createdAt));
  return Promise.all(rooms.map(mapRoom));
}

export async function getRoom(roomId: string) {
  await seedLiveData();
  const [room] = await db
    .select()
    .from(liveRoomsTable)
    .where(eq(liveRoomsTable.id, roomId));
  return room ? mapRoom(room) : null;
}

export async function listGifts() {
  await seedLiveData();
  return db
    .select()
    .from(giftCatalogTable)
    .where(eq(giftCatalogTable.active, true))
    .orderBy(giftCatalogTable.coinCost);
}

export async function sendGift(
  roomId: string,
  senderUserId: string,
  giftId: string,
  quantity: number,
  idempotencyKey: string,
) {
  await seedLiveData();
  return db.transaction(async (tx) => {
    const [room] = await tx
      .select()
      .from(liveRoomsTable)
      .where(eq(liveRoomsTable.id, roomId))
      .for("update");
    if (!room) throw Object.assign(new Error("Live room not found"), { code: "ROOM_NOT_FOUND" });
    const [gift] = await tx
      .select()
      .from(giftCatalogTable)
      .where(and(eq(giftCatalogTable.id, giftId), eq(giftCatalogTable.active, true)));
    if (!gift) throw Object.assign(new Error("Gift not found"), { code: "GIFT_NOT_FOUND" });
    if (room.hostUserId === senderUserId) {
      throw Object.assign(new Error("You cannot gift yourself"), { code: "SELF_GIFT" });
    }
    const [existing] = await tx
      .select()
      .from(giftTransfersTable)
      .where(
        and(
          eq(giftTransfersTable.senderUserId, senderUserId),
          eq(giftTransfersTable.idempotencyKey, idempotencyKey),
        ),
      );
    if (existing) {
      if (
        existing.roomId !== roomId ||
        existing.giftId !== giftId ||
        existing.quantity !== quantity
      ) {
        throw Object.assign(new Error("Idempotency key was already used"), { code: "IDEMPOTENCY_CONFLICT" });
      }
      return existing;
    }

    const userIds = [senderUserId, room.hostUserId].sort();
    const lockedWallets = await tx
      .select()
      .from(walletsTable)
      .where(inArray(walletsTable.userId, userIds))
      .orderBy(walletsTable.userId)
      .for("update");
    const senderWallet = lockedWallets.find((wallet) => wallet.userId === senderUserId);
    const hostWallet = lockedWallets.find((wallet) => wallet.userId === room.hostUserId);
    if (!senderWallet || !hostWallet) {
      throw Object.assign(new Error("Wallet is not available"), { code: "WALLET_NOT_FOUND" });
    }
    const totalCoins = gift.coinCost * quantity;
    if (senderWallet.coinBalance < totalCoins) {
      throw Object.assign(new Error("Insufficient coin balance"), { code: "INSUFFICIENT_BALANCE" });
    }

    const [transfer] = await tx
      .insert(giftTransfersTable)
      .values({
        roomId,
        giftId,
        senderUserId,
        receiverUserId: room.hostUserId,
        quantity,
        totalCoins,
        idempotencyKey,
      })
      .returning();
    const senderBalance = senderWallet.coinBalance - totalCoins;
    const hostBalance = hostWallet.coinBalance + totalCoins;
    await tx
      .update(walletsTable)
      .set({ coinBalance: senderBalance })
      .where(eq(walletsTable.userId, senderUserId));
    await tx
      .update(walletsTable)
      .set({ coinBalance: hostBalance, creatorEarnings: hostWallet.creatorEarnings + totalCoins })
      .where(eq(walletsTable.userId, room.hostUserId));
    await tx.insert(walletLedgerTable).values([
      {
        userId: senderUserId,
        amount: -totalCoins,
        balanceAfter: senderBalance,
        kind: "gift_debit",
        referenceId: String(transfer.id),
        idempotencyKey: `gift:${transfer.id}:debit`,
      },
      {
        userId: room.hostUserId,
        amount: totalCoins,
        balanceAfter: hostBalance,
        kind: "gift_credit",
        referenceId: String(transfer.id),
        idempotencyKey: `gift:${transfer.id}:credit`,
      },
    ]);
    return transfer;
  });
}