import { and, desc, eq } from "drizzle-orm";
import {
  connectedPaymentAccountsTable,
  db,
  marketListingsTable,
  marketPaymentInventoryTable,
  usersTable,
} from "@workspace/db";

const people = {
  me: {
    id: "u-me",
    name: "Amina Noor",
    handle: "@aminanoor",
    avatarUrl:
      "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=300&auto=format&fit=crop",
    location: "Dubai, UAE",
    verified: true,
    role: "creator" as const,
  },
  zara: {
    id: "u-zara",
    name: "Zara Adeel",
    handle: "@zarastudio",
    avatarUrl:
      "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop",
    location: "Lahore, Pakistan",
    verified: true,
    role: "business" as const,
  },
  imran: {
    id: "u-imran",
    name: "Imran Raza",
    handle: "@imranbuilds",
    avatarUrl:
      "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&auto=format&fit=crop",
    location: "Karachi, Pakistan",
    verified: true,
    role: "freelancer" as const,
  },
  lina: {
    id: "u-lina",
    name: "Lina Haddad",
    handle: "@linatravels",
    avatarUrl:
      "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?w=300&auto=format&fit=crop",
    location: "Amman, Jordan",
    verified: false,
    role: "creator" as const,
  },
};

export const session = {
  user: people.me,
  unreadCount: 4,
  coinBalance: 1250,
  locale: "en",
};

export const posts = [
  {
    id: "post-1",
    author: people.zara,
    body: "A quiet morning in the studio, finishing the hand-embroidered details on our newest summer collection.",
    mediaUrl:
      "https://images.unsplash.com/photo-1558769132-cb1aea458c5e?w=1200&auto=format&fit=crop",
    mediaType: "image" as const,
    createdAt: "12 min ago",
    likes: 2841,
    comments: 126,
    shares: 54,
    liked: false,
    saved: true,
    sponsored: false,
    category: "Style",
  },
  {
    id: "post-2",
    author: people.imran,
    body: "Three lessons I learned while helping a small retailer launch internationally: simplify checkout, localize pricing, and answer customer questions fast.",
    mediaUrl:
      "https://images.unsplash.com/photo-1552664730-d307ca884978?w=1200&auto=format&fit=crop",
    mediaType: "image" as const,
    createdAt: "46 min ago",
    likes: 936,
    comments: 78,
    shares: 110,
    liked: true,
    saved: false,
    sponsored: false,
    category: "Business",
  },
  {
    id: "post-3",
    author: people.lina,
    body: "Finding the best independent cafés in Amman today. Join my live room this evening and help choose the final stop.",
    mediaUrl:
      "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=1200&auto=format&fit=crop",
    mediaType: "image" as const,
    createdAt: "2 hr ago",
    likes: 1502,
    comments: 203,
    shares: 41,
    liked: false,
    saved: false,
    sponsored: false,
    category: "Travel",
  },
];

export const products = [
  {
    id: "product-1",
    name: "Handwoven Olive Tote",
    price: 68,
    currency: "USD",
    imageUrl:
      "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=900&auto=format&fit=crop",
    seller: people.zara,
    location: "Lahore, Pakistan",
    rating: 4.9,
    reviewCount: 184,
    availability: "In stock",
    category: "Fashion",
    description:
      "A roomy everyday tote woven by hand and finished with reinforced leather handles.",
    condition: "New",
  },
  {
    id: "product-2",
    name: "Minimal Ceramic Set",
    price: 42,
    currency: "USD",
    imageUrl:
      "https://images.unsplash.com/photo-1610701596007-11502861dcfa?w=900&auto=format&fit=crop",
    seller: people.lina,
    location: "Amman, Jordan",
    rating: 4.8,
    reviewCount: 97,
    availability: "Only 4 left",
    category: "Home",
    description:
      "A warm stoneware cup and plate set shaped and glazed in a small local workshop.",
    condition: "New",
  },
  {
    id: "product-3",
    name: "Compact Creator Microphone",
    price: 89,
    currency: "USD",
    imageUrl:
      "https://images.unsplash.com/photo-1590602847861-f357a9332bbc?w=900&auto=format&fit=crop",
    seller: people.imran,
    location: "Karachi, Pakistan",
    rating: 4.7,
    reviewCount: 62,
    availability: "In stock",
    category: "Tech",
    description:
      "Portable USB-C microphone with a cardioid capsule for calls, podcasts, and live sessions.",
    condition: "New",
  },
];

export function getProductDetail(product: (typeof products)[number]) {
  const limitedQuantity = /^Only (\d+) left$/i.exec(product.availability)?.[1];
  return {
  ...product,
  images: [product.imageUrl],
  quantity: limitedQuantity ? Number(limitedQuantity) : 8,
  delivery: "Tracked international delivery in 5–10 business days.",
  returnPolicy: "Returns accepted within 14 days in original condition.",
  specifications: [
    { label: "Origin", value: product.location },
    { label: "Condition", value: product.condition },
  ],
  };
}

export const productDetails = products.map(getProductDetail);

function mapPersistedProduct(row: {
  listing: typeof marketListingsTable.$inferSelect;
  inventory: typeof marketPaymentInventoryTable.$inferSelect | null;
  seller: typeof usersTable.$inferSelect;
  account: typeof connectedPaymentAccountsTable.$inferSelect | null;
}) {
  const quantity = row.inventory?.availableQuantity ?? 0;
  return {
    id: row.listing.id,
    name: row.listing.name,
    price: row.listing.amountMinor / 100,
    currency: row.listing.currency.toUpperCase(),
    imageUrl: row.listing.imageUrl,
    seller: {
      id: row.seller.id,
      name: row.seller.name,
      handle: row.seller.handle,
      avatarUrl: row.seller.avatarUrl,
      location: row.seller.location,
      verified: row.account?.status === "enabled",
      role: row.seller.role,
    },
    location: row.listing.location,
    rating: 0,
    reviewCount: 0,
    availability: quantity > 0 ? "in_stock" : "sold_out",
    checkoutReady: Boolean(
      quantity > 0 &&
      row.listing.status === "published" &&
      row.account?.chargesEnabled &&
      row.account?.payoutsEnabled
    ),
    category: row.listing.category,
    status: row.listing.status === "published" ? "published" as const : "unpublished" as const,
    description: row.listing.description,
    condition: row.listing.condition,
    images: [row.listing.imageUrl],
    quantity,
    delivery: "Delivery terms are arranged with the seller.",
    returnPolicy: "Return eligibility is provided by the seller.",
    specifications: [
      { label: "Origin", value: row.listing.location || "Not specified" },
      { label: "Condition", value: row.listing.condition },
    ],
  };
}

const persistedProductSelection = {
  listing: marketListingsTable,
  inventory: marketPaymentInventoryTable,
  seller: usersTable,
  account: connectedPaymentAccountsTable,
};

export async function listPersistedProducts() {
  const rows = await db.select(persistedProductSelection)
    .from(marketListingsTable)
    .innerJoin(usersTable, eq(usersTable.id, marketListingsTable.sellerUserId))
    .leftJoin(marketPaymentInventoryTable, eq(marketPaymentInventoryTable.productId, marketListingsTable.id))
    .leftJoin(connectedPaymentAccountsTable, eq(connectedPaymentAccountsTable.userId, marketListingsTable.sellerUserId))
    .where(eq(marketListingsTable.status, "published"))
    .orderBy(desc(marketListingsTable.createdAt));
  return rows.map(mapPersistedProduct);
}

export async function listSellerPersistedProducts(sellerUserId: string) {
  const rows = await db.select(persistedProductSelection)
    .from(marketListingsTable)
    .innerJoin(usersTable, eq(usersTable.id, marketListingsTable.sellerUserId))
    .leftJoin(marketPaymentInventoryTable, eq(marketPaymentInventoryTable.productId, marketListingsTable.id))
    .leftJoin(connectedPaymentAccountsTable, eq(connectedPaymentAccountsTable.userId, marketListingsTable.sellerUserId))
    .where(eq(marketListingsTable.sellerUserId, sellerUserId))
    .orderBy(desc(marketListingsTable.createdAt));
  return rows.map(mapPersistedProduct);
}

export async function getPersistedProduct(productId: string, includeUnpublished = false) {
  const [row] = await db.select(persistedProductSelection)
    .from(marketListingsTable)
    .innerJoin(usersTable, eq(usersTable.id, marketListingsTable.sellerUserId))
    .leftJoin(marketPaymentInventoryTable, eq(marketPaymentInventoryTable.productId, marketListingsTable.id))
    .leftJoin(connectedPaymentAccountsTable, eq(connectedPaymentAccountsTable.userId, marketListingsTable.sellerUserId))
    .where(eq(marketListingsTable.id, productId));
  if (!row || (!includeUnpublished && row.listing.status !== "published")) return undefined;
  return mapPersistedProduct(row);
}

export async function createPersistedProduct(
  sellerUserId: string,
  productId: string,
  input: {
    name: string;
    price: number;
    currency: string;
    imageUrl: string;
    category: string;
    description: string;
    condition?: string;
    quantity: number;
  },
) {
  const amountMinor = Math.round(input.price * 100);
  if (
    input.currency.toUpperCase() !== "USD" ||
    !Number.isFinite(input.price) ||
    amountMinor < 1 ||
    amountMinor > 99_999_999
  ) {
    throw new Error("Listings must use a valid USD price between $0.01 and $999,999.99");
  }
  if (!Number.isInteger(input.quantity) || input.quantity < 1 || input.quantity > 100_000) {
    throw new Error("Inventory quantity must be between 1 and 100,000");
  }
  const [account] = await db.select().from(connectedPaymentAccountsTable)
    .where(eq(connectedPaymentAccountsTable.userId, sellerUserId));
  if (!account?.chargesEnabled || !account.payoutsEnabled || account.status !== "enabled") {
    throw new Error("Complete seller verification before publishing a listing");
  }
  const [seller] = await db.select().from(usersTable).where(eq(usersTable.id, sellerUserId));
  if (!seller) throw new Error("Seller profile not found");
  await db.transaction(async (tx) => {
    await tx.insert(marketListingsTable).values({
      id: productId,
      sellerUserId,
      name: input.name,
      description: input.description,
      category: input.category,
      condition: input.condition ?? "New",
      imageUrl: input.imageUrl,
      location: seller.location,
      amountMinor,
      currency: "usd",
    });
    await tx.insert(marketPaymentInventoryTable).values({
      productId,
      availableQuantity: input.quantity,
    });
  });
  return getPersistedProduct(productId);
}

export async function updatePersistedProduct(
  sellerUserId: string,
  productId: string,
  input: {
    name?: string;
    price?: number;
    imageUrl?: string;
    category?: string;
    description?: string;
    condition?: string;
    quantity?: number;
    expectedQuantity?: number;
    status?: "published" | "unpublished";
  },
) {
  const amountMinor = input.price === undefined ? undefined : Math.round(input.price * 100);
  if (
    input.price !== undefined &&
    (!Number.isFinite(input.price) || amountMinor === undefined || amountMinor < 1 || amountMinor > 99_999_999)
  ) {
    throw new Error("Listings must use a valid USD price between $0.01 and $999,999.99");
  }
  if (
    input.quantity !== undefined &&
    (!Number.isInteger(input.quantity) || input.quantity < 0 || input.quantity > 100_000)
  ) {
    throw new Error("Inventory quantity must be between 0 and 100,000");
  }
  if (
    input.quantity !== undefined &&
    (
      input.expectedQuantity === undefined ||
      !Number.isInteger(input.expectedQuantity) ||
      input.expectedQuantity < 0 ||
      input.expectedQuantity > 100_000
    )
  ) {
    throw new Error("Expected inventory quantity is required when changing inventory");
  }
  const updated = await db.transaction(async (tx) => {
    const [listing] = await tx.select().from(marketListingsTable).where(and(
      eq(marketListingsTable.id, productId),
      eq(marketListingsTable.sellerUserId, sellerUserId),
    )).for("update");
    if (!listing) return false;
    const [inventory] = await tx.select().from(marketPaymentInventoryTable)
      .where(eq(marketPaymentInventoryTable.productId, productId))
      .for("update");
    if (!inventory) throw new Error("Listing inventory not found");
    if (input.quantity !== undefined && inventory.availableQuantity !== input.expectedQuantity) {
      throw new Error("Inventory changed since this listing was loaded");
    }
    if (input.status === "published") {
      const [account] = await tx.select().from(connectedPaymentAccountsTable)
        .where(eq(connectedPaymentAccountsTable.userId, sellerUserId));
      if (!account?.chargesEnabled || !account.payoutsEnabled || account.status !== "enabled") {
        throw new Error("Complete seller verification before publishing a listing");
      }
    }
    await tx.update(marketListingsTable).set({
      ...(input.name !== undefined ? { name: input.name } : {}),
      ...(input.description !== undefined ? { description: input.description } : {}),
      ...(input.category !== undefined ? { category: input.category } : {}),
      ...(input.condition !== undefined ? { condition: input.condition } : {}),
      ...(input.imageUrl !== undefined ? { imageUrl: input.imageUrl } : {}),
      ...(amountMinor !== undefined ? { amountMinor } : {}),
      ...(input.status !== undefined ? { status: input.status } : {}),
      updatedAt: new Date(),
    }).where(and(
      eq(marketListingsTable.id, productId),
      eq(marketListingsTable.sellerUserId, sellerUserId),
    ));
    if (input.quantity !== undefined) {
      await tx.update(marketPaymentInventoryTable).set({
        availableQuantity: input.quantity,
        updatedAt: new Date(),
      }).where(eq(marketPaymentInventoryTable.productId, productId));
    }
    return true;
  });
  if (!updated) return undefined;
  return getPersistedProduct(productId, true);
}

export const liveRooms = [
  {
    id: "live-1",
    title: "Studio tour: new summer pieces",
    category: "Style",
    host: people.zara,
    coverUrl:
      "https://images.unsplash.com/photo-1445205170230-053b83016050?w=1200&auto=format&fit=crop",
    viewers: 2384,
    isLive: true,
    tags: ["fashion", "behind the scenes"],
  },
  {
    id: "live-2",
    title: "Build a client-ready portfolio",
    category: "Freelancing",
    host: people.imran,
    coverUrl:
      "https://images.unsplash.com/photo-1556761175-b413da4baf72?w=1200&auto=format&fit=crop",
    viewers: 892,
    isLive: true,
    tags: ["portfolio", "career"],
  },
];

export const notifications = [
  {
    id: "notification-1",
    kind: "message",
    title: "New message from Zara",
    body: "I can ship that color tomorrow.",
    createdAt: "4 min ago",
    read: false,
  },
  {
    id: "notification-2",
    kind: "live",
    title: "Lina is going live",
    body: "Join the café tour from Amman.",
    createdAt: "22 min ago",
    read: false,
  },
  {
    id: "notification-3",
    kind: "opportunity",
    title: "New creator opportunity",
    body: "A regional lifestyle campaign matches your profile.",
    createdAt: "Today",
    read: true,
  },
];

export const opportunities = [
  {
    id: "opportunity-1",
    title: "Creator spotlight applications",
    type: "Creator",
    description:
      "Apply to be featured in the weekly regional creator collection.",
    actionLabel: "View details",
    accent: "olive",
  },
  {
    id: "opportunity-2",
    title: "Free portfolio review",
    type: "Freelance",
    description:
      "Get practical feedback from experienced independent professionals.",
    actionLabel: "Reserve a place",
    accent: "sand",
  },
  {
    id: "opportunity-3",
    title: "Small business shipping guide",
    type: "Business",
    description:
      "A clear checklist for selling to customers in new countries.",
    actionLabel: "Open guide",
    accent: "sage",
  },
];
