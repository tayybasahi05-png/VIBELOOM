import { randomUUID } from "node:crypto";
import { Readable } from "node:stream";
import { Storage, type File } from "@google-cloud/storage";

const REPLIT_SIDECAR_ENDPOINT = "http://127.0.0.1:1106";

export const objectStorageClient = new Storage({
  credentials: {
    audience: "replit",
    subject_token_type: "access_token",
    token_url: `${REPLIT_SIDECAR_ENDPOINT}/token`,
    type: "external_account",
    credential_source: {
      url: `${REPLIT_SIDECAR_ENDPOINT}/credential`,
      format: { type: "json", subject_token_field_name: "access_token" },
    },
    universe_domain: "googleapis.com",
  },
  projectId: "",
});

export class ObjectNotFoundError extends Error {
  constructor() {
    super("Object not found");
    this.name = "ObjectNotFoundError";
  }
}

export type StoredObjectMetadata = {
  contentType: string;
  size: number;
};

export class ObjectStorageService {
  private getPrivateObjectDir(): string {
    const dir = process.env.PRIVATE_OBJECT_DIR;
    if (!dir) {
      throw new Error(
        "PRIVATE_OBJECT_DIR is not set. Provision App Storage before uploading stories.",
      );
    }
    return dir.replace(/\/+$/, "");
  }

  async getStoryUploadURL(
    userId: string,
  ): Promise<{ uploadURL: string; objectPath: string }> {
    if (!/^[A-Za-z0-9_:-]+$/.test(userId)) {
      throw new Error("Invalid user id");
    }
    const fullPath = `${this.getPrivateObjectDir()}/stories/${userId}/${randomUUID()}`;
    const { bucketName, objectName } = parseObjectPath(fullPath);
    const uploadURL = await signObjectURL(bucketName, objectName, "PUT", 900);
    return { uploadURL, objectPath: `/objects/stories/${userId}/${fullPath.split("/").at(-1)}` };
  }

  async getObjectEntityFile(objectPath: string): Promise<File> {
    if (
      !objectPath.startsWith("/objects/stories/") ||
      objectPath.includes("..") ||
      objectPath.includes("\\") ||
      objectPath.includes("?")
    ) {
      throw new ObjectNotFoundError();
    }
    const entityId = objectPath.slice("/objects/".length);
    const { bucketName, objectName } = parseObjectPath(
      `${this.getPrivateObjectDir()}/${entityId}`,
    );
    const file = objectStorageClient.bucket(bucketName).file(objectName);
    const [exists] = await file.exists();
    if (!exists) throw new ObjectNotFoundError();
    return file;
  }

  async getObjectMetadata(objectPath: string): Promise<{
    file: File;
    metadata: StoredObjectMetadata;
  }> {
    const file = await this.getObjectEntityFile(objectPath);
    const [metadata] = await file.getMetadata();
    return {
      file,
      metadata: {
        contentType: metadata.contentType ?? "application/octet-stream",
        size: Number(metadata.size ?? 0),
      },
    };
  }

  /**
   * Read only the bounded image header prefix. Image dimensions are encoded
   * near the beginning of supported formats, so the API never buffers a
   * user-controlled media object in full.
   */
  async readObjectPrefix(file: File, maxBytes = 1024 * 1024): Promise<Buffer> {
    const chunks: Buffer[] = [];
    let total = 0;
    const stream = file.createReadStream({ start: 0, end: maxBytes - 1 });
    for await (const chunk of stream) {
      const bytes = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
      const remaining = maxBytes - total;
      if (remaining <= 0) break;
      const bounded = bytes.length > remaining ? bytes.subarray(0, remaining) : bytes;
      chunks.push(bounded);
      total += bounded.length;
      if (total >= maxBytes) break;
    }
    return Buffer.concat(chunks, total);
  }

  async downloadObject(file: File): Promise<Response> {
    const [metadata] = await file.getMetadata();
    const stream = Readable.toWeb(file.createReadStream()) as ReadableStream;
    const headers: Record<string, string> = {
      "Content-Type": metadata.contentType ?? "application/octet-stream",
      "Cache-Control": "private, max-age=60",
    };
    if (metadata.size) headers["Content-Length"] = String(metadata.size);
    return new Response(stream, { headers });
  }
}

function parseObjectPath(path: string): { bucketName: string; objectName: string } {
  const normalized = path.startsWith("/") ? path : `/${path}`;
  const parts = normalized.split("/");
  if (parts.length < 3 || !parts[1] || !parts.slice(2).join("/")) {
    throw new Error("Invalid object storage path");
  }
  return { bucketName: parts[1], objectName: parts.slice(2).join("/") };
}

async function signObjectURL(
  bucketName: string,
  objectName: string,
  method: "PUT" | "GET",
  ttlSec: number,
): Promise<string> {
  const response = await fetch(`${REPLIT_SIDECAR_ENDPOINT}/object-storage/signed-object-url`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      bucket_name: bucketName,
      object_name: objectName,
      method,
      expires_at: new Date(Date.now() + ttlSec * 1000).toISOString(),
    }),
    signal: AbortSignal.timeout(30_000),
  });
  if (!response.ok) {
    throw new Error(`Failed to sign object URL (${response.status})`);
  }
  const body = (await response.json()) as { signed_url?: string };
  if (!body.signed_url) throw new Error("Storage signer returned no URL");
  return body.signed_url;
}