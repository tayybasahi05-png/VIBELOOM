import { and, desc, eq } from "drizzle-orm";
import {
  db,
  giftTransfersTable,
  stripeCheckoutRecordsTable,
  walletLedgerTable,
  walletsTable,
} from "@workspace/db";
import { mapTransfer } from "./live-service";

export const COIN_PACKS = [
  { id: "coins-100", coinAmount: 100, priceCents: 199, currency: "usd" },
  { id: "coins-550", coinAmount: 550, priceCents: 899, currency: "usd" },
  { id: "coins-1200", coinAmount: 1200, priceCents: 1699, currency: "usd" },
] as const;

export function getCoinPack(packId: string) {
  return COIN_PACKS.find((pack) => pack.id === packId);
}

export async function getWalletSummary(userId: string) {
  const [wallet] = await db.select().from(walletsTable).where(eq(walletsTable.userId, userId));
  return {
    coinBalance: wallet?.coinBalance ?? 0,
    earnings: wallet?.creatorEarnings ?? 0,
    pendingPayout: 0,
    currency: "USD",
  };
}

export async function listWalletTransactions(userId: string) {
  return db
    .select()
    .from(walletLedgerTable)
    .where(eq(walletLedgerTable.userId, userId))
    .orderBy(desc(walletLedgerTable.createdAt))
    .limit(100);
}

export async function listGiftHistory(userId: string, direction: "sent" | "received") {
  const column =
    direction === "sent"
      ? eq(giftTransfersTable.senderUserId, userId)
      : eq(giftTransfersTable.receiverUserId, userId);
  const transfers = await db
    .select()
    .from(giftTransfersTable)
    .where(and(column))
    .orderBy(desc(giftTransfersTable.createdAt))
    .limit(100);
  return transfers.map(mapTransfer);
}

export async function createCheckoutRecord(values: {
  userId: string;
  checkoutSessionId: string;
  packId: string;
  coinAmount: number;
  amountMinor: number;
  currency: string;
}) {
  const [record] = await db
    .insert(stripeCheckoutRecordsTable)
    .values(values)
    .onConflictDoNothing()
    .returning();
  if (record) return record;
  const [existing] = await db
    .select()
    .from(stripeCheckoutRecordsTable)
    .where(eq(stripeCheckoutRecordsTable.checkoutSessionId, values.checkoutSessionId));
  return existing;
}

export async function getCheckoutRecord(sessionId: string) {
  const [record] = await db
    .select()
    .from(stripeCheckoutRecordsTable)
    .where(eq(stripeCheckoutRecordsTable.checkoutSessionId, sessionId));
  return record;
}

export async function creditPaidCheckout(sessionId: string, paymentIntentId?: string | null) {
  return db.transaction(async (tx) => {
    const [record] = await tx
      .select()
      .from(stripeCheckoutRecordsTable)
      .where(eq(stripeCheckoutRecordsTable.checkoutSessionId, sessionId))
      .for("update");
    if (!record) throw new Error("Coin checkout record is not available yet");
    if (record.status === "paid") return record;
    const [wallet] = await tx
      .select()
      .from(walletsTable)
      .where(eq(walletsTable.userId, record.userId))
      .for("update");
    if (!wallet) throw new Error("Wallet is not available");
    const balanceAfter = wallet.coinBalance + record.coinAmount;
    await tx
      .update(walletsTable)
      .set({ coinBalance: balanceAfter })
      .where(eq(walletsTable.userId, record.userId));
    await tx.insert(walletLedgerTable).values({
      userId: record.userId,
      amount: record.coinAmount,
      balanceAfter,
      kind: "coin_purchase",
      referenceId: sessionId,
      idempotencyKey: `checkout:${sessionId}`,
    });
    const [updated] = await tx
      .update(stripeCheckoutRecordsTable)
      .set({
        status: "paid",
        paymentIntentId: paymentIntentId ?? record.paymentIntentId,
        paidAt: new Date(),
      })
      .where(eq(stripeCheckoutRecordsTable.checkoutSessionId, sessionId))
      .returning();
    return updated;
  });
}