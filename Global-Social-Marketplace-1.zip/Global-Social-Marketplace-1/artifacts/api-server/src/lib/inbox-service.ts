import { and, asc, count, desc, eq, gt, inArray, ne, sql } from "drizzle-orm";
import {
  db,
  inboxConversationParticipantsTable,
  inboxConversationsTable,
  inboxMessagesTable,
  usersTable,
} from "@workspace/db";

export type InboxPerson = {
  id: string;
  name: string;
  handle: string;
  avatarUrl: string;
  location: string;
  verified: boolean;
  role: "member" | "creator" | "business" | "freelancer";
};

function toPerson(user: typeof usersTable.$inferSelect): InboxPerson {
  const supportedRoles = ["member", "creator", "business", "freelancer"] as const;
  const role = supportedRoles.find((value) => value === user.role) ?? "member";
  return {
    id: user.id,
    name: user.name,
    handle: user.handle.startsWith("@") ? user.handle : `@${user.handle}`,
    avatarUrl: user.avatarUrl,
    location: user.location,
    verified: user.verified,
    role,
  };
}

export async function syncInboxUser(person: InboxPerson) {
  await db
    .insert(usersTable)
    .values({
      ...person,
      handle: person.handle.replace(/^@/, ""),
    })
    .onConflictDoUpdate({
      target: usersTable.id,
      set: {
        name: person.name,
        handle: person.handle.replace(/^@/, ""),
        avatarUrl: person.avatarUrl,
        location: person.location,
        verified: person.verified,
        role: person.role,
        updatedAt: new Date(),
      },
    });
}

export async function getInboxPerson(userId: string) {
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId)).limit(1);
  return user ? toPerson(user) : null;
}

export async function searchInboxPeople(query: string) {
  const users = await db.select().from(usersTable).orderBy(asc(usersTable.name));
  const normalizedQuery = query.trim().toLowerCase();
  return users
    .filter((user) =>
      `${user.name} ${user.handle} ${user.location}`.toLowerCase().includes(normalizedQuery),
    )
    .map(toPerson);
}

export async function listInboxConversations(userId: string) {
  const memberships = await db
    .select({
      conversationId: inboxConversationParticipantsTable.conversationId,
      updatedAt: inboxConversationsTable.updatedAt,
      lastReadAt: inboxConversationParticipantsTable.lastReadAt,
    })
    .from(inboxConversationParticipantsTable)
    .innerJoin(
      inboxConversationsTable,
      eq(inboxConversationsTable.id, inboxConversationParticipantsTable.conversationId),
    )
    .where(eq(inboxConversationParticipantsTable.userId, userId))
    .orderBy(desc(inboxConversationsTable.updatedAt));

  return Promise.all(
    memberships.map(async (membership) => {
      const [participantRow, latestMessage, unreadResult] = await Promise.all([
        db
          .select({ user: usersTable })
          .from(inboxConversationParticipantsTable)
          .innerJoin(usersTable, eq(usersTable.id, inboxConversationParticipantsTable.userId))
          .where(
            and(
              eq(
                inboxConversationParticipantsTable.conversationId,
                membership.conversationId,
              ),
              ne(inboxConversationParticipantsTable.userId, userId),
            ),
          )
          .limit(1),
        db
          .select({ body: inboxMessagesTable.body })
          .from(inboxMessagesTable)
          .where(eq(inboxMessagesTable.conversationId, membership.conversationId))
          .orderBy(desc(inboxMessagesTable.createdAt))
          .limit(1),
        db
          .select({ value: count() })
          .from(inboxMessagesTable)
          .where(
            and(
              eq(inboxMessagesTable.conversationId, membership.conversationId),
              ne(inboxMessagesTable.senderId, userId),
              gt(inboxMessagesTable.createdAt, membership.lastReadAt),
            ),
          ),
      ]);

      const participant = participantRow[0]?.user;
      if (!participant) return null;
      return {
        id: membership.conversationId,
        participant: toPerson(participant),
        preview: latestMessage[0]?.body ?? "",
        updatedAt: membership.updatedAt.toISOString(),
        unreadCount: unreadResult[0]?.value ?? 0,
        online: false,
      };
    }),
  ).then((items) => items.filter((item): item is NonNullable<typeof item> => item !== null));
}

export async function listInboxNotifications(userId: string) {
  const rows = await db
    .select({
      id: inboxMessagesTable.id,
      conversationId: inboxMessagesTable.conversationId,
      body: inboxMessagesTable.body,
      createdAt: inboxMessagesTable.createdAt,
      lastReadAt: inboxConversationParticipantsTable.lastReadAt,
      senderName: usersTable.name,
    })
    .from(inboxConversationParticipantsTable)
    .innerJoin(
      inboxMessagesTable,
      eq(inboxMessagesTable.conversationId, inboxConversationParticipantsTable.conversationId),
    )
    .innerJoin(usersTable, eq(usersTable.id, inboxMessagesTable.senderId))
    .where(
      and(
        eq(inboxConversationParticipantsTable.userId, userId),
        ne(inboxMessagesTable.senderId, userId),
      ),
    )
    .orderBy(desc(inboxMessagesTable.createdAt));

  return rows.map((row) => ({
    id: `message-${row.id}`,
    kind: "message",
    title: `New message from ${row.senderName}`,
    body: row.body,
    createdAt: row.createdAt.toISOString(),
    read: row.createdAt <= row.lastReadAt,
    conversationId: row.conversationId,
  }));
}

function directConversationKey(firstUserId: string, secondUserId: string) {
  return JSON.stringify([firstUserId, secondUserId].sort());
}

async function getConversationSummary(conversationId: string, userId: string) {
  const conversations = await listInboxConversations(userId);
  return conversations.find((conversation) => conversation.id === conversationId) ?? null;
}

export async function createOrGetDirectConversation(userId: string, participantId: string) {
  if (userId === participantId) {
    return { status: "invalid" as const };
  }

  const [participant] = await db
    .select({ id: usersTable.id })
    .from(usersTable)
    .where(eq(usersTable.id, participantId))
    .limit(1);
  if (!participant) {
    return { status: "not_found" as const };
  }

  const directKey = directConversationKey(userId, participantId);
  const existingMemberships = await db
    .select({ conversationId: inboxConversationParticipantsTable.conversationId })
    .from(inboxConversationParticipantsTable)
    .where(eq(inboxConversationParticipantsTable.userId, userId));
  if (existingMemberships.length > 0) {
    const existingParticipants = await db
      .select({
        conversationId: inboxConversationParticipantsTable.conversationId,
        userId: inboxConversationParticipantsTable.userId,
      })
      .from(inboxConversationParticipantsTable)
      .where(
        inArray(
          inboxConversationParticipantsTable.conversationId,
          existingMemberships.map(({ conversationId }) => conversationId),
        ),
      );
    const participantsByConversation = new Map<string, string[]>();
    for (const row of existingParticipants) {
      const participantIds = participantsByConversation.get(row.conversationId) ?? [];
      participantIds.push(row.userId);
      participantsByConversation.set(row.conversationId, participantIds);
    }
    const legacyConversationId = [...participantsByConversation].find(
      ([, participantIds]) =>
        participantIds.length === 2 &&
        directConversationKey(participantIds[0], participantIds[1]) === directKey,
    )?.[0];
    if (legacyConversationId) {
      await db
        .update(inboxConversationsTable)
        .set({ directKey })
        .where(eq(inboxConversationsTable.id, legacyConversationId));
      const conversation = await getConversationSummary(legacyConversationId, userId);
      if (!conversation) {
        throw new Error("Direct conversation participants could not be loaded");
      }
      return { status: "existing" as const, conversation };
    }
  }

  const result = await db.transaction(async (tx) => {
    const [created] = await tx
      .insert(inboxConversationsTable)
      .values({ directKey })
      .onConflictDoNothing({ target: inboxConversationsTable.directKey })
      .returning({ id: inboxConversationsTable.id });

    const [conversation] = created
      ? [created]
      : await tx
          .select({ id: inboxConversationsTable.id })
          .from(inboxConversationsTable)
          .where(eq(inboxConversationsTable.directKey, directKey))
          .limit(1);

    if (!conversation) {
      throw new Error("Direct conversation could not be created");
    }

    if (created) {
      await tx.insert(inboxConversationParticipantsTable).values([
        { conversationId: conversation.id, userId },
        { conversationId: conversation.id, userId: participantId },
      ]);
    }

    return { id: conversation.id, created: Boolean(created) };
  });

  const conversation = await getConversationSummary(result.id, userId);
  if (!conversation) {
    throw new Error("Direct conversation participants could not be loaded");
  }
  return {
    status: result.created ? ("created" as const) : ("existing" as const),
    conversation,
  };
}

export async function listInboxMessages(conversationId: string, userId: string) {
  return db.transaction(async (tx) => {
    const [membership] = await tx
      .select({ conversationId: inboxConversationParticipantsTable.conversationId })
      .from(inboxConversationParticipantsTable)
      .where(
        and(
          eq(inboxConversationParticipantsTable.conversationId, conversationId),
          eq(inboxConversationParticipantsTable.userId, userId),
        ),
      )
      .limit(1);
    if (!membership) return null;

    const rows = await tx
      .select()
      .from(inboxMessagesTable)
      .where(eq(inboxMessagesTable.conversationId, conversationId))
      .orderBy(asc(inboxMessagesTable.createdAt));

    const latestReturnedMessage = rows.at(-1);
    if (latestReturnedMessage) {
      await tx
        .update(inboxConversationParticipantsTable)
        .set({
          lastReadAt: sql`greatest(
            ${inboxConversationParticipantsTable.lastReadAt},
            ${latestReturnedMessage.createdAt}
          )`,
        })
        .where(
          and(
            eq(inboxConversationParticipantsTable.conversationId, conversationId),
            eq(inboxConversationParticipantsTable.userId, userId),
          ),
        );
    }

    return rows.map((message) => ({
      ...message,
      createdAt: message.createdAt.toISOString(),
      isMine: message.senderId === userId,
    }));
  });
}

export async function sendInboxMessage(
  conversationId: string,
  userId: string,
  body: string,
) {
  return db.transaction(async (tx) => {
    const [membership] = await tx
      .select({ conversationId: inboxConversationParticipantsTable.conversationId })
      .from(inboxConversationParticipantsTable)
      .where(
        and(
          eq(inboxConversationParticipantsTable.conversationId, conversationId),
          eq(inboxConversationParticipantsTable.userId, userId),
        ),
      )
      .limit(1);
    if (!membership) return null;

    const now = new Date();
    const [message] = await tx
      .insert(inboxMessagesTable)
      .values({ conversationId, senderId: userId, body, createdAt: now })
      .returning();
    await tx
      .update(inboxConversationsTable)
      .set({ updatedAt: now })
      .where(eq(inboxConversationsTable.id, conversationId));
    await tx
      .update(inboxConversationParticipantsTable)
      .set({ lastReadAt: now })
      .where(
        and(
          eq(inboxConversationParticipantsTable.conversationId, conversationId),
          eq(inboxConversationParticipantsTable.userId, userId),
        ),
      );

    return {
      ...message,
      createdAt: message.createdAt.toISOString(),
      isMine: true,
    };
  });
}