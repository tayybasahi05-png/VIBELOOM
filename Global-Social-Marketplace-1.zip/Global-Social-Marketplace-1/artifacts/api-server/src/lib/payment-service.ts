import { and, desc, eq, inArray, lt, sql } from "drizzle-orm";
import {
  connectedPaymentAccountsTable,
  db,
  marketPaymentInventoryTable,
  marketListingsTable,
  paymentOrdersTable,
  paymentPayoutsTable,
  paymentReservationsTable,
  paymentRefundsTable,
  paymentTransfersTable,
  usersTable,
} from "@workspace/db";
import { getPersistedProduct } from "./platform-data";
import { StripeProviderError, stripeRequest } from "../stripeConnector";

const CURRENCY = "usd";
export type TaxRegion = "pakistan" | "international";
type StripeRequester = typeof stripeRequest;
let requestStripe: StripeRequester = stripeRequest;
type MarketProduct = NonNullable<Awaited<ReturnType<typeof getPersistedProduct>>>;
type ProductResolver = (productId: string) => MarketProduct | undefined | Promise<MarketProduct | undefined>;
let resolveProduct: ProductResolver = getPersistedProduct;
let beforeCheckoutLockForTests: (() => void | Promise<void>) | undefined;

export function setPaymentStripeRequesterForTests(requester?: StripeRequester) {
  if (process.env.NODE_ENV !== "test") throw new Error("Stripe requester can only be replaced in tests");
  requestStripe = requester ?? stripeRequest;
}

export function setPaymentProductResolverForTests(resolver?: ProductResolver) {
  if (process.env.NODE_ENV !== "test") throw new Error("Product resolver can only be replaced in tests");
  resolveProduct = resolver ?? getPersistedProduct;
}

export function setPaymentCheckoutBeforeLockForTests(callback?: () => void | Promise<void>) {
  if (process.env.NODE_ENV !== "test") throw new Error("Checkout hooks can only be replaced in tests");
  beforeCheckoutLockForTests = callback;
}

function mapOrder(row: typeof paymentOrdersTable.$inferSelect) {
  const subtotalMinor = row.subtotalMinor ?? row.amountMinor;
  const taxMinor = row.taxMinor ?? 0;
  return {
    id: row.id,
    kind: row.kind as "market_purchase" | "coin_purchase",
    referenceId: row.referenceId,
    description: row.description,
    amountMinor: row.amountMinor,
    subtotalMinor,
    taxMinor,
    taxRateBps: row.taxRateBps ?? 0,
    taxRegion: row.taxRegion === "pakistan" || row.taxRegion === "international" ? row.taxRegion : null,
    currency: row.currency.toLowerCase(),
    status: row.status as "created" | "pending" | "requires_action" | "succeeded" | "failed" | "canceled" | "partially_refunded" | "refunded" | "disputed",
    refundedAmountMinor: row.refundedAmountMinor,
    receiptUrl: row.receiptUrl,
    createdAt: row.createdAt,
    updatedAt: row.updatedAt,
  };
}

function marketPlatformFeeMinor(subtotalMinor: number) {
  return Math.max(1, Math.round(subtotalMinor * 0.1));
}

function persistedMarketPlatformFeeMinor(
  sale: { grossAmountMinor: number; subtotalMinor: number | null; metadata: Record<string, string> },
) {
  const persisted = Number(sale.metadata.platformFeeMinor);
  if (Number.isInteger(persisted) && persisted > 0 && persisted <= sale.grossAmountMinor) return persisted;
  return marketPlatformFeeMinor(sale.subtotalMinor ?? sale.grossAmountMinor);
}

function mapRefund(row: typeof paymentRefundsTable.$inferSelect) {
  const status = row.status === "succeeded"
    ? "completed"
    : row.status === "canceled"
      ? "failed"
      : row.status;
  return {
    id: row.id,
    orderId: row.orderId,
    amountMinor: row.amountMinor,
    currency: row.currency.toLowerCase(),
    reason: row.reason,
    status: status as "pending" | "approved" | "denied" | "failed" | "completed",
    denialReason: row.denialReason,
    createdAt: row.createdAt,
    updatedAt: row.updatedAt,
  };
}

export async function isSupportOperator(userId: string) {
  const [user] = await db.select({ role: usersTable.role }).from(usersTable).where(eq(usersTable.id, userId));
  return user?.role === "support" || user?.role === "admin";
}

async function assertSupportOperator(userId: string) {
  if (!await isSupportOperator(userId)) throw new Error("Support operator access required");
}

async function getProduct(productId: string) {
  return resolveProduct(productId);
}

async function getRecipient(userId: string) {
  const [account] = await db
    .select()
    .from(connectedPaymentAccountsTable)
    .where(eq(connectedPaymentAccountsTable.userId, userId));
  return account;
}

async function ensureStripePrice(productId: string, name: string, amountMinor: number) {
  const query = encodeURIComponent(`metadata['vibeloom_product_id']:'${productId}' AND active:'true'`);
  const found = await requestStripe<{ data: Array<{ id: string }> }>(`/v1/products/search?query=${query}`);
  const stripeProduct =
    found.data[0] ??
    (await requestStripe<{ id: string }>("/v1/products", {
      method: "POST",
      body: new URLSearchParams({
        name,
        "metadata[vibeloom_product_id]": productId,
      }),
    }));
  const prices = await requestStripe<{ data: Array<{ id: string; unit_amount: number | null; currency: string }> }>(
    `/v1/prices?product=${stripeProduct.id}&active=true&type=one_time&limit=100`,
  );
  const existing = prices.data.find((price) => price.unit_amount === amountMinor && price.currency.toLowerCase() === CURRENCY);
  if (existing) return existing.id;
  const price = await requestStripe<{ id: string }>("/v1/prices", {
    method: "POST",
    body: new URLSearchParams({
      product: stripeProduct.id,
      unit_amount: String(amountMinor),
      currency: CURRENCY,
      "metadata[vibeloom_product_id]": productId,
    }),
  });
  return price.id;
}

export function paymentCapabilities() {
  const testMode = process.env.STRIPE_MODE !== "live";
  const configured = process.env.STRIPE_ENABLED === "true";
  const liveApproved = testMode || process.env.STRIPE_LIVE_APPROVED === "true";
  return {
    provider: "stripe" as const,
    hostedPaymentCollection: configured,
    automaticPaymentMethods: true,
    storesSensitiveCredentials: false,
    livePaymentsEnabled: configured && process.env.STRIPE_MODE === "live" && process.env.STRIPE_LIVE_APPROVED === "true",
    marketplaceCheckout: configured && liveApproved && process.env.STRIPE_MARKETPLACE_APPROVED === "true",
    recipientOnboarding: configured && liveApproved,
    refunds: configured && liveApproved && process.env.STRIPE_REFUNDS_APPROVED === "true",
    message: configured
      ? "Hosted Stripe Checkout is used. Marketplace checkout is gated on recipient Connect capability."
      : "Stripe payments are not configured.",
    testMode,
  };
}

export async function applyPaidMarketOrder(
  tx: Parameters<Parameters<typeof db.transaction>[0]>[0],
  session: {
    id: string;
    payment_status: string;
    payment_intent?: string | null | { id: string };
    amount_total: number | null;
    currency: string | null;
    client_reference_id: string | null;
    metadata?: Record<string, string> | null;
  },
) {
  const orderId = Number(session.metadata?.orderId);
  if (!Number.isInteger(orderId) || orderId < 1 || session.payment_status !== "paid") return null;
  const [order] = await tx.select().from(paymentOrdersTable).where(eq(paymentOrdersTable.id, orderId)).for("update");
  if (!order?.providerCheckoutSessionId) throw new Error("Checkout binding is not yet persisted");
  if (
    session.id !== order.providerCheckoutSessionId ||
    session.client_reference_id !== order.buyerUserId ||
    session.metadata?.productId !== order.referenceId ||
    session.metadata?.recipientAccountId !== order.metadata.recipientAccountId ||
    session.metadata?.subtotalMinor !== order.metadata.subtotalMinor ||
    session.metadata?.taxMinor !== order.metadata.taxMinor ||
    session.metadata?.taxRateBps !== order.metadata.taxRateBps ||
    session.metadata?.taxRegion !== order.metadata.taxRegion ||
    session.metadata?.amountMinor !== String(order.amountMinor) ||
    session.amount_total !== order.amountMinor ||
    session.currency?.toLowerCase() !== order.currency
  ) throw new Error("Checkout event does not match the persisted order binding");
  const [reservation] = await tx.select().from(paymentReservationsTable)
    .where(eq(paymentReservationsTable.orderId, order.id)).for("update");
  if (!reservation || !["reserved", "fulfilled"].includes(reservation.status)) {
    throw new Error("Paid order does not have a valid inventory reservation");
  }
  if (reservation.status === "reserved") {
    await tx.update(paymentReservationsTable).set({ status: "fulfilled", updatedAt: new Date() })
      .where(eq(paymentReservationsTable.orderId, order.id));
  }
  const paymentIntentId = typeof session.payment_intent === "string"
    ? session.payment_intent
    : session.payment_intent?.id ?? order.providerPaymentIntentId;
  const [updated] = await tx.update(paymentOrdersTable).set({
    status: "succeeded",
    providerPaymentIntentId: paymentIntentId,
    updatedAt: new Date(),
  }).where(eq(paymentOrdersTable.id, order.id)).returning();
  return updated;
}

function assertPaymentCapability(capability: "marketplaceCheckout" | "recipientOnboarding" | "refunds") {
  if (!paymentCapabilities()[capability]) {
    throw new Error("This payment operation is not enabled");
  }
}

export async function createMarketCheckout(
  userId: string,
  productId: string,
  idempotencyKey: string,
  baseUrl: string,
  taxRegion: TaxRegion = "international",
) {
  assertPaymentCapability("marketplaceCheckout");
  const existing = await db.select().from(paymentOrdersTable).where(
    and(eq(paymentOrdersTable.buyerUserId, userId), eq(paymentOrdersTable.idempotencyKey, idempotencyKey)),
  );
  if (existing.some((row) =>
    row.kind !== "market_purchase" ||
    row.referenceId !== productId ||
    (row.taxRegion !== null && row.taxRegion !== taxRegion)
  )) {
    throw new Error("Idempotency key was already used for a different request");
  }
  const duplicate = existing.find((row) => row.kind === "market_purchase" && row.referenceId === productId);
  if (duplicate && duplicate.providerCheckoutSessionId) {
    const session = await requestStripe<{ url: string | null }>(`/v1/checkout/sessions/${duplicate.providerCheckoutSessionId}`);
    return { order: mapOrder(duplicate), url: session.url ?? "" };
  }
  const taxRateBps = taxRegion === "pakistan" ? 500 : 1000;
  let order = duplicate;
  let checkoutContext: {
    productName: string;
    recipientAccountId: string;
    subtotalMinor: number;
    taxMinor: number;
    amountMinor: number;
    taxRateBps: number;
  } | undefined;
  if (!order) {
    const product = await getProduct(productId);
    if (!product) throw new Error("Product not found");
    await beforeCheckoutLockForTests?.();
    const createdContext = await db.transaction(async (tx) => {
      const [listing] = await tx.select().from(marketListingsTable)
        .where(eq(marketListingsTable.id, productId))
        .for("update");
      if (!listing || listing.status !== "published") throw new Error("Product not found");
      const [inventory] = await tx.select().from(marketPaymentInventoryTable)
        .where(eq(marketPaymentInventoryTable.productId, productId))
        .for("update");
      if (!inventory || inventory.availableQuantity < 1) throw new Error("Product is sold out");
      const [recipient] = await tx.select().from(connectedPaymentAccountsTable)
        .where(eq(connectedPaymentAccountsTable.userId, listing.sellerUserId));
      if (!recipient?.chargesEnabled || !recipient.payoutsEnabled || recipient.status !== "enabled") {
        throw new Error("Seller payment capability is unavailable");
      }
      const subtotalMinor = listing.amountMinor;
      const taxMinor = Math.round((subtotalMinor * taxRateBps) / 10_000);
      const amountMinor = subtotalMinor + taxMinor;
      const platformFeeMinor = marketPlatformFeeMinor(subtotalMinor);
      const [created] = await tx.insert(paymentOrdersTable).values({
        buyerUserId: userId,
        sellerUserId: listing.sellerUserId,
        provider: "stripe",
        kind: "market_purchase",
        referenceId: productId,
        description: listing.name,
        amountMinor,
        subtotalMinor,
        taxMinor,
        taxRateBps,
        taxRegion,
        currency: CURRENCY,
        idempotencyKey,
        metadata: {
          productId,
          idempotencyKey,
          recipientAccountId: recipient.providerAccountId,
          subtotalMinor: String(subtotalMinor),
          taxMinor: String(taxMinor),
          taxRateBps: String(taxRateBps),
          taxRegion,
          platformFeeMinor: String(platformFeeMinor),
        },
      }).onConflictDoNothing({ target: [paymentOrdersTable.buyerUserId, paymentOrdersTable.idempotencyKey] }).returning();
      if (!created) return null;
      await tx.update(marketPaymentInventoryTable).set({
        availableQuantity: inventory.availableQuantity - 1,
        updatedAt: new Date(),
      }).where(eq(marketPaymentInventoryTable.productId, productId));
      await tx.insert(paymentReservationsTable).values({ orderId: created.id, productId });
      return {
        order: created,
        productName: listing.name,
        recipientAccountId: recipient.providerAccountId,
        subtotalMinor,
        taxMinor,
        amountMinor,
        taxRateBps,
      };
    });
    if (createdContext) {
      order = createdContext.order;
      checkoutContext = createdContext;
    } else {
      [order] = await db.select().from(paymentOrdersTable).where(
        and(eq(paymentOrdersTable.buyerUserId, userId), eq(paymentOrdersTable.idempotencyKey, idempotencyKey)),
      );
    }
  }
  if (!order) throw new Error("Could not create payment order");
  if (order.kind !== "market_purchase" || order.referenceId !== productId) {
    throw new Error("Idempotency key was already used for a different request");
  }
  if (order.taxRegion !== null && order.taxRegion !== taxRegion) {
    throw new Error("Idempotency key was already used for a different tax region");
  }
  if (order.status === "failed" || order.status === "canceled") {
    throw new Error("This payment attempt is closed; use a new idempotency key");
  }
  if (!checkoutContext) {
    const recipientAccountId = order.metadata.recipientAccountId;
    if (!recipientAccountId) throw new Error("Persisted order is missing its recipient binding");
    checkoutContext = {
      productName: order.description,
      recipientAccountId,
      subtotalMinor: order.subtotalMinor ?? order.amountMinor,
      taxMinor: order.taxMinor ?? 0,
      amountMinor: order.amountMinor,
      taxRateBps: order.taxRateBps ?? 0,
    };
  }
  try {
    const {
      amountMinor,
      productName,
      recipientAccountId,
      subtotalMinor,
      taxMinor,
      taxRateBps: checkoutTaxRateBps,
    } = checkoutContext;
    const priceId = await ensureStripePrice(productId, productName, amountMinor);
    const fields = new URLSearchParams({
    mode: "payment",
    "line_items[0][price]": priceId,
    "line_items[0][quantity]": "1",
    success_url: `${baseUrl}/payments?checkout=returned&order_id=${order.id}`,
    cancel_url: `${baseUrl}/market/${encodeURIComponent(productId)}?checkout=cancelled`,
    billing_address_collection: "auto",
    customer_creation: "always",
    client_reference_id: userId,
    "metadata[orderId]": String(order.id),
    "metadata[productId]": productId,
    "metadata[amountMinor]": String(amountMinor),
    "metadata[subtotalMinor]": String(subtotalMinor),
    "metadata[taxMinor]": String(taxMinor),
    "metadata[taxRateBps]": String(checkoutTaxRateBps),
    "metadata[taxRegion]": taxRegion,
    "metadata[currency]": CURRENCY,
    "metadata[recipientAccountId]": recipientAccountId,
    "payment_intent_data[metadata][orderId]": String(order.id),
    "payment_intent_data[metadata][recipientAccountId]": recipientAccountId,
    "payment_intent_data[metadata][subtotalMinor]": String(subtotalMinor),
    "payment_intent_data[metadata][taxMinor]": String(taxMinor),
    "payment_intent_data[metadata][taxRateBps]": String(checkoutTaxRateBps),
    "payment_intent_data[metadata][taxRegion]": taxRegion,
    "payment_intent_data[transfer_group]": `market_order_${order.id}`,
  });
    fields.set("payment_intent_data[application_fee_amount]", String(marketPlatformFeeMinor(subtotalMinor)));
    fields.set("payment_intent_data[transfer_data][destination]", recipientAccountId);
    const session = await requestStripe<{ id: string; url: string | null }>("/v1/checkout/sessions", {
      method: "POST",
      idempotencyKey: `market:${userId}:${idempotencyKey}`,
      body: fields,
    });
    if (!session.url) throw new Error("Payment provider did not return a checkout URL");
    await db.update(paymentOrdersTable).set({ providerCheckoutSessionId: session.id, status: "pending" }).where(eq(paymentOrdersTable.id, order.id));
    return { order: mapOrder({ ...order, providerCheckoutSessionId: session.id, status: "pending" }), url: session.url };
  } catch (error) {
    const definiteProviderRejection =
      error instanceof StripeProviderError &&
      error.status >= 400 &&
      error.status < 500 &&
      error.status !== 409 &&
      error.status !== 429;
    if (definiteProviderRejection) {
      await db.transaction(async (tx) => {
        const [released] = await tx.update(paymentReservationsTable).set({ status: "released", updatedAt: new Date() })
          .where(and(eq(paymentReservationsTable.orderId, order.id), eq(paymentReservationsTable.status, "reserved"))).returning();
        if (released) await tx.update(marketPaymentInventoryTable).set({
          availableQuantity: sql`${marketPaymentInventoryTable.availableQuantity} + ${released.quantity}`,
          updatedAt: new Date(),
        }).where(eq(marketPaymentInventoryTable.productId, released.productId));
        await tx.update(paymentOrdersTable).set({ status: "failed", updatedAt: new Date() }).where(eq(paymentOrdersTable.id, order.id));
      });
    } else {
      await db.update(paymentOrdersTable).set({ status: "pending", updatedAt: new Date() }).where(eq(paymentOrdersTable.id, order.id));
    }
    throw error;
  }
}

export async function listPaymentOrders(userId: string, cursor?: number, limit = 20) {
  const rows = await db.select().from(paymentOrdersTable).where(cursor
    ? and(eq(paymentOrdersTable.buyerUserId, userId), lt(paymentOrdersTable.id, cursor))
    : eq(paymentOrdersTable.buyerUserId, userId)).orderBy(desc(paymentOrdersTable.id)).limit(limit + 1);
  const hasMore = rows.length > limit;
  const items = rows.slice(0, limit);
  return { items: items.map(mapOrder), nextCursor: hasMore ? items[items.length - 1]?.id ?? null : null };
}

export async function getPaymentOrder(userId: string, orderId: number) {
  const [row] = await db.select().from(paymentOrdersTable).where(and(eq(paymentOrdersTable.id, orderId), eq(paymentOrdersTable.buyerUserId, userId)));
  return row ? mapOrder(row) : null;
}

export async function confirmPaymentOrder(userId: string, orderId: number) {
  const [row] = await db.select().from(paymentOrdersTable).where(and(eq(paymentOrdersTable.id, orderId), eq(paymentOrdersTable.buyerUserId, userId)));
  if (!row) return null;
  if (!row.providerCheckoutSessionId) return mapOrder(row);
  const session = await requestStripe<{
    id: string; payment_status: string; payment_intent: string | null;
    amount_total: number | null; currency: string | null; client_reference_id: string | null;
    metadata?: Record<string, string>;
  }>(`/v1/checkout/sessions/${encodeURIComponent(row.providerCheckoutSessionId)}`);
  const valid = session.id === row.providerCheckoutSessionId &&
    session.client_reference_id === userId &&
    session.amount_total === row.amountMinor &&
    session.currency?.toLowerCase() === row.currency &&
    session.metadata?.orderId === String(row.id) &&
    session.metadata?.productId === row.referenceId &&
    session.metadata?.recipientAccountId === row.metadata.recipientAccountId &&
    session.metadata?.amountMinor === String(row.amountMinor) &&
    session.metadata?.subtotalMinor === row.metadata.subtotalMinor &&
    session.metadata?.taxMinor === row.metadata.taxMinor &&
    session.metadata?.taxRateBps === row.metadata.taxRateBps &&
    session.metadata?.taxRegion === row.metadata.taxRegion;
  if (!valid) throw new Error("Provider payment details do not match this order");
  if (session.payment_status !== "paid") return mapOrder(row);
  const updated = await db.transaction((tx) => applyPaidMarketOrder(tx, session));
  return mapOrder(updated ?? row);
}

export async function requestPaymentRefund(userId: string, orderId: number, amountMinor: number, reason: string, idempotencyKey: string) {
  assertPaymentCapability("refunds");
  return db.transaction(async (tx) => {
    const [order] = await tx.select().from(paymentOrdersTable)
      .where(and(eq(paymentOrdersTable.id, orderId), eq(paymentOrdersTable.buyerUserId, userId))).for("update");
    if (!order || !order.providerPaymentIntentId) throw new Error("Paid order not found");
    const [old] = await tx.select().from(paymentRefundsTable).where(and(
      eq(paymentRefundsTable.requestedByUserId, userId),
      eq(paymentRefundsTable.idempotencyKey, idempotencyKey),
    ));
    if (old) {
      if (old.orderId !== orderId || old.amountMinor !== amountMinor || old.reason !== reason) {
        throw new Error("Idempotency key was already used for a different refund request");
      }
      return mapRefund(old);
    }
    const [reserved] = await tx.select({
      activeAmountMinor: sql<number>`coalesce(sum(${paymentRefundsTable.amountMinor}) filter (where ${paymentRefundsTable.status} in ('pending', 'approved', 'failed')), 0)`,
      completedAmountMinor: sql<number>`coalesce(sum(${paymentRefundsTable.amountMinor}) filter (where ${paymentRefundsTable.status} = 'completed'), 0)`,
    }).from(paymentRefundsTable).where(eq(paymentRefundsTable.orderId, orderId));
    const knownRefunded = Math.max(order.refundedAmountMinor, Number(reserved?.completedAmountMinor ?? 0));
    const refundableBalance = order.amountMinor - knownRefunded - Number(reserved?.activeAmountMinor ?? 0);
    if (amountMinor <= 0 || amountMinor > refundableBalance) throw new Error("Refund amount exceeds refundable balance");
    let [saved] = await tx.insert(paymentRefundsTable).values({
      orderId, requestedByUserId: userId, amountMinor, currency: order.currency,
      reason, status: "pending", idempotencyKey,
    }).onConflictDoNothing({
      target: [paymentRefundsTable.requestedByUserId, paymentRefundsTable.idempotencyKey],
    }).returning();
    if (!saved) {
      [saved] = await tx.select().from(paymentRefundsTable).where(and(
        eq(paymentRefundsTable.requestedByUserId, userId),
        eq(paymentRefundsTable.idempotencyKey, idempotencyKey),
      ));
      if (!saved || saved.orderId !== orderId || saved.amountMinor !== amountMinor || saved.reason !== reason) {
        throw new Error("Idempotency key was already used for a different refund request");
      }
    }
    return mapRefund(saved);
  });
}

export async function listPaymentRefunds(userId: string) {
  const rows = await db.select().from(paymentRefundsTable)
    .where(eq(paymentRefundsTable.requestedByUserId, userId))
    .orderBy(desc(paymentRefundsTable.id));
  return rows.map(mapRefund);
}

export async function listSupportPaymentRefunds(operatorUserId: string) {
  await assertSupportOperator(operatorUserId);
  const rows = await db.select({
    refund: paymentRefundsTable,
    order: paymentOrdersTable,
    fulfillmentStatus: paymentReservationsTable.status,
  }).from(paymentRefundsTable)
    .innerJoin(paymentOrdersTable, eq(paymentRefundsTable.orderId, paymentOrdersTable.id))
    .leftJoin(paymentReservationsTable, eq(paymentReservationsTable.orderId, paymentOrdersTable.id))
    .orderBy(desc(paymentRefundsTable.createdAt));
  return rows.map(({ refund, order, fulfillmentStatus }) => ({
    ...mapRefund(refund),
    reviewedByUserId: refund.reviewedByUserId,
    reviewedAt: refund.reviewedAt,
    canRetry: refund.status === "approved" || refund.status === "failed",
    order: mapOrder(order),
    fulfillmentStatus: (fulfillmentStatus ?? "unknown") as "reserved" | "fulfilled" | "released" | "unknown",
  }));
}

export async function decidePaymentRefund(
  operatorUserId: string,
  refundId: number,
  decision: "approve" | "deny",
  reason?: string,
) {
  await assertSupportOperator(operatorUserId);
  if (decision === "deny" && !reason?.trim()) throw new Error("A denial reason is required");
  const [context] = await db.select({
    refund: paymentRefundsTable,
    order: paymentOrdersTable,
    fulfillmentStatus: paymentReservationsTable.status,
  }).from(paymentRefundsTable)
    .innerJoin(paymentOrdersTable, eq(paymentRefundsTable.orderId, paymentOrdersTable.id))
    .leftJoin(paymentReservationsTable, eq(paymentReservationsTable.orderId, paymentOrdersTable.id))
    .where(eq(paymentRefundsTable.id, refundId));
  if (!context) return null;
  const retryingApproval = decision === "approve" && ["approved", "failed"].includes(context.refund.status);
  if (context.refund.status !== "pending" && !retryingApproval) throw new Error("Refund request was already reviewed");

  if (decision === "deny") {
    const [denied] = await db.update(paymentRefundsTable).set({
      status: "denied",
      reviewedByUserId: operatorUserId,
      reviewedAt: new Date(),
      denialReason: reason!.trim(),
      updatedAt: new Date(),
    }).where(and(eq(paymentRefundsTable.id, refundId), eq(paymentRefundsTable.status, "pending"))).returning();
    if (!denied) throw new Error("Refund request was already reviewed");
    return {
      ...mapRefund(denied),
      reviewedByUserId: denied.reviewedByUserId,
      reviewedAt: denied.reviewedAt,
      canRetry: false,
      order: mapOrder(context.order),
      fulfillmentStatus: (context.fulfillmentStatus ?? "unknown") as "reserved" | "fulfilled" | "released" | "unknown",
    };
  }

  if (!context.order.providerPaymentIntentId) throw new Error("Paid order not found");
  let approved = context.refund;
  if (!retryingApproval) {
    [approved] = await db.update(paymentRefundsTable).set({
      status: "approved",
      reviewedByUserId: operatorUserId,
      reviewedAt: new Date(),
      denialReason: null,
      updatedAt: new Date(),
    }).where(and(eq(paymentRefundsTable.id, refundId), eq(paymentRefundsTable.status, "pending"))).returning();
    if (!approved) throw new Error("Refund request was already reviewed");
  } else if (approved.status === "failed") {
    const [transitioned] = await db.update(paymentRefundsTable).set({ status: "approved", updatedAt: new Date() })
      .where(and(eq(paymentRefundsTable.id, refundId), eq(paymentRefundsTable.status, "failed"))).returning();
    if (transitioned) {
      approved = transitioned;
    } else {
      const [current] = await db.select().from(paymentRefundsTable).where(eq(paymentRefundsTable.id, refundId));
      if (!current) return null;
      if (current.status === "completed" || current.status === "denied") {
        return {
          ...mapRefund(current),
          reviewedByUserId: current.reviewedByUserId,
          reviewedAt: current.reviewedAt,
          canRetry: false,
          order: mapOrder(context.order),
          fulfillmentStatus: (context.fulfillmentStatus ?? "unknown") as "reserved" | "fulfilled" | "released" | "unknown",
        };
      }
      if (current.status !== "approved") throw new Error("Refund request was already reviewed");
      approved = current;
    }
  }

  try {
    const providerRefund = await requestStripe<{ id: string }>("/v1/refunds", {
      method: "POST",
      idempotencyKey: `refund-request:${refundId}`,
      body: new URLSearchParams({
        payment_intent: context.order.providerPaymentIntentId,
        amount: String(approved.amountMinor),
        reverse_transfer: "true",
        refund_application_fee: "true",
        "metadata[refundRequestId]": String(refundId),
        "metadata[orderId]": String(context.order.id),
      }),
    });
    const [saved] = await db.update(paymentRefundsTable).set({
      providerRefundId: providerRefund.id,
      updatedAt: new Date(),
    }).where(eq(paymentRefundsTable.id, refundId)).returning();
    return {
      ...mapRefund(saved ?? approved),
      reviewedByUserId: (saved ?? approved).reviewedByUserId,
      reviewedAt: (saved ?? approved).reviewedAt,
      canRetry: true,
      order: mapOrder(context.order),
      fulfillmentStatus: (context.fulfillmentStatus ?? "unknown") as "reserved" | "fulfilled" | "released" | "unknown",
    };
  } catch (error) {
    const definiteProviderRejection = error instanceof StripeProviderError &&
      error.status >= 400 && error.status < 500 && error.status !== 409 && error.status !== 429;
    if (definiteProviderRejection) {
      await db.update(paymentRefundsTable).set({ status: "failed", updatedAt: new Date() })
        .where(and(eq(paymentRefundsTable.id, refundId), eq(paymentRefundsTable.status, "approved")));
    }
    throw error;
  }
}

export async function getConnectedAccount(userId: string) {
  const [row] = await db.select().from(connectedPaymentAccountsTable).where(eq(connectedPaymentAccountsTable.userId, userId));
  if (!row) return { exists: false, provider: "stripe" as const, country: null, defaultCurrency: null, status: "not_started" as const, detailsSubmitted: false, chargesEnabled: false, payoutsEnabled: false, requirements: [] };
  return { exists: true, provider: "stripe" as const, country: row.country, defaultCurrency: row.defaultCurrency, status: row.status as "not_started" | "restricted" | "pending" | "enabled", detailsSubmitted: row.detailsSubmitted, chargesEnabled: row.chargesEnabled, payoutsEnabled: row.payoutsEnabled, requirements: row.requirements };
}

export async function createConnectedAccount(userId: string, country: string) {
  assertPaymentCapability("recipientOnboarding");
  const current = await getConnectedAccount(userId);
  if (!current.exists) {
    const account = await requestStripe<{ id: string }>("/v1/accounts", { method: "POST", idempotencyKey: `connect:${userId}`, body: new URLSearchParams({ type: "express", country: country.toUpperCase(), "capabilities[card_payments][requested]": "true", "capabilities[transfers][requested]": "true", "metadata[userId]": userId }) });
    await db.insert(connectedPaymentAccountsTable).values({ userId, providerAccountId: account.id, country: country.toUpperCase(), status: "restricted" });
  }
  return getConnectedAccount(userId);
}

export async function onboardingLink(userId: string, baseUrl: string) {
  assertPaymentCapability("recipientOnboarding");
  const [account] = await db.select().from(connectedPaymentAccountsTable).where(eq(connectedPaymentAccountsTable.userId, userId));
  if (!account) throw new Error("Connected account has not been created");
  const link = await requestStripe<{ url: string; expires_at: number }>("/v1/account_links", { method: "POST", idempotencyKey: `connect-link:${userId}:${Math.floor(Date.now() / 60000)}`, body: new URLSearchParams({ account: account.providerAccountId, type: "account_onboarding", refresh_url: `${baseUrl}/payments?connect=refresh`, return_url: `${baseUrl}/payments?connect=returned` }) });
  return { url: link.url, expiresAt: new Date(link.expires_at * 1000) };
}

export async function refreshConnectedAccount(userId: string) {
  const [account] = await db.select().from(connectedPaymentAccountsTable).where(eq(connectedPaymentAccountsTable.userId, userId));
  if (!account) return getConnectedAccount(userId);
  const remote = await requestStripe<{ country: string | null; default_currency: string | null; details_submitted: boolean; charges_enabled: boolean; payouts_enabled: boolean; requirements?: { currently_due?: string[] } }>(`/v1/accounts/${account.providerAccountId}`);
  const status = remote.charges_enabled && remote.payouts_enabled ? "enabled" : remote.details_submitted ? "pending" : "restricted";
  await db.update(connectedPaymentAccountsTable).set({ country: remote.country, defaultCurrency: remote.default_currency, detailsSubmitted: remote.details_submitted, chargesEnabled: remote.charges_enabled, payoutsEnabled: remote.payouts_enabled, status, requirements: remote.requirements?.currently_due ?? [], updatedAt: new Date() }).where(eq(connectedPaymentAccountsTable.userId, userId));
  return getConnectedAccount(userId);
}

export async function listPayouts(userId: string) {
  const [account] = await db.select().from(connectedPaymentAccountsTable).where(eq(connectedPaymentAccountsTable.userId, userId));
  if (!account) return [];
  type StripePayout = { id: string; amount: number; currency: string; status: string; arrival_date: number | null; failure_code: string | null; created: number };
  const payouts: StripePayout[] = [];
  let payoutCursor: string | undefined;
  do {
    const query = new URLSearchParams({ limit: "100" });
    if (payoutCursor) query.set("starting_after", payoutCursor);
    const page = await requestStripe<{ data: StripePayout[]; has_more: boolean }>(`/v1/payouts?${query}`, {
      connectedAccountId: account.providerAccountId,
    });
    payouts.push(...page.data);
    if (page.has_more && !page.data.at(-1)?.id) throw new Error("Payment provider returned an invalid payout page");
    payoutCursor = page.has_more ? page.data.at(-1)?.id : undefined;
  } while (payoutCursor);
  const results = [];
  for (let offset = 0; offset < payouts.length; offset += 5) {
    const batch = await Promise.all(payouts.slice(offset, offset + 5).map(async (payout) => {
      const balanceTransactions: Array<{ source: string | { id?: string } | null }> = [];
      let transactionCursor: string | undefined;
      do {
        const query = new URLSearchParams({ limit: "100", payout: payout.id });
        if (transactionCursor) query.set("starting_after", transactionCursor);
        const page = await requestStripe<{
          data: Array<{ id: string; source: string | { id?: string } | null }>;
          has_more: boolean;
        }>(`/v1/balance_transactions?${query}`, {
          connectedAccountId: account.providerAccountId,
        });
        balanceTransactions.push(...page.data);
        if (page.has_more && !page.data.at(-1)?.id) throw new Error("Payment provider returned an invalid balance transaction page");
        transactionCursor = page.has_more ? page.data.at(-1)?.id : undefined;
      } while (transactionCursor);
      const transferIds = balanceTransactions.flatMap((transaction) => {
        const sourceId = typeof transaction.source === "string" ? transaction.source : transaction.source?.id;
        return sourceId?.startsWith("tr_") ? [sourceId] : [];
      });
      const sales = transferIds.length === 0 ? [] : await db
        .select({
          orderId: paymentOrdersTable.id,
          listingId: paymentOrdersTable.referenceId,
          listingName: paymentOrdersTable.description,
          grossAmountMinor: paymentOrdersTable.amountMinor,
          subtotalMinor: paymentOrdersTable.subtotalMinor,
          metadata: paymentOrdersTable.metadata,
          currency: paymentTransfersTable.currency,
          status: paymentOrdersTable.status,
          createdAt: paymentOrdersTable.createdAt,
        })
        .from(paymentTransfersTable)
        .innerJoin(paymentOrdersTable, and(
          eq(paymentTransfersTable.orderId, paymentOrdersTable.id),
          eq(paymentOrdersTable.sellerUserId, userId),
        ))
        .where(and(
          eq(paymentTransfersTable.userId, userId),
          eq(paymentOrdersTable.kind, "market_purchase"),
          inArray(paymentTransfersTable.providerTransferId, transferIds),
        ))
        .orderBy(desc(paymentOrdersTable.createdAt));
      return {
        id: payout.id,
        amountMinor: payout.amount,
        currency: payout.currency.toLowerCase(),
        status: payout.status as "pending" | "in_transit" | "paid" | "failed" | "canceled",
        arrivalAt: payout.arrival_date ? new Date(payout.arrival_date * 1000) : null,
        failureCode: payout.failure_code,
        createdAt: new Date(payout.created * 1000),
        reconciliationStatus: "complete" as const,
        sales: sales.map((sale) => {
          const platformFeeMinor = persistedMarketPlatformFeeMinor(sale);
          return {
            orderId: sale.orderId,
            listingId: sale.listingId,
            listingName: sale.listingName,
            grossAmountMinor: sale.grossAmountMinor,
            platformFeeMinor,
            transferAmountMinor: sale.grossAmountMinor - platformFeeMinor,
            currency: sale.currency.toLowerCase(),
            status: sale.status as "created" | "pending" | "requires_action" | "succeeded" | "failed" | "canceled" | "partially_refunded" | "refunded" | "disputed",
            createdAt: sale.createdAt,
          };
        }),
      };
    }));
    results.push(...batch);
  }
  return results;
}