import { ReplitConnectors } from "@replit/connectors-sdk";

const connectors = new ReplitConnectors();
const STRIPE_API_VERSION = "2025-02-24.acacia";
const TRANSIENT_STATUSES = new Set([409, 429, 500, 502, 503, 504]);

export class StripeProviderError extends Error {
  constructor(
    message: string,
    readonly status: number,
    readonly code?: string,
  ) {
    super(message);
    this.name = "StripeProviderError";
  }
}

export async function stripeRequest<T>(
  path: string,
  options: {
    method?: string;
    body?: URLSearchParams;
    idempotencyKey?: string;
    connectedAccountId?: string;
    timeoutMs?: number;
  } = {},
): Promise<T> {
  const headers: Record<string, string> = {
    "Stripe-Version": STRIPE_API_VERSION,
  };
  if (options.body) {
    headers["Content-Type"] = "application/x-www-form-urlencoded";
  }
  if (options.idempotencyKey) {
    headers["Idempotency-Key"] = options.idempotencyKey;
  }
  if (options.connectedAccountId) {
    headers["Stripe-Account"] = options.connectedAccountId;
  }
  const method = options.method ?? "GET";
  const maxAttempts = method === "GET" || options.idempotencyKey ? 2 : 1;
  let lastError: unknown;
  for (let attempt = 1; attempt <= maxAttempts; attempt += 1) {
    try {
      const response = await Promise.race([
        connectors.proxy("stripe", path, { method, body: options.body, headers }),
        new Promise<never>((_, reject) =>
          setTimeout(
            () => reject(new StripeProviderError("Stripe request timed out", 504, "timeout")),
            options.timeoutMs ?? 20_000,
          ),
        ),
      ]);
      const data = (await response.json()) as T & {
        error?: { message?: string; code?: string };
      };
      if (!response.ok) {
        throw new StripeProviderError(
          data.error?.message ?? `Stripe request failed (${response.status})`,
          response.status,
          data.error?.code,
        );
      }
      return data;
    } catch (error) {
      lastError = error;
      const status = error instanceof StripeProviderError ? error.status : 503;
      if (attempt >= maxAttempts || !TRANSIENT_STATUSES.has(status)) throw error;
      await new Promise((resolve) => setTimeout(resolve, 250 * attempt));
    }
  }
  throw lastError;
}