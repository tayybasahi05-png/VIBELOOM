import { Router, type IRouter, type Request } from "express";
import {
  CreateProductBody,
  CreateProductParams,
  CreateProductResponse,
  CreateConversationBody,
  CreateConversationResponse,
  GetDiscoverResponse,
  GetFeedResponse,
  GetMemberParams,
  GetMemberResponse,
  GetProductParams,
  GetProductResponse,
  GetSessionResponse,
  LikePostParams,
  LikePostResponse,
  ListConversationsResponse,
  ListMessagesParams,
  ListMessagesResponse,
  ListNotificationsResponse,
  ListOpportunitiesResponse,
  ListProductsResponse,
  ListSellerProductsResponse,
  SavePostParams,
  SavePostResponse,
  SearchQueryParams,
  SearchResponse,
  SendMessageBody,
  SendMessageParams,
  SendMessageResponse,
  ToggleWishlistParams,
  ToggleWishlistResponse,
  UpdateProductBody,
  UpdateProductParams,
  UpdateProductResponse,
} from "@workspace/api-zod";
import {
  opportunities,
  posts,
  productDetails,
  getProductDetail,
  createPersistedProduct,
  getPersistedProduct,
  listPersistedProducts,
  listSellerPersistedProducts,
  products,
  session,
  updatePersistedProduct,
} from "../lib/platform-data";
import {
  createOrGetDirectConversation,
  getInboxPerson,
  listInboxConversations,
  listInboxNotifications,
  listInboxMessages,
  sendInboxMessage,
  searchInboxPeople,
  syncInboxUser,
} from "../lib/inbox-service";
import {
  getRequestAuth,
  requireAuthenticatedRequest,
} from "../middlewares/requireAuthenticatedRequest";

const router: IRouter = Router();

function currentPerson(req: Request) {
  const auth = getRequestAuth(req);
  const claims = (auth.sessionClaims ?? {}) as Record<string, unknown>;
  const firstName =
    typeof claims.firstName === "string"
      ? claims.firstName
      : typeof claims.first_name === "string"
        ? claims.first_name
        : "";
  const lastName =
    typeof claims.lastName === "string"
      ? claims.lastName
      : typeof claims.last_name === "string"
        ? claims.last_name
        : "";
  const username =
    typeof claims.username === "string" && claims.username
      ? claims.username
      : `member-${auth.userId?.slice(-8)}`;
  const avatarUrl =
    typeof claims.imageUrl === "string"
      ? claims.imageUrl
      : typeof claims.image_url === "string"
        ? claims.image_url
        : "";
  return {
    id: auth.userId ?? "",
    name: `${firstName} ${lastName}`.trim() || "Member",
    handle: username.startsWith("@") ? username : `@${username}`,
    avatarUrl,
    location: "",
    verified: false,
    role: "freelancer" as const,
  };
}

router.get("/session", requireAuthenticatedRequest, (req, res) => {
  res.json(
    GetSessionResponse.parse({
      ...session,
      user: currentPerson(req),
      coinBalance: 0,
    }),
  );
});

router.get("/feed", (_req, res) => {
  res.json(GetFeedResponse.parse({ items: posts, nextCursor: null }));
});

router.post("/posts/:postId/like", requireAuthenticatedRequest, (req, res) => {
  const parsed = LikePostParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const post = posts.find((item) => item.id === parsed.data.postId);
  if (!post) {
    res.status(404).json({ error: "Post not found" });
    return;
  }
  post.liked = !post.liked;
  post.likes += post.liked ? 1 : -1;
  res.json(LikePostResponse.parse({ active: post.liked, count: post.likes }));
});

router.post("/posts/:postId/save", requireAuthenticatedRequest, (req, res) => {
  const parsed = SavePostParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const post = posts.find((item) => item.id === parsed.data.postId);
  if (!post) {
    res.status(404).json({ error: "Post not found" });
    return;
  }
  post.saved = !post.saved;
  res.json(SavePostResponse.parse({ active: post.saved, count: 0 }));
});

router.get("/discover", (_req, res) => {
  res.json(
    GetDiscoverResponse.parse({
      trending: posts.slice(0, 2),
      creators: posts.map((post) => post.author),
      people: posts.map((post) => post.author),
      categories: ["Creators", "Business", "Freelancing", "Style", "Travel"],
    }),
  );
});

router.get("/search", async (req, res): Promise<void> => {
  const parsed = SearchQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const query = parsed.data.q.toLowerCase();
  const peopleResults = await searchInboxPeople(query);
  const results = [
    ...products.map((product) => ({
      id: product.id,
      kind: "product" as const,
      title: product.name,
      subtitle: `${product.currency} ${product.price}`,
      imageUrl: product.imageUrl,
      meta: product.location,
    })),
    ...peopleResults.map((person) => ({
      id: person.id,
      kind: "person" as const,
      title: person.name,
      subtitle: person.handle,
      imageUrl: person.avatarUrl,
      meta: person.location,
    })),
  ].filter((item) =>
    `${item.title} ${item.subtitle} ${item.meta}`.toLowerCase().includes(query),
  );
  res.json(SearchResponse.parse({ results, total: results.length }));
});

router.get("/members/:userId", requireAuthenticatedRequest, async (req, res): Promise<void> => {
  const params = GetMemberParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const person = currentPerson(req);
  await syncInboxUser({ ...person, role: person.role });
  const member = await getInboxPerson(params.data.userId);
  if (!member) {
    res.status(404).json({ error: "Member not found" });
    return;
  }
  res.json(GetMemberResponse.parse(member));
});

router.get("/market/products", async (_req, res) => {
  res.json(ListProductsResponse.parse(await listPersistedProducts()));
});

router.get("/market/seller/products", requireAuthenticatedRequest, async (req, res): Promise<void> => {
  const person = currentPerson(req);
  await syncInboxUser({ ...person, role: person.role });
  res.json(ListSellerProductsResponse.parse(await listSellerPersistedProducts(person.id)));
});

router.get("/market/products/:productId", async (req, res) => {
  const parsed = GetProductParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const product = await getPersistedProduct(parsed.data.productId);
  if (!product) {
    res.status(404).json({ error: "Product not found" });
    return;
  }
  res.json(GetProductResponse.parse(product));
});

router.post("/market/products/:productId", requireAuthenticatedRequest, async (req, res) => {
  const params = CreateProductParams.safeParse(req.params);
  const body = CreateProductBody.safeParse(req.body);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  try {
    const person = currentPerson(req);
    await syncInboxUser({ ...person, role: person.role });
    const product = await createPersistedProduct(person.id, params.data.productId, body.data);
    res.status(201).json(CreateProductResponse.parse(product));
  } catch (error) {
    const message = error instanceof Error ? error.message : "Could not publish listing";
    res.status(message.includes("verification") ? 409 : 400).json({ error: message });
  }
});

router.patch("/market/products/:productId", requireAuthenticatedRequest, async (req, res): Promise<void> => {
  const params = UpdateProductParams.safeParse(req.params);
  const body = UpdateProductBody.safeParse(req.body);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  if (Object.keys(body.data).length === 0) {
    res.status(400).json({ error: "At least one listing field is required" });
    return;
  }
  try {
    const person = currentPerson(req);
    const product = await updatePersistedProduct(person.id, params.data.productId, body.data);
    if (!product) {
      res.status(404).json({ error: "Product not found" });
      return;
    }
    res.json(UpdateProductResponse.parse(product));
  } catch (error) {
    const message = error instanceof Error ? error.message : "Could not update listing";
    res.status(
      message.includes("verification") || message.includes("Inventory changed") ? 409 : 400,
    ).json({ error: message });
  }
});

router.post("/market/products/:productId/wishlist", requireAuthenticatedRequest, async (req, res) => {
  const parsed = ToggleWishlistParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const exists = Boolean(await getPersistedProduct(parsed.data.productId));
  if (!exists) {
    res.status(404).json({ error: "Product not found" });
    return;
  }
  res.json(ToggleWishlistResponse.parse({ active: true, count: 1 }));
});

router.use("/inbox", requireAuthenticatedRequest);

router.get("/inbox/conversations", async (req, res): Promise<void> => {
  const person = currentPerson(req);
  await syncInboxUser({ ...person, role: person.role });
  const conversations = await listInboxConversations(person.id);
  res.json(ListConversationsResponse.parse(conversations));
});

router.post("/inbox/conversations", async (req, res): Promise<void> => {
  const body = CreateConversationBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const person = currentPerson(req);
  await syncInboxUser({ ...person, role: person.role });
  const result = await createOrGetDirectConversation(person.id, body.data.participantId);
  if (result.status === "invalid") {
    res.status(400).json({ error: "You cannot start a conversation with yourself" });
    return;
  }
  if (result.status === "not_found") {
    res.status(404).json({ error: "Participant not found" });
    return;
  }
  res
    .status(result.status === "created" ? 201 : 200)
    .json(CreateConversationResponse.parse(result.conversation));
});

router.get("/inbox/conversations/:conversationId/messages", async (req, res): Promise<void> => {
  const parsed = ListMessagesParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const userId = getRequestAuth(req).userId!;
  const person = currentPerson(req);
  await syncInboxUser({ ...person, role: person.role });
  const messages = await listInboxMessages(parsed.data.conversationId, userId);
  if (!messages) {
    res.status(404).json({ error: "Conversation not found" });
    return;
  }
  res.json(ListMessagesResponse.parse(messages));
});

router.post("/inbox/conversations/:conversationId/messages", async (req, res): Promise<void> => {
  const params = SendMessageParams.safeParse(req.params);
  const body = SendMessageBody.safeParse(req.body);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const userId = getRequestAuth(req).userId!;
  const person = currentPerson(req);
  await syncInboxUser({ ...person, role: person.role });
  const message = await sendInboxMessage(
    params.data.conversationId,
    userId,
    body.data.body,
  );
  if (!message) {
    res.status(404).json({ error: "Conversation not found" });
    return;
  }
  res.status(201).json(SendMessageResponse.parse(message));
});

router.get("/notifications", requireAuthenticatedRequest, async (req, res): Promise<void> => {
  const person = currentPerson(req);
  await syncInboxUser({ ...person, role: person.role });
  res.json(ListNotificationsResponse.parse(await listInboxNotifications(person.id)));
});

router.get("/opportunities", (_req, res) => {
  res.json(ListOpportunitiesResponse.parse(opportunities));
});

export default router;
