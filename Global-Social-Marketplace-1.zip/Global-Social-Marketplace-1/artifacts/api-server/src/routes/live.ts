import { Router, type IRouter } from "express";
import {
  GetLiveRoomParams,
  GetLiveRoomResponse,
  ListGiftsResponse,
  ListLiveRoomsResponse,
  SendGiftBody,
  SendGiftParams,
  SendGiftResponse,
} from "@workspace/api-zod";
import {
  ensureAuthenticatedUser,
  getRoom,
  listGifts,
  listRooms,
  sendGift,
} from "../lib/live-service";
import { requireAuthenticatedRequest } from "../middlewares/requireAuthenticatedRequest";

const router: IRouter = Router();

router.get("/live/rooms", async (_req, res): Promise<void> => {
  const rooms = await listRooms();
  res.json(ListLiveRoomsResponse.parse(rooms));
});

router.get("/live/rooms/:roomId", async (req, res): Promise<void> => {
  const params = GetLiveRoomParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const room = await getRoom(params.data.roomId);
  if (!room) {
    res.status(404).json({ error: "Live room not found" });
    return;
  }
  res.json(GetLiveRoomResponse.parse(room));
});

router.get("/live/gifts", async (_req, res): Promise<void> => {
  const gifts = await listGifts();
  res.json(ListGiftsResponse.parse(gifts));
});

router.post(
  "/live/rooms/:roomId/gifts",
  requireAuthenticatedRequest,
  async (req, res): Promise<void> => {
    const params = SendGiftParams.safeParse(req.params);
    const body = SendGiftBody.safeParse(req.body);
    const idempotencyKey = req.header("Idempotency-Key");
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    if (!body.success) {
      res.status(400).json({ error: body.error.message });
      return;
    }
    if (!idempotencyKey) {
      res.status(400).json({ error: "Idempotency-Key header is required" });
      return;
    }
    try {
      const senderUserId = await ensureAuthenticatedUser(req);
      const transfer = await sendGift(
        params.data.roomId,
        senderUserId,
        body.data.giftId,
        body.data.quantity ?? 1,
        idempotencyKey,
      );
      res.status(201).json(
        SendGiftResponse.parse({
          ...transfer,
          id: String(transfer.id),
          createdAt: transfer.createdAt.toISOString(),
        }),
      );
    } catch (error) {
      const code = error instanceof Error && "code" in error ? error.code : undefined;
      const message = error instanceof Error ? error.message : "Unable to send gift";
      const status =
        code === "ROOM_NOT_FOUND" || code === "GIFT_NOT_FOUND"
          ? 404
          : code === "IDEMPOTENCY_CONFLICT"
            ? 409
            : code === "SELF_GIFT" || code === "INSUFFICIENT_BALANCE"
              ? 400
              : 500;
      res.status(status).json({ error: message });
    }
  },
);

export default router;