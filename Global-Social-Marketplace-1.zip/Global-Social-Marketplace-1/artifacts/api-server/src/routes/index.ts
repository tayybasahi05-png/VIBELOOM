import { Router, type IRouter } from "express";
import healthRouter from "./health";
import platformRouter from "./platform";
import liveRouter from "./live";
import walletRouter from "./wallet";
import appAiRouter from "./app-ai";
import paymentsRouter from "./payments";
import storiesRouter from "./stories";

const router: IRouter = Router();

router.use(healthRouter);
router.use(platformRouter);
router.use(liveRouter);
router.use(walletRouter);
router.use(appAiRouter);
router.use(paymentsRouter);
router.use(storiesRouter);

export default router;
