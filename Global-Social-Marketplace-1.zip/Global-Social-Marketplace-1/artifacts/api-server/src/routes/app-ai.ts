import { Router, type IRouter } from "express";
import { and, asc, desc, eq } from "drizzle-orm";
import {
  appAiConversationsTable,
  appAiMessagesTable,
  db,
  supportTicketsTable,
} from "@workspace/db";
import {
  CreateAppAiConversationBody,
  CreateAppAiConversationResponse,
  CreateAppAiSupportTicketBody,
  CreateAppAiSupportTicketResponse,
  GetAppAiConversationParams,
  GetAppAiConversationResponse,
  ListAppAiConversationsResponse,
  RateAppAiMessageBody,
  RateAppAiMessageParams,
  RateAppAiMessageResponse,
  ReportAppAiMessageBody,
  ReportAppAiMessageParams,
  ReportAppAiMessageResponse,
  SendAppAiMessageBody,
  SendAppAiMessageParams,
  SendAppAiMessageResponse,
} from "@workspace/api-zod";
import { openai } from "@workspace/integrations-openai-ai-server";
import { ensureAuthenticatedUser } from "../lib/live-service";
import { APP_AI_SYSTEM_PROMPT } from "../lib/app-ai-knowledge";
import { requireAuthenticatedRequest } from "../middlewares/requireAuthenticatedRequest";

const router: IRouter = Router();
const requestWindows = new Map<string, number[]>();
const APP_AI_RATE_LIMIT = 12;
const APP_AI_RATE_WINDOW_MS = 60_000;

function withinRateLimit(userId: string) {
  const now = Date.now();
  const recent = (requestWindows.get(userId) ?? []).filter(
    (startedAt) => now - startedAt < APP_AI_RATE_WINDOW_MS,
  );
  if (recent.length >= APP_AI_RATE_LIMIT) {
    requestWindows.set(userId, recent);
    return false;
  }
  recent.push(now);
  requestWindows.set(userId, recent);
  return true;
}

function aiErrorStatus(error: unknown) {
  if (!error || typeof error !== "object") return 503;
  const candidate = error as { status?: number; code?: string; name?: string };
  if (candidate.status === 429) return 429;
  if (
    candidate.status === 408 ||
    candidate.code === "ETIMEDOUT" ||
    candidate.name === "APIConnectionTimeoutError"
  ) {
    return 504;
  }
  return 503;
}

function conversationJson(row: typeof appAiConversationsTable.$inferSelect) {
  return {
    id: row.id,
    title: row.title,
    createdAt: row.createdAt,
    updatedAt: row.updatedAt,
  };
}

function messageJson(row: typeof appAiMessagesTable.$inferSelect) {
  return {
    id: row.id,
    conversationId: row.conversationId,
    role: row.role as "user" | "assistant",
    content: row.content,
    helpful: row.helpful,
    createdAt: row.createdAt,
  };
}

router.use("/app-ai", requireAuthenticatedRequest);

router.get("/app-ai/conversations", async (req, res): Promise<void> => {
  const userId = await ensureAuthenticatedUser(req);
  const rows = await db
    .select()
    .from(appAiConversationsTable)
    .where(eq(appAiConversationsTable.userId, userId))
    .orderBy(desc(appAiConversationsTable.updatedAt));
  res.json(ListAppAiConversationsResponse.parse(rows.map(conversationJson)));
});

router.post("/app-ai/conversations", async (req, res): Promise<void> => {
  const body = CreateAppAiConversationBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const userId = await ensureAuthenticatedUser(req);
  const [created] = await db
    .insert(appAiConversationsTable)
    .values({ userId, title: body.data.title })
    .returning();
  res.status(201).json(CreateAppAiConversationResponse.parse(conversationJson(created)));
});

router.get("/app-ai/conversations/:conversationId", async (req, res): Promise<void> => {
  const params = GetAppAiConversationParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const userId = await ensureAuthenticatedUser(req);
  const [conversation] = await db
    .select()
    .from(appAiConversationsTable)
    .where(
      and(
        eq(appAiConversationsTable.id, params.data.conversationId),
        eq(appAiConversationsTable.userId, userId),
      ),
    )
    .limit(1);
  if (!conversation) {
    res.status(404).json({ error: "APP AI conversation not found" });
    return;
  }
  const messages = await db
    .select()
    .from(appAiMessagesTable)
    .where(eq(appAiMessagesTable.conversationId, conversation.id))
    .orderBy(asc(appAiMessagesTable.createdAt), asc(appAiMessagesTable.id));
  res.json(
    GetAppAiConversationResponse.parse({
      ...conversationJson(conversation),
      messages: messages.map(messageJson),
    }),
  );
});

router.delete("/app-ai/conversations/:conversationId", async (req, res): Promise<void> => {
  const params = GetAppAiConversationParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const userId = await ensureAuthenticatedUser(req);
  const deleted = await db
    .delete(appAiConversationsTable)
    .where(
      and(
        eq(appAiConversationsTable.id, params.data.conversationId),
        eq(appAiConversationsTable.userId, userId),
      ),
    )
    .returning({ id: appAiConversationsTable.id });
  if (deleted.length === 0) {
    res.status(404).json({ error: "APP AI conversation not found" });
    return;
  }
  res.status(204).send();
});

router.post("/app-ai/conversations/:conversationId/messages", async (req, res): Promise<void> => {
  const params = SendAppAiMessageParams.safeParse(req.params);
  const body = SendAppAiMessageBody.safeParse(req.body);
  if (!params.success || !body.success) {
    res.status(400).json({ error: "Invalid APP AI message" });
    return;
  }
  const userId = await ensureAuthenticatedUser(req);
  if (!withinRateLimit(userId)) {
    res.setHeader("Retry-After", "60");
    res.status(429).json({ error: "Too many APP AI requests. Please wait a minute and retry." });
    return;
  }
  const [conversation] = await db
    .select()
    .from(appAiConversationsTable)
    .where(
      and(
        eq(appAiConversationsTable.id, params.data.conversationId),
        eq(appAiConversationsTable.userId, userId),
      ),
    )
    .limit(1);
  if (!conversation) {
    res.status(404).json({ error: "APP AI conversation not found" });
    return;
  }
  const history = await db
    .select()
    .from(appAiMessagesTable)
    .where(eq(appAiMessagesTable.conversationId, conversation.id))
    .orderBy(desc(appAiMessagesTable.createdAt), desc(appAiMessagesTable.id))
    .limit(16);
  try {
    const completion = await openai.chat.completions.create(
      {
        model: "gpt-5.6-luna",
        max_completion_tokens: 1200,
        messages: [
          { role: "system", content: APP_AI_SYSTEM_PROMPT },
          ...history.reverse().map((message) => ({
            role: message.role as "user" | "assistant",
            content: message.content,
          })),
          { role: "user", content: body.data.content },
        ],
      },
      { timeout: 30_000, maxRetries: 1 },
    );
    const answer = completion.choices[0]?.message.content?.trim();
    if (!answer) throw new Error("APP AI returned an empty answer");
    const [, assistantMessage] = await db.transaction(async (tx) => {
      const inserted = await tx
        .insert(appAiMessagesTable)
        .values([
          { conversationId: conversation.id, role: "user", content: body.data.content },
          { conversationId: conversation.id, role: "assistant", content: answer },
        ])
        .returning();
      await tx
        .update(appAiConversationsTable)
        .set({
          updatedAt: new Date(),
          ...(history.length === 0
            ? { title: body.data.content.trim().slice(0, 72) }
            : {}),
        })
        .where(eq(appAiConversationsTable.id, conversation.id));
      return inserted;
    });
    res.status(201).json(SendAppAiMessageResponse.parse(messageJson(assistantMessage)));
  } catch (error) {
    req.log.error({ err: error }, "APP AI response failed");
    const status = aiErrorStatus(error);
    const message =
      status === 429
        ? "APP AI is receiving too many requests. Please wait a minute and retry."
        : status === 504
          ? "APP AI took too long to respond. Please retry."
          : "APP AI is temporarily unavailable. Please try again.";
    res.status(status).json({ error: message });
  }
});

router.post("/app-ai/messages/:messageId/report", async (req, res): Promise<void> => {
  const params = ReportAppAiMessageParams.safeParse(req.params);
  const body = ReportAppAiMessageBody.safeParse(req.body);
  if (!params.success || !body.success) {
    res.status(400).json({ error: "Invalid response report" });
    return;
  }
  const userId = await ensureAuthenticatedUser(req);
  const [ownedMessage] = await db
    .select({ id: appAiMessagesTable.id })
    .from(appAiMessagesTable)
    .innerJoin(
      appAiConversationsTable,
      eq(appAiMessagesTable.conversationId, appAiConversationsTable.id),
    )
    .where(
      and(
        eq(appAiMessagesTable.id, params.data.messageId),
        eq(appAiMessagesTable.role, "assistant"),
        eq(appAiConversationsTable.userId, userId),
      ),
    )
    .limit(1);
  if (!ownedMessage) {
    res.status(404).json({ error: "APP AI answer not found" });
    return;
  }
  await db
    .update(appAiMessagesTable)
    .set({ reportReason: body.data.reason, reportedAt: new Date() })
    .where(eq(appAiMessagesTable.id, params.data.messageId));
  res.json(
    ReportAppAiMessageResponse.parse({
      messageId: params.data.messageId,
      status: "received",
    }),
  );
});

router.patch("/app-ai/messages/:messageId/feedback", async (req, res): Promise<void> => {
  const params = RateAppAiMessageParams.safeParse(req.params);
  const body = RateAppAiMessageBody.safeParse(req.body);
  if (!params.success || !body.success) {
    res.status(400).json({ error: "Invalid feedback" });
    return;
  }
  const userId = await ensureAuthenticatedUser(req);
  const [message] = await db
    .select({ message: appAiMessagesTable })
    .from(appAiMessagesTable)
    .innerJoin(
      appAiConversationsTable,
      eq(appAiMessagesTable.conversationId, appAiConversationsTable.id),
    )
    .where(
      and(
        eq(appAiMessagesTable.id, params.data.messageId),
        eq(appAiMessagesTable.role, "assistant"),
        eq(appAiConversationsTable.userId, userId),
      ),
    )
    .limit(1);
  if (!message) {
    res.status(404).json({ error: "APP AI answer not found" });
    return;
  }
  const [updated] = await db
    .update(appAiMessagesTable)
    .set({ helpful: body.data.helpful })
    .where(eq(appAiMessagesTable.id, params.data.messageId))
    .returning();
  res.json(RateAppAiMessageResponse.parse(messageJson(updated)));
});

router.post("/app-ai/support-tickets", async (req, res): Promise<void> => {
  const body = CreateAppAiSupportTicketBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const userId = await ensureAuthenticatedUser(req);
  const [conversation] = await db
    .select({ id: appAiConversationsTable.id })
    .from(appAiConversationsTable)
    .where(
      and(
        eq(appAiConversationsTable.id, body.data.conversationId),
        eq(appAiConversationsTable.userId, userId),
      ),
    )
    .limit(1);
  if (!conversation) {
    res.status(404).json({ error: "APP AI conversation not found" });
    return;
  }
  const [ticket] = await db
    .insert(supportTicketsTable)
    .values({ userId, ...body.data })
    .returning();
  res.status(201).json(
    CreateAppAiSupportTicketResponse.parse({
      id: ticket.id,
      conversationId: ticket.conversationId,
      subject: ticket.subject,
      status: "open",
      createdAt: ticket.createdAt,
    }),
  );
});

export default router;
