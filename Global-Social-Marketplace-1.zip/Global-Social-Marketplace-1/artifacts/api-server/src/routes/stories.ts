import { and, desc, eq, gt, inArray, isNull } from "drizzle-orm";
import { getAuth } from "@clerk/express";
import { Router, type IRouter, type RequestHandler } from "express";
import { Readable } from "node:stream";
import { imageSize } from "image-size";
import {
  CreateStoryBody,
  CreateStoryResponse,
  DeleteStoryParams,
  FinalizeStoryUploadBody,
  FinalizeStoryUploadResponse,
  ListStoriesResponse,
  MarkStoryViewedParams,
  MarkStoryViewedResponse,
  RequestStoryUploadUrlBody,
  RequestStoryUploadUrlResponse,
} from "@workspace/api-zod";
import {
  db,
  storiesTable,
  storyViewsTable,
  usersTable,
} from "@workspace/db";
import { ensureAuthenticatedUser } from "../lib/live-service";
import { ObjectNotFoundError, ObjectStorageService } from "../lib/objectStorage";

const router: IRouter = Router();
const storage = new ObjectStorageService();
const IMAGE_TYPES = new Set(["image/jpeg", "image/png", "image/webp"]);
const VIDEO_TYPES = new Set(["video/mp4", "video/webm"]);
const MAX_IMAGE_BYTES = 10 * 1024 * 1024;
const MAX_VIDEO_BYTES = 50 * 1024 * 1024;

const requireStoriesAuth: RequestHandler = (req, res, next) => {
  if (!getAuth(req).userId) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }
  next();
};

function validateMedia(
  contentType: string,
  size: number,
  durationSeconds: number | undefined,
) {
  if (IMAGE_TYPES.has(contentType)) {
    if (size > MAX_IMAGE_BYTES) return "Images must be 10MB or smaller";
    if (durationSeconds !== undefined) return "Images cannot declare duration";
    return null;
  }
  if (VIDEO_TYPES.has(contentType)) {
    if (size > MAX_VIDEO_BYTES) return "Videos must be 50MB or smaller";
    if (
      durationSeconds === undefined ||
      !Number.isFinite(durationSeconds) ||
      durationSeconds <= 0 ||
      durationSeconds > 15
    ) {
      return "Videos require a declared duration of 15 seconds or less";
    }
    return null;
  }
  return "Unsupported story media type";
}

function normalizeStoryText(value: string) {
  return value
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F-\u009F]/g, "")
    .trim();
}

function objectBelongsToUser(objectPath: string, userId: string) {
  return new RegExp(`^/objects/stories/${escapeRegExp(userId)}/[A-Za-z0-9-]+$`).test(
    objectPath,
  );
}

function escapeRegExp(value: string) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function mediaUrl(objectPath: string | null) {
  return objectPath ? `/api/storage${objectPath}` : null;
}

async function readImageDimensions(
  file: Parameters<ObjectStorageService["downloadObject"]>[0],
  contentType: string,
) {
  const detected = imageSize(await storage.readObjectPrefix(file));
  const expectedType =
    contentType === "image/jpeg"
      ? "jpg"
      : contentType === "image/png"
        ? "png"
        : "webp";
  if (detected.type !== expectedType) {
    throw new Error("Image bytes do not match declared content type");
  }
  if (
    !Number.isInteger(detected.width) ||
    !Number.isInteger(detected.height) ||
    detected.width <= 0 ||
    detected.height <= 0 ||
    detected.width > 4096 ||
    detected.height > 4096
  ) {
    throw new Error("Images must be no larger than 4096 by 4096 pixels");
  }
  return { width: detected.width, height: detected.height };
}

router.use("/stories", requireStoriesAuth);
router.use("/storage", requireStoriesAuth);

router.get("/stories", async (req, res): Promise<void> => {
  const userId = await ensureAuthenticatedUser(req);
  const now = new Date();
  const rows = await db
    .select({ story: storiesTable, author: usersTable })
    .from(storiesTable)
    .innerJoin(usersTable, eq(usersTable.id, storiesTable.authorUserId))
    .where(and(gt(storiesTable.expiresAt, now), isNull(storiesTable.deletedAt)))
    .orderBy(desc(storiesTable.createdAt));
  const storyIds = rows.map(({ story }) => story.id);
  const viewedIds = storyIds.length
    ? new Set(
        (
          await db
            .select({ storyId: storyViewsTable.storyId })
            .from(storyViewsTable)
            .where(
              and(
                eq(storyViewsTable.viewerUserId, userId),
                inArray(storyViewsTable.storyId, storyIds),
              ),
            )
        ).map(({ storyId }) => storyId),
      )
    : new Set<number>();

  const groups = new Map<
    string,
    {
      author: {
        id: string;
        name: string;
        handle: string;
        avatarUrl: string;
      };
      stories: Array<ReturnType<typeof toStoryJson>>;
      hasUnviewed: boolean;
    }
  >();
  for (const { story, author } of rows) {
    const group = groups.get(author.id) ?? {
      author: {
        id: author.id,
        name: author.name,
        handle: author.handle.startsWith("@") ? author.handle : `@${author.handle}`,
        avatarUrl: author.avatarUrl,
      },
      stories: [],
      hasUnviewed: false,
    };
    const viewed = viewedIds.has(story.id);
    group.stories.push(toStoryJson(story, viewed));
    group.hasUnviewed ||= !viewed;
    groups.set(author.id, group);
  }
  res.json(ListStoriesResponse.parse([...groups.values()]));
});

router.post("/stories", async (req, res): Promise<void> => {
  const parsed = CreateStoryBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const userId = await ensureAuthenticatedUser(req);
  const body = parsed.data;
  let objectPath: string | null = null;
  let contentType: string | null = null;
  let sizeBytes: number | null = null;
  let durationSeconds: number | null = null;
  let width: number | null = null;
  let height: number | null = null;

  if (body.type === "text") {
    const normalizedText = body.text ? normalizeStoryText(body.text) : "";
    if (!normalizedText || normalizedText.length > 280 || body.objectPath) {
      res.status(400).json({ error: "Text stories require text of 1-280 characters only" });
      return;
    }
    body.text = normalizedText;
  } else {
    if (!body.objectPath || !objectBelongsToUser(body.objectPath, userId)) {
      res.status(400).json({ error: "Story media must be an uploaded object owned by you" });
      return;
    }
    try {
      const actual = await storage.getObjectMetadata(body.objectPath);
      contentType = actual.metadata.contentType;
      sizeBytes = actual.metadata.size;
      durationSeconds = body.durationSeconds ?? null;
      const mediaError = validateMedia(contentType, sizeBytes, body.durationSeconds);
      if (mediaError || contentType !== body.contentType) {
        res.status(400).json({ error: mediaError ?? "Media content type does not match upload" });
        return;
      }
      if (body.sizeBytes !== undefined && body.sizeBytes !== sizeBytes) {
        res.status(400).json({ error: "Media size does not match upload" });
        return;
      }
      const expectedType = body.type === "image" ? IMAGE_TYPES : VIDEO_TYPES;
      if (!expectedType.has(contentType)) {
        res.status(400).json({ error: "Story type does not match media content type" });
        return;
      }
      if (IMAGE_TYPES.has(contentType)) {
        try {
          ({ width, height } = await readImageDimensions(actual.file, contentType));
        } catch {
          res.status(400).json({ error: "Malformed or oversized image" });
          return;
        }
      }
      objectPath = body.objectPath;
    } catch (error) {
      if (error instanceof ObjectNotFoundError) {
        res.status(400).json({ error: "Uploaded media was not found; finalize it first" });
        return;
      }
      throw error;
    }
  }

  const [story] = await db
    .insert(storiesTable)
    .values({
      authorUserId: userId,
      type: body.type,
      text: body.type === "text" ? body.text! : null,
      objectPath,
      contentType,
      sizeBytes,
      durationSeconds,
      width,
      height,
      expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000),
    })
    .returning();
  res.status(201).json(CreateStoryResponse.parse(toStoryJson(story, false)));
});

router.post("/stories/:storyId/viewed", async (req, res): Promise<void> => {
  const parsed = MarkStoryViewedParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const userId = await ensureAuthenticatedUser(req);
  const [story] = await db
    .select({ id: storiesTable.id })
    .from(storiesTable)
    .where(
      and(
        eq(storiesTable.id, parsed.data.storyId),
        gt(storiesTable.expiresAt, new Date()),
        isNull(storiesTable.deletedAt),
      ),
    )
    .limit(1);
  if (!story) {
    res.status(404).json({ error: "Active story not found" });
    return;
  }
  await db
    .insert(storyViewsTable)
    .values({ storyId: story.id, viewerUserId: userId })
    .onConflictDoNothing({
      target: [storyViewsTable.storyId, storyViewsTable.viewerUserId],
    });
  res.json(MarkStoryViewedResponse.parse({ storyId: story.id, viewed: true }));
});

router.delete("/stories/:storyId", async (req, res): Promise<void> => {
  const parsed = DeleteStoryParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const userId = await ensureAuthenticatedUser(req);
  const [story] = await db
    .select({ authorUserId: storiesTable.authorUserId })
    .from(storiesTable)
    .where(eq(storiesTable.id, parsed.data.storyId))
    .limit(1);
  if (!story) {
    res.status(404).json({ error: "Story not found" });
    return;
  }
  if (story.authorUserId !== userId) {
    res.status(403).json({ error: "Only the story author can delete it" });
    return;
  }
  await db
    .update(storiesTable)
    .set({ deletedAt: new Date() })
    .where(
      and(eq(storiesTable.id, parsed.data.storyId), isNull(storiesTable.deletedAt)),
    );
  res.status(204).end();
});

router.post("/storage/uploads/request-url", async (req, res): Promise<void> => {
  const parsed = RequestStoryUploadUrlBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { contentType, size, durationSeconds } = parsed.data;
  const mediaError = validateMedia(contentType, size, durationSeconds);
  if (mediaError) {
    res.status(400).json({ error: mediaError });
    return;
  }
  const userId = await ensureAuthenticatedUser(req);
  const result = await storage.getStoryUploadURL(userId);
  res.json(
    RequestStoryUploadUrlResponse.parse({
      ...result,
      metadata: parsed.data,
    }),
  );
});

router.post("/storage/uploads/finalize", async (req, res): Promise<void> => {
  const parsed = FinalizeStoryUploadBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const userId = await ensureAuthenticatedUser(req);
  if (!objectBelongsToUser(parsed.data.objectPath, userId)) {
    res.status(403).json({ error: "Upload does not belong to the current user" });
    return;
  }
  try {
    const actual = await storage.getObjectMetadata(parsed.data.objectPath);
    const mediaError = validateMedia(
      actual.metadata.contentType,
      actual.metadata.size,
      parsed.data.durationSeconds,
    );
    if (
      mediaError ||
      actual.metadata.contentType !== parsed.data.contentType ||
      actual.metadata.size !== parsed.data.size
    ) {
      res.status(400).json({ error: mediaError ?? "Uploaded object metadata does not match" });
      return;
    }
    let width: number | null = null;
    let height: number | null = null;
    if (IMAGE_TYPES.has(actual.metadata.contentType)) {
      try {
        ({ width, height } = await readImageDimensions(
          actual.file,
          actual.metadata.contentType,
        ));
      } catch {
        res.status(400).json({ error: "Malformed or oversized image" });
        return;
      }
    }
    res.json(
      FinalizeStoryUploadResponse.parse({
        objectPath: parsed.data.objectPath,
        contentType: actual.metadata.contentType,
        sizeBytes: actual.metadata.size,
        width,
        height,
        durationSeconds: parsed.data.durationSeconds ?? null,
      }),
    );
  } catch (error) {
    if (error instanceof ObjectNotFoundError) {
      res.status(400).json({ error: "Uploaded object was not found" });
      return;
    }
    throw error;
  }
});

router.get("/storage/objects/*path", async (req, res): Promise<void> => {
  const userId = getAuth(req).userId!;
  const rawPath = req.params.path;
  const objectPath = `/objects/stories/${Array.isArray(rawPath) ? rawPath.join("/") : rawPath}`;
  if (!objectPath.startsWith("/objects/stories/")) {
    res.status(404).json({ error: "Object not found" });
    return;
  }
  const [activeStory] = await db
    .select({ id: storiesTable.id })
    .from(storiesTable)
    .where(
      and(
        eq(storiesTable.objectPath, objectPath),
        gt(storiesTable.expiresAt, new Date()),
        isNull(storiesTable.deletedAt),
      ),
    )
    .limit(1);
  if (!activeStory) {
    res.status(404).json({ error: "Object not found" });
    return;
  }
  try {
    const file = await storage.getObjectEntityFile(objectPath);
    const response = await storage.downloadObject(file);
    res.status(response.status);
    response.headers.forEach((value, key) => res.setHeader(key, value));
    if (response.body) {
      Readable.fromWeb(response.body as ReadableStream<Uint8Array>).pipe(res);
    } else {
      res.end();
    }
  } catch (error) {
    if (error instanceof ObjectNotFoundError) {
      res.status(404).json({ error: "Object not found" });
      return;
    }
    req.log.error({ err: error, userId }, "Story object serving failed");
    res.status(500).json({ error: "Failed to serve object" });
  }
});

function toStoryJson(
  story: typeof storiesTable.$inferSelect,
  viewed: boolean,
) {
  return {
    id: story.id,
    authorUserId: story.authorUserId,
    type: story.type as "text" | "image" | "video",
    text: story.text,
    objectPath: story.objectPath,
    mediaUrl: mediaUrl(story.objectPath),
    contentType: story.contentType,
    sizeBytes: story.sizeBytes,
    durationSeconds: story.durationSeconds,
    width: story.width,
    height: story.height,
    createdAt: story.createdAt,
    expiresAt: story.expiresAt,
    deletedAt: story.deletedAt,
    viewed,
  };
}

export default router;