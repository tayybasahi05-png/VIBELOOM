import { Router, type IRouter, type Request } from "express";
import {
  CreateConnectedPaymentAccountBody,
  CreateConnectedPaymentAccountResponse,
  CreateConnectedAccountOnboardingLinkResponse,
  CreateMarketCheckoutBody,
  CreateMarketCheckoutResponse,
  GetConnectedPaymentAccountResponse,
  GetPaymentConfigResponse,
  GetPaymentOrderResponse,
  GetPaymentOrderParams,
  ConfirmPaymentOrderParams,
  ConfirmPaymentOrderResponse,
  DecidePaymentRefundBody,
  DecidePaymentRefundParams,
  DecidePaymentRefundResponse,
  ListPaymentOrdersQueryParams,
  ListPaymentOrdersResponse,
  ListPaymentPayoutsResponse,
  ListPaymentRefundsResponse,
  ListSupportPaymentRefundsResponse,
  RequestPaymentRefundBody,
  RequestPaymentRefundParams,
  RequestPaymentRefundResponse,
} from "@workspace/api-zod";
import { ensureAuthenticatedUser } from "../lib/live-service";
import { requireAuthenticatedRequest } from "../middlewares/requireAuthenticatedRequest";
import {
  confirmPaymentOrder,
  createConnectedAccount,
  createMarketCheckout,
  decidePaymentRefund,
  getConnectedAccount,
  getPaymentOrder,
  listPaymentOrders,
  listPayouts,
  listPaymentRefunds,
  listSupportPaymentRefunds,
  onboardingLink,
  paymentCapabilities,
  refreshConnectedAccount,
  requestPaymentRefund,
} from "../lib/payment-service";

const router: IRouter = Router();
const baseUrl = (req: Request) => {
  const configured = process.env.PUBLIC_APP_ORIGIN?.trim();
  if (configured) {
    const origin = new URL(configured);
    if (process.env.NODE_ENV === "production" && origin.protocol !== "https:") {
      throw new Error("PUBLIC_APP_ORIGIN must use HTTPS");
    }
    return origin.toString().replace(/\/$/, "");
  }
  if (process.env.NODE_ENV === "production") throw new Error("PUBLIC_APP_ORIGIN is required");
  if (process.env.REPLIT_DEV_DOMAIN) return `https://${process.env.REPLIT_DEV_DOMAIN}/global-social`;
  return `${req.protocol}://${req.get("host")}/global-social`;
};

router.get("/payments/config", requireAuthenticatedRequest, async (_req, res) => {
  res.json(GetPaymentConfigResponse.parse(paymentCapabilities()));
});

router.post("/payments/checkout", requireAuthenticatedRequest, async (req, res) => {
  const body = CreateMarketCheckoutBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  try {
    const userId = await ensureAuthenticatedUser(req);
    const result = await createMarketCheckout(
      userId,
      body.data.productId,
      body.data.idempotencyKey,
      baseUrl(req),
      body.data.taxRegion,
    );
    res.status(201).json(CreateMarketCheckoutResponse.parse(result));
  } catch (error) {
    const message = error instanceof Error ? error.message : "Payment checkout unavailable";
    res.status(message.includes("unavailable") ? 409 : 503).json({ error: message });
  }
});

router.get("/payments/orders", requireAuthenticatedRequest, async (req, res) => {
  const query = ListPaymentOrdersQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }
  const userId = await ensureAuthenticatedUser(req);
  res.json(ListPaymentOrdersResponse.parse(await listPaymentOrders(userId, query.data.cursor, query.data.limit)));
});

router.get("/payments/orders/:orderId", requireAuthenticatedRequest, async (req, res) => {
  const params = GetPaymentOrderParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const order = await getPaymentOrder(await ensureAuthenticatedUser(req), params.data.orderId);
  if (!order) {
    res.status(404).json({ error: "Payment order not found" });
    return;
  }
  res.json(GetPaymentOrderResponse.parse(order));
});

router.post("/payments/orders/:orderId/confirm", requireAuthenticatedRequest, async (req, res) => {
  const params = ConfirmPaymentOrderParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  try {
    const order = await confirmPaymentOrder(await ensureAuthenticatedUser(req), params.data.orderId);
    if (!order) {
      res.status(404).json({ error: "Payment order not found" });
      return;
    }
    res.json(ConfirmPaymentOrderResponse.parse(order));
  } catch {
    res.status(503).json({ error: "Payment verification is temporarily unavailable" });
  }
});

router.post("/payments/orders/:orderId/refunds", requireAuthenticatedRequest, async (req, res) => {
  const params = RequestPaymentRefundParams.safeParse(req.params);
  const body = RequestPaymentRefundBody.safeParse(req.body);
  if (!params.success || !body.success) {
    const message = !params.success
      ? params.error.message
      : !body.success
        ? body.error.message
        : "Invalid refund request";
    res.status(400).json({ error: message });
    return;
  }
  try {
    const order = await getPaymentOrder(await ensureAuthenticatedUser(req), params.data.orderId);
    if (!order) {
      res.status(404).json({ error: "Payment order not found" });
      return;
    }
    const refund = await requestPaymentRefund(await ensureAuthenticatedUser(req), params.data.orderId, body.data.amountMinor ?? order.amountMinor - order.refundedAmountMinor, body.data.reason, body.data.idempotencyKey);
    res.status(201).json(RequestPaymentRefundResponse.parse(refund));
  } catch (error) {
    const message = error instanceof Error ? error.message : "Refund unavailable";
    res.status(message.includes("Idempotency key") ? 409 : 400).json({ error: message });
  }
});

router.get("/payments/refunds", requireAuthenticatedRequest, async (req, res) => {
  const userId = await ensureAuthenticatedUser(req);
  res.json(ListPaymentRefundsResponse.parse(await listPaymentRefunds(userId)));
});

router.get("/payments/support/refunds", requireAuthenticatedRequest, async (req, res) => {
  try {
    const userId = await ensureAuthenticatedUser(req);
    res.json(ListSupportPaymentRefundsResponse.parse(await listSupportPaymentRefunds(userId)));
  } catch (error) {
    const message = error instanceof Error ? error.message : "Refund review unavailable";
    res.status(message.includes("access required") ? 403 : 503).json({ error: message });
  }
});

router.post("/payments/support/refunds/:refundId/decision", requireAuthenticatedRequest, async (req, res) => {
  const params = DecidePaymentRefundParams.safeParse(req.params);
  const body = DecidePaymentRefundBody.safeParse(req.body);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  try {
    const userId = await ensureAuthenticatedUser(req);
    const refund = await decidePaymentRefund(userId, params.data.refundId, body.data.decision, body.data.reason);
    if (!refund) {
      res.status(404).json({ error: "Refund request not found" });
      return;
    }
    res.json(DecidePaymentRefundResponse.parse(refund));
  } catch (error) {
    const message = error instanceof Error ? error.message : "Refund review unavailable";
    const status = message.includes("access required")
      ? 403
      : message.includes("already reviewed")
        ? 409
        : message.includes("denial reason")
          ? 400
          : 503;
    res.status(status).json({ error: message });
  }
});

router.get("/payments/connected-account", requireAuthenticatedRequest, async (req, res) => {
  res.json(GetConnectedPaymentAccountResponse.parse(await refreshConnectedAccount(await ensureAuthenticatedUser(req))));
});

router.post("/payments/connected-account", requireAuthenticatedRequest, async (req, res) => {
  const body = CreateConnectedPaymentAccountBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  try {
    const account = await createConnectedAccount(await ensureAuthenticatedUser(req), body.data.country);
    res.status(201).json(CreateConnectedPaymentAccountResponse.parse(account));
  } catch {
    res.status(503).json({ error: "Recipient onboarding is temporarily unavailable" });
  }
});

router.post("/payments/connected-account/onboarding-link", requireAuthenticatedRequest, async (req, res) => {
  try {
    const link = await onboardingLink(await ensureAuthenticatedUser(req), baseUrl(req));
    res.json(CreateConnectedAccountOnboardingLinkResponse.parse(link));
  } catch (error) {
    res.status(400).json({ error: error instanceof Error ? error.message : "Onboarding unavailable" });
  }
});

router.get("/payments/payouts", requireAuthenticatedRequest, async (req, res) => {
  try {
    res.json(ListPaymentPayoutsResponse.parse(await listPayouts(await ensureAuthenticatedUser(req))));
  } catch {
    res.status(503).json({ error: "Payout history is temporarily unavailable" });
  }
});

export default router;