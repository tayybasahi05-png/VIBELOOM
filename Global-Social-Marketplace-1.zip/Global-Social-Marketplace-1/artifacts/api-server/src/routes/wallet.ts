import { Router, type IRouter } from "express";
import {
  CreateCoinCheckoutBody,
  CreateCoinCheckoutResponse,
  ConfirmCoinCheckoutBody,
  ConfirmCoinCheckoutResponse,
  GetWalletResponse,
  ListReceivedGiftsResponse,
  ListSentGiftsResponse,
  ListWalletTransactionsResponse,
  ListCoinPacksResponse,
} from "@workspace/api-zod";
import { ensureAuthenticatedUser } from "../lib/live-service";
import {
  COIN_PACKS,
  createCheckoutRecord,
  creditPaidCheckout,
  getCoinPack,
  getCheckoutRecord,
  getWalletSummary,
  listGiftHistory,
  listWalletTransactions,
} from "../lib/wallet-service";
import { stripeRequest } from "../stripeConnector";
import { requireAuthenticatedRequest } from "../middlewares/requireAuthenticatedRequest";

const router: IRouter = Router();

async function getOrCreateCoinPackPrice(
  pack: (typeof COIN_PACKS)[number],
): Promise<string> {
  const query = encodeURIComponent(
    `metadata['vibeloom_coin_pack_id']:'${pack.id}' AND active:'true'`,
  );
  const products = await stripeRequest<{ data: Array<{ id: string }> }>(
    `/v1/products/search?query=${query}`,
  );
  const product =
    products.data[0] ??
    (await stripeRequest<{ id: string }>("/v1/products", {
      method: "POST",
      body: new URLSearchParams({
        name: `${pack.coinAmount.toLocaleString()} VibeLoom Coins`,
        description: "Coins used to send gifts to live creators.",
        "metadata[vibeloom_coin_pack_id]": pack.id,
        "metadata[coin_amount]": String(pack.coinAmount),
      }),
    }));
  const prices = await stripeRequest<{
    data: Array<{ id: string; unit_amount: number | null; currency: string }>;
  }>(
    `/v1/prices?product=${encodeURIComponent(product.id)}&active=true&type=one_time&limit=100`,
  );
  const existing = prices.data.find(
    (price) =>
      price.unit_amount === pack.priceCents &&
      price.currency.toLowerCase() === pack.currency,
  );
  if (existing) return existing.id;
  const price = await stripeRequest<{ id: string }>("/v1/prices", {
    method: "POST",
    body: new URLSearchParams({
      product: product.id,
      unit_amount: String(pack.priceCents),
      currency: pack.currency,
      "metadata[vibeloom_coin_pack_id]": pack.id,
    }),
  });
  return price.id;
}

router.get("/wallet", requireAuthenticatedRequest, async (req, res): Promise<void> => {
  const userId = await ensureAuthenticatedUser(req);
  res.json(GetWalletResponse.parse(await getWalletSummary(userId)));
});

router.get("/wallet/transactions", requireAuthenticatedRequest, async (req, res): Promise<void> => {
  const userId = await ensureAuthenticatedUser(req);
  const transactions = await listWalletTransactions(userId);
  res.json(
    ListWalletTransactionsResponse.parse(
      transactions.map((transaction) => ({
        ...transaction,
        createdAt: transaction.createdAt.toISOString(),
        referenceId: transaction.referenceId ?? null,
      })),
    ),
  );
});

router.get("/wallet/gifts/sent", requireAuthenticatedRequest, async (req, res): Promise<void> => {
  const userId = await ensureAuthenticatedUser(req);
  res.json(ListSentGiftsResponse.parse(await listGiftHistory(userId, "sent")));
});

router.get("/wallet/gifts/received", requireAuthenticatedRequest, async (req, res): Promise<void> => {
  const userId = await ensureAuthenticatedUser(req);
  res.json(ListReceivedGiftsResponse.parse(await listGiftHistory(userId, "received")));
});

router.get("/wallet/coin-packs", async (_req, res): Promise<void> => {
  res.json(ListCoinPacksResponse.parse(COIN_PACKS));
});

router.post("/wallet/checkout", requireAuthenticatedRequest, async (req, res): Promise<void> => {
  const body = CreateCoinCheckoutBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const pack = getCoinPack(body.data.packId);
  if (!pack) {
    res.status(400).json({ error: "Unknown coin pack" });
    return;
  }
  try {
    const userId = await ensureAuthenticatedUser(req);
    const priceId = await getOrCreateCoinPackPrice(pack);
    const baseUrl = `${req.protocol}://${req.get("host")}`;
    const returnPath = body.data.roomId
      ? `/live/${encodeURIComponent(body.data.roomId)}`
      : "/wallet";
    const session = await stripeRequest<{ id: string; url: string | null }>(
      "/v1/checkout/sessions",
      {
        method: "POST",
        idempotencyKey: `coin-checkout:${userId}:${body.data.idempotencyKey}`,
        body: new URLSearchParams({
          mode: "payment",
          "line_items[0][price]": priceId,
          "line_items[0][quantity]": "1",
          success_url: `${baseUrl}${returnPath}?coin_checkout=success&session_id={CHECKOUT_SESSION_ID}`,
          cancel_url: `${baseUrl}${returnPath}?coin_checkout=cancelled`,
          client_reference_id: userId,
          "metadata[userId]": userId,
          "metadata[packId]": pack.id,
          "metadata[coinAmount]": String(pack.coinAmount),
        }),
      },
    );
    if (!session.url) {
      res.status(503).json({ error: "Stripe did not return a checkout URL" });
      return;
    }
    await createCheckoutRecord({
      userId,
      checkoutSessionId: session.id,
      packId: pack.id,
      coinAmount: pack.coinAmount,
      amountMinor: pack.priceCents,
      currency: pack.currency,
    });
    res.status(201).json(
      CreateCoinCheckoutResponse.parse({
        checkoutSessionId: session.id,
        url: session.url,
        packId: pack.id,
        coinAmount: pack.coinAmount,
      }),
    );
  } catch (error) {
    req.log.warn({ err: error }, "Stripe checkout creation failed");
    res.status(503).json({ error: "Stripe checkout is temporarily unavailable" });
  }
});

router.post(
  "/wallet/checkout/confirm",
  requireAuthenticatedRequest,
  async (req, res): Promise<void> => {
    const body = ConfirmCoinCheckoutBody.safeParse(req.body);
    if (!body.success) {
      res.status(400).json({ error: body.error.message });
      return;
    }
    try {
      const userId = await ensureAuthenticatedUser(req);
      const record = await getCheckoutRecord(body.data.checkoutSessionId);
      if (!record || record.userId !== userId) {
        res.status(404).json({ error: "Checkout record not found" });
        return;
      }
      const session = await stripeRequest<{
        id: string;
        payment_status: string;
        amount_total: number | null;
        currency: string | null;
        client_reference_id: string | null;
        payment_intent: string | null;
        metadata?: Record<string, string>;
      }>(`/v1/checkout/sessions/${encodeURIComponent(body.data.checkoutSessionId)}`);
      const legacyPack = getCoinPack(record.packId);
      const expectedAmountMinor = record.amountMinor ?? legacyPack?.priceCents;
      const expectedCurrency = record.currency || legacyPack?.currency;
      if (
        session.payment_status !== "paid" ||
        session.client_reference_id !== userId ||
        expectedAmountMinor == null ||
        session.amount_total !== expectedAmountMinor ||
        session.currency?.toLowerCase() !== expectedCurrency ||
        session.metadata?.packId !== record.packId ||
        session.metadata?.coinAmount !== String(record.coinAmount)
      ) {
        res.status(400).json({ error: "Checkout has not been paid" });
        return;
      }
      await creditPaidCheckout(session.id, session.payment_intent);
      res.json(
        ConfirmCoinCheckoutResponse.parse(await getWalletSummary(userId)),
      );
    } catch (error) {
      req.log.warn({ err: error }, "Stripe checkout confirmation failed");
      res.status(503).json({ error: "Stripe checkout verification is temporarily unavailable" });
    }
  },
);

export default router;